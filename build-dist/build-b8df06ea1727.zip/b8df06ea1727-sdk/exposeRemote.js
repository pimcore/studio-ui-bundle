
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/b8df06ea1727-sdk/static/js/remoteEntry.js'
    