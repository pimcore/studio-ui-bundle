
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/4bc5f95325ff-sdk/static/js/remoteEntry.js'
    