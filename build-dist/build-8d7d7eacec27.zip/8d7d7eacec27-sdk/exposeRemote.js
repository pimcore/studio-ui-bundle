
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/8d7d7eacec27-sdk/static/js/remoteEntry.js'
    