
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/666bb7d2d6b1-sdk/static/js/remoteEntry.js'
    