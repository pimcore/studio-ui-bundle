
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/d7e2cc66f701-sdk/static/js/remoteEntry.js'
    