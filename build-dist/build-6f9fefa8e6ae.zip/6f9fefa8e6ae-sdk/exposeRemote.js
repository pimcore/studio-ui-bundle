
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/6f9fefa8e6ae-sdk/static/js/remoteEntry.js'
    