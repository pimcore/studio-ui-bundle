
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/31a7d1a6d71d-sdk/static/js/remoteEntry.js'
    