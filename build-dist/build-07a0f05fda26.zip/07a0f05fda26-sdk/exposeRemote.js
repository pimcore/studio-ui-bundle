
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/07a0f05fda26-sdk/static/js/remoteEntry.js'
    