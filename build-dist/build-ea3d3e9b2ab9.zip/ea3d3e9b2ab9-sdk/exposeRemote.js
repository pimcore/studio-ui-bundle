
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/ea3d3e9b2ab9-sdk/static/js/remoteEntry.js'
    