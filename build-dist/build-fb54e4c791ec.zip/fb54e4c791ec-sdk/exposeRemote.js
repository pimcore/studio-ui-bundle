
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/fb54e4c791ec-sdk/static/js/remoteEntry.js'
    