
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/3dbb97553ed5-sdk/static/js/remoteEntry.js'
    