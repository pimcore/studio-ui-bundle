
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/67981bf1c31d-sdk/static/js/remoteEntry.js'
    