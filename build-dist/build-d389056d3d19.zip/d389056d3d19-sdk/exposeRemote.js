
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/d389056d3d19-sdk/static/js/remoteEntry.js'
    