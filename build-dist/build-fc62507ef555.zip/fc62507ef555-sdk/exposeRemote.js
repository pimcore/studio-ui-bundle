
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/fc62507ef555-sdk/static/js/remoteEntry.js'
    