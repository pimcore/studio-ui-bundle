
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/1c724d9e9cca-sdk/static/js/remoteEntry.js'
    