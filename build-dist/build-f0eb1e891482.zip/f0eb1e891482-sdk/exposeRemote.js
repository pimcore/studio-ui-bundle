
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/f0eb1e891482-sdk/static/js/remoteEntry.js'
    