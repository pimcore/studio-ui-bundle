
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/2f3f17dee46d-sdk/static/js/remoteEntry.js'
    