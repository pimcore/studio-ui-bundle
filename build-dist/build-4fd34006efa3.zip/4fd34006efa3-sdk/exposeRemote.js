
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/4fd34006efa3-sdk/static/js/remoteEntry.js'
    