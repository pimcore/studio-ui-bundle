
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/7a56d9cc5a18-sdk/static/js/remoteEntry.js'
    