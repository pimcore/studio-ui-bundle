
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/403d1c01b9e8-sdk/static/js/remoteEntry.js'
    