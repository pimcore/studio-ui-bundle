
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/44b012282fb3-sdk/static/js/remoteEntry.js'
    