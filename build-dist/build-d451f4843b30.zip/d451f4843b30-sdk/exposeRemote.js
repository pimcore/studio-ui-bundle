
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/d451f4843b30-sdk/static/js/remoteEntry.js'
    