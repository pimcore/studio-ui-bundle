
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/73aff8b4b4ff-sdk/static/js/remoteEntry.js'
    