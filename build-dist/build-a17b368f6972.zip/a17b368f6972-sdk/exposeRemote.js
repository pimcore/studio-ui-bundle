
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/a17b368f6972-sdk/static/js/remoteEntry.js'
    