
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/6fb5ee848ee3-sdk/static/js/remoteEntry.js'
    