
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/81a86b176cc9-sdk/static/js/remoteEntry.js'
    