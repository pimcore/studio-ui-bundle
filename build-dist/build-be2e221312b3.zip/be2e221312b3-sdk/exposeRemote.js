
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/be2e221312b3-sdk/static/js/remoteEntry.js'
    