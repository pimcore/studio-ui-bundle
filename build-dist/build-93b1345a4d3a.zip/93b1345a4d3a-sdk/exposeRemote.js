
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/93b1345a4d3a-sdk/static/js/remoteEntry.js'
    