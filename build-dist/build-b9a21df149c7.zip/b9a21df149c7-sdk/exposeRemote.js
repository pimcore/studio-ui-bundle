
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/b9a21df149c7-sdk/static/js/remoteEntry.js'
    