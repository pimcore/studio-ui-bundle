
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/5c8cad809de8-sdk/static/js/remoteEntry.js'
    