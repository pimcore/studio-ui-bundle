
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/c61078e116c9-sdk/static/js/remoteEntry.js'
    