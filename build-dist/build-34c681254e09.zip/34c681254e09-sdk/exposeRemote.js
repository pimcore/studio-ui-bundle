
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/34c681254e09-sdk/static/js/remoteEntry.js'
    