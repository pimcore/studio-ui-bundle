
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/9e3f09e47269-sdk/static/js/remoteEntry.js'
    