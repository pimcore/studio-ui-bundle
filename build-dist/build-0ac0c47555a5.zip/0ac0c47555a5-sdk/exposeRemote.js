
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/0ac0c47555a5-sdk/static/js/remoteEntry.js'
    