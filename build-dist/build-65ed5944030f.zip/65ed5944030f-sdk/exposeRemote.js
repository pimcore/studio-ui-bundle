
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/65ed5944030f-sdk/static/js/remoteEntry.js'
    