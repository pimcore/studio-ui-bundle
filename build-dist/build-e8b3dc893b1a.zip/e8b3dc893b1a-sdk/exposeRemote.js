
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/e8b3dc893b1a-sdk/static/js/remoteEntry.js'
    