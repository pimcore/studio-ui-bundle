
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/71dfce65c1e5-sdk/static/js/remoteEntry.js'
    