
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/3d221c742f97-sdk/static/js/remoteEntry.js'
    