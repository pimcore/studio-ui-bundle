
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/ace2a0ee567e-sdk/static/js/remoteEntry.js'
    