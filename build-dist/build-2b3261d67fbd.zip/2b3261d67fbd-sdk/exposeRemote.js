
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/2b3261d67fbd-sdk/static/js/remoteEntry.js'
    