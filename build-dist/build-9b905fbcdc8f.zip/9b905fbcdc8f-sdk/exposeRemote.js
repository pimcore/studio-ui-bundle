
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/9b905fbcdc8f-sdk/static/js/remoteEntry.js'
    