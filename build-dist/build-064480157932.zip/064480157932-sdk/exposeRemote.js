
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/064480157932-sdk/static/js/remoteEntry.js'
    