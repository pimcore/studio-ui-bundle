
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/89b0d459f97a-sdk/static/js/remoteEntry.js'
    