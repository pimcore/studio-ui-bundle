
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/3eb741ddcf36-sdk/static/js/remoteEntry.js'
    