
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/c82b4cbffa98-sdk/static/js/remoteEntry.js'
    