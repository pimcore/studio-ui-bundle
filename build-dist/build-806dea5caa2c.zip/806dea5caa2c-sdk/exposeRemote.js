
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/806dea5caa2c-sdk/static/js/remoteEntry.js'
    