
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/b11a5cf14e11-sdk/static/js/remoteEntry.js'
    