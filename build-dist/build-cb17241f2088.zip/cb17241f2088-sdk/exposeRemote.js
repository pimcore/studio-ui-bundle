
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/cb17241f2088-sdk/static/js/remoteEntry.js'
    