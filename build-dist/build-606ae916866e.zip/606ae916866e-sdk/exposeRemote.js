
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/606ae916866e-sdk/static/js/remoteEntry.js'
    