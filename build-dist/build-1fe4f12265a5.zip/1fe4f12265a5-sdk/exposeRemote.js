
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/1fe4f12265a5-sdk/static/js/remoteEntry.js'
    