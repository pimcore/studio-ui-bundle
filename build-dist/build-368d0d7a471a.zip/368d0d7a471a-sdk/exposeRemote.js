
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/368d0d7a471a-sdk/static/js/remoteEntry.js'
    