
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/bbf086d4ea21-sdk/static/js/remoteEntry.js'
    