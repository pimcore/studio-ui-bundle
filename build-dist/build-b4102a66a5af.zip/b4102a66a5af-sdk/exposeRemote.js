
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/b4102a66a5af-sdk/static/js/remoteEntry.js'
    