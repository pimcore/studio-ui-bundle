
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/2bf32ffe40f9-sdk/static/js/remoteEntry.js'
    