
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/f4dd5c6659ee-sdk/static/js/remoteEntry.js'
    