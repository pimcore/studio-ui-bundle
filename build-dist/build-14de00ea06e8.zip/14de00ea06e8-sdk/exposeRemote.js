
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/14de00ea06e8-sdk/static/js/remoteEntry.js'
    