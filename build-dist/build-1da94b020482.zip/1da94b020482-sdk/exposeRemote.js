
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/1da94b020482-sdk/static/js/remoteEntry.js'
    