
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/53b03b908e96-sdk/static/js/remoteEntry.js'
    