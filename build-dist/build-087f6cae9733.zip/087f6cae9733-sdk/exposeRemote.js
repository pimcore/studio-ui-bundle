
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/087f6cae9733-sdk/static/js/remoteEntry.js'
    