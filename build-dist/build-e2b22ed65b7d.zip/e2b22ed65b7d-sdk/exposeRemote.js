
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/e2b22ed65b7d-sdk/static/js/remoteEntry.js'
    