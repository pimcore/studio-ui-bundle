
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/5ba43fb218b8-sdk/static/js/remoteEntry.js'
    