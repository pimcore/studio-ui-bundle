
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/506fe338275a-sdk/static/js/remoteEntry.js'
    