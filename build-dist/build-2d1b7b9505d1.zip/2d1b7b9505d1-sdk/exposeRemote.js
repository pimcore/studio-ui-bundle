
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/2d1b7b9505d1-sdk/static/js/remoteEntry.js'
    