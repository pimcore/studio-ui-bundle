
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/63b3af519971-sdk/static/js/remoteEntry.js'
    