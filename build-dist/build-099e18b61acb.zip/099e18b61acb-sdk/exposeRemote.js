
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/099e18b61acb-sdk/static/js/remoteEntry.js'
    