
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/18487e1e9e05-sdk/static/js/remoteEntry.js'
    