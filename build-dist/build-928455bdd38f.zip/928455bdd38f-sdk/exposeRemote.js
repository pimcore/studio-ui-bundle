
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/928455bdd38f-sdk/static/js/remoteEntry.js'
    