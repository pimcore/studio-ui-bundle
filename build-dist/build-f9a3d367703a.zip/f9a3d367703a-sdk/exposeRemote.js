
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/f9a3d367703a-sdk/static/js/remoteEntry.js'
    