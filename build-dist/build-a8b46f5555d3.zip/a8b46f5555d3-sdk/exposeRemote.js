
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/a8b46f5555d3-sdk/static/js/remoteEntry.js'
    