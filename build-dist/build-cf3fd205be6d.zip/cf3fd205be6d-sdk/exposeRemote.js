
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/cf3fd205be6d-sdk/static/js/remoteEntry.js'
    