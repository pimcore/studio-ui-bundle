
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/f9436205af16-sdk/static/js/remoteEntry.js'
    