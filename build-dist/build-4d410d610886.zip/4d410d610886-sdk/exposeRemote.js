
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/4d410d610886-sdk/static/js/remoteEntry.js'
    