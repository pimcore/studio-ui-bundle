
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/724776a03fb1-sdk/static/js/remoteEntry.js'
    