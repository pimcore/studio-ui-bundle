
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/6f24473c6e1d-sdk/static/js/remoteEntry.js'
    