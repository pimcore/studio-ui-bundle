
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/5d9587503532-sdk/static/js/remoteEntry.js'
    