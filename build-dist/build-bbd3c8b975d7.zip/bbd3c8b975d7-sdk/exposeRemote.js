
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/bbd3c8b975d7-sdk/static/js/remoteEntry.js'
    