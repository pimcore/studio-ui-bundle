
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/c1e624124591-sdk/static/js/remoteEntry.js'
    