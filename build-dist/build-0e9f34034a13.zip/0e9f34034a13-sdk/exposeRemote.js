
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/0e9f34034a13-sdk/static/js/remoteEntry.js'
    