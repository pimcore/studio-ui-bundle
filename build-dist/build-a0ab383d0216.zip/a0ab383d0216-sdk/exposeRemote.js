
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/a0ab383d0216-sdk/static/js/remoteEntry.js'
    