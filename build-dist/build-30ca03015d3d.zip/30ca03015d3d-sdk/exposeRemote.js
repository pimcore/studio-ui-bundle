
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/30ca03015d3d-sdk/static/js/remoteEntry.js'
    