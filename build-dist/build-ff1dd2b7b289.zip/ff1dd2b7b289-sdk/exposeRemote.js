
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/ff1dd2b7b289-sdk/static/js/remoteEntry.js'
    