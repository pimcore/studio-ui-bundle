
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/f4441a8b3689-sdk/static/js/remoteEntry.js'
    