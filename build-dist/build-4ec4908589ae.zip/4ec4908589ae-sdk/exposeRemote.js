
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/4ec4908589ae-sdk/static/js/remoteEntry.js'
    