
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/afb02aecc21d-sdk/static/js/remoteEntry.js'
    