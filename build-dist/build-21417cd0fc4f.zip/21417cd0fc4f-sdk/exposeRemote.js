
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/21417cd0fc4f-sdk/static/js/remoteEntry.js'
    