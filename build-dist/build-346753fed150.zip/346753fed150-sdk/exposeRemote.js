
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/346753fed150-sdk/static/js/remoteEntry.js'
    