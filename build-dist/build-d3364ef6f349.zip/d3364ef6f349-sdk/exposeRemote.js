
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/d3364ef6f349-sdk/static/js/remoteEntry.js'
    