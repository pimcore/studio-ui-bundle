
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/f3d34b232275-sdk/static/js/remoteEntry.js'
    