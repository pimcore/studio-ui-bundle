
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/ab59d86c7c6d-sdk/static/js/remoteEntry.js'
    