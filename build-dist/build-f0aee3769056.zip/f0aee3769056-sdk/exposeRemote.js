
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/f0aee3769056-sdk/static/js/remoteEntry.js'
    