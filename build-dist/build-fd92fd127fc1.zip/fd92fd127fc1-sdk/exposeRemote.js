
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/fd92fd127fc1-sdk/static/js/remoteEntry.js'
    