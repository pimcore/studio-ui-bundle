
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/47ea0286753f-sdk/static/js/remoteEntry.js'
    