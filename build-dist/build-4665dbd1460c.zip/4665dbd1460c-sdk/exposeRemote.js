
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/4665dbd1460c-sdk/static/js/remoteEntry.js'
    