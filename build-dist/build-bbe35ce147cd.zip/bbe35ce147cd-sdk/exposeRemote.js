
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/bbe35ce147cd-sdk/static/js/remoteEntry.js'
    