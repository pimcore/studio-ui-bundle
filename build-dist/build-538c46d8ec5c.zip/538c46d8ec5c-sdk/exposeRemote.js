
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/538c46d8ec5c-sdk/static/js/remoteEntry.js'
    