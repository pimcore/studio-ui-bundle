
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/ea595112ee61-sdk/static/js/remoteEntry.js'
    