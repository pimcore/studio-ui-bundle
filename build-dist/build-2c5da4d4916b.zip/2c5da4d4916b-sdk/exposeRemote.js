
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/2c5da4d4916b-sdk/static/js/remoteEntry.js'
    