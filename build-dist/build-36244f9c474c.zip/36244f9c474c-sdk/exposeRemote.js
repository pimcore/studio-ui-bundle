
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/36244f9c474c-sdk/static/js/remoteEntry.js'
    