
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/21472e35af27-sdk/static/js/remoteEntry.js'
    