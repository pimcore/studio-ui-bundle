
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/72a4b3c74359-sdk/static/js/remoteEntry.js'
    