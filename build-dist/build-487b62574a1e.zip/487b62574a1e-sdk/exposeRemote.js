
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/487b62574a1e-sdk/static/js/remoteEntry.js'
    