
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/05bcee59de90-sdk/static/js/remoteEntry.js'
    