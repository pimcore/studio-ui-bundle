
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/3506d6075d80-sdk/static/js/remoteEntry.js'
    