
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/b8ea4f4900c2-sdk/static/js/remoteEntry.js'
    