
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/2bb78554650a-sdk/static/js/remoteEntry.js'
    