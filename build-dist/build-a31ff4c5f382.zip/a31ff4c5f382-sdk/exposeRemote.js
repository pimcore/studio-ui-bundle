
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/a31ff4c5f382-sdk/static/js/remoteEntry.js'
    