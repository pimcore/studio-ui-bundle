
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/05a2cf864ce0-sdk/static/js/remoteEntry.js'
    