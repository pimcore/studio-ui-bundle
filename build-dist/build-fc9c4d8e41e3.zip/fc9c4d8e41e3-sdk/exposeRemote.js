
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/fc9c4d8e41e3-sdk/static/js/remoteEntry.js'
    