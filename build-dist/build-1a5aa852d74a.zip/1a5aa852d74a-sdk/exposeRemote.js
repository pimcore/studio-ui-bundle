
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/1a5aa852d74a-sdk/static/js/remoteEntry.js'
    