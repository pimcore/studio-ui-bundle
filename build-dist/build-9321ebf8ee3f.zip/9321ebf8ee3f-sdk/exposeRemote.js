
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/9321ebf8ee3f-sdk/static/js/remoteEntry.js'
    