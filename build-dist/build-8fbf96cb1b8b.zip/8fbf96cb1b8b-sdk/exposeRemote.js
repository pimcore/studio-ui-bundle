
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/8fbf96cb1b8b-sdk/static/js/remoteEntry.js'
    