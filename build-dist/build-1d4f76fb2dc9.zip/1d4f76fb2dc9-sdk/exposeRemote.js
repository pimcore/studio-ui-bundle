
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/1d4f76fb2dc9-sdk/static/js/remoteEntry.js'
    