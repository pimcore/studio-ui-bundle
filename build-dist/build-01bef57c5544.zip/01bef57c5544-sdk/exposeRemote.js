
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/01bef57c5544-sdk/static/js/remoteEntry.js'
    