
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/8cd2812ffa88-sdk/static/js/remoteEntry.js'
    