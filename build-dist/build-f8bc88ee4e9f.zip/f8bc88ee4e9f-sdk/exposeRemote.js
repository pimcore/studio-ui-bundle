
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/f8bc88ee4e9f-sdk/static/js/remoteEntry.js'
    