
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/cc5ed6f0ee09-sdk/static/js/remoteEntry.js'
    