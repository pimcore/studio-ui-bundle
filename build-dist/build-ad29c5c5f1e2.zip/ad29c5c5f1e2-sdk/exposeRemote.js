
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/ad29c5c5f1e2-sdk/static/js/remoteEntry.js'
    