
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/d6a1d7531496-sdk/static/js/remoteEntry.js'
    