
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/d7aaeac5669b-sdk/static/js/remoteEntry.js'
    