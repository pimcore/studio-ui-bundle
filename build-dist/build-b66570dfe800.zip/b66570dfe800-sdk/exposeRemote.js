
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/b66570dfe800-sdk/static/js/remoteEntry.js'
    