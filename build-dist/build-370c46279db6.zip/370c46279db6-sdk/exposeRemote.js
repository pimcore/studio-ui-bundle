
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/370c46279db6-sdk/static/js/remoteEntry.js'
    