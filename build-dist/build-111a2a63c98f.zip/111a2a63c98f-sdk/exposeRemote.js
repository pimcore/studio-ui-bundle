
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/111a2a63c98f-sdk/static/js/remoteEntry.js'
    