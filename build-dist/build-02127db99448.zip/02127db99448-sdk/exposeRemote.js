
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/02127db99448-sdk/static/js/remoteEntry.js'
    