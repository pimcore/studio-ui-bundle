
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/d601d09c64d1-sdk/static/js/remoteEntry.js'
    