
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/9bc654367171-sdk/static/js/remoteEntry.js'
    