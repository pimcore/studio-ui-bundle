
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/8e95132b5386-sdk/static/js/remoteEntry.js'
    