
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/ee966aca85e0-sdk/static/js/remoteEntry.js'
    