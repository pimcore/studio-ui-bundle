
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/d84e58bea1ed-sdk/static/js/remoteEntry.js'
    