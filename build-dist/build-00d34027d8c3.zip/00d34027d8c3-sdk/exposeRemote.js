
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/00d34027d8c3-sdk/static/js/remoteEntry.js'
    