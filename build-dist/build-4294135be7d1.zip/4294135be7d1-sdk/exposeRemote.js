
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/4294135be7d1-sdk/static/js/remoteEntry.js'
    