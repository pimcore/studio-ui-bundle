
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/19205161c4d9-sdk/static/js/remoteEntry.js'
    