
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/05dc3cdb807a-sdk/static/js/remoteEntry.js'
    