
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/10da65548762-sdk/static/js/remoteEntry.js'
    