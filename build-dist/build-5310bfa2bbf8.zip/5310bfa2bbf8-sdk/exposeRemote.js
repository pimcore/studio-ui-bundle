
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/5310bfa2bbf8-sdk/static/js/remoteEntry.js'
    