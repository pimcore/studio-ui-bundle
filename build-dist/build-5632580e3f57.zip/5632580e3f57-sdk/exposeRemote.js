
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/5632580e3f57-sdk/static/js/remoteEntry.js'
    