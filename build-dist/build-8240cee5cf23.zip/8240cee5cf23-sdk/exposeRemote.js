
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/8240cee5cf23-sdk/static/js/remoteEntry.js'
    