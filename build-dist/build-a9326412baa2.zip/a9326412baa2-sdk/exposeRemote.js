
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/a9326412baa2-sdk/static/js/remoteEntry.js'
    