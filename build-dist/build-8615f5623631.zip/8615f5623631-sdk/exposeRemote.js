
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/8615f5623631-sdk/static/js/remoteEntry.js'
    