
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/ba539855ef7f-sdk/static/js/remoteEntry.js'
    