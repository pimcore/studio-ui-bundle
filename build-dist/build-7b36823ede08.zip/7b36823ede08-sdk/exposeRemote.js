
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/7b36823ede08-sdk/static/js/remoteEntry.js'
    