
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/c1308be2e7c7-sdk/static/js/remoteEntry.js'
    