
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/5a24d77b99ec-sdk/static/js/remoteEntry.js'
    