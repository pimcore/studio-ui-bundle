
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/606e5fea1aa6-sdk/static/js/remoteEntry.js'
    