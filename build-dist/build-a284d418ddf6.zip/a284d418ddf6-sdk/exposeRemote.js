
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/a284d418ddf6-sdk/static/js/remoteEntry.js'
    