
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/285ec610cd91-sdk/static/js/remoteEntry.js'
    