
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/eaa761f0fdce-sdk/static/js/remoteEntry.js'
    