
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/4b44f38013a7-sdk/static/js/remoteEntry.js'
    