
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/e3105b824895-sdk/static/js/remoteEntry.js'
    