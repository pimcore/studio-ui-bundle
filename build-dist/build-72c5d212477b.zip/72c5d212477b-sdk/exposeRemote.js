
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/72c5d212477b-sdk/static/js/remoteEntry.js'
    