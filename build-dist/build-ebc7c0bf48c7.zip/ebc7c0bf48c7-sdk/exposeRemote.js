
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/ebc7c0bf48c7-sdk/static/js/remoteEntry.js'
    