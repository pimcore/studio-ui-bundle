
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/eef24ea37485-sdk/static/js/remoteEntry.js'
    