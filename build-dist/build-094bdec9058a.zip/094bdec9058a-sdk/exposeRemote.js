
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/094bdec9058a-sdk/static/js/remoteEntry.js'
    