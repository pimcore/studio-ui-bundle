
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/2454c641fbd9-sdk/static/js/remoteEntry.js'
    