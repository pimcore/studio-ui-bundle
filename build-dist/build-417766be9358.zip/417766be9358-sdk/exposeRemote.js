
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/417766be9358-sdk/static/js/remoteEntry.js'
    