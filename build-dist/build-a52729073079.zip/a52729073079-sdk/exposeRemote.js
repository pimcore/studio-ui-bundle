
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/a52729073079-sdk/static/js/remoteEntry.js'
    