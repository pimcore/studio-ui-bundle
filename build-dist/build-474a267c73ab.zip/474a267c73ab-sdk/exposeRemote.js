
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/474a267c73ab-sdk/static/js/remoteEntry.js'
    