
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/e40b8d8e5cf2-sdk/static/js/remoteEntry.js'
    