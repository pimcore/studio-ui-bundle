
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/cbe8e1290c7b-sdk/static/js/remoteEntry.js'
    