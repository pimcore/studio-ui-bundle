
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/560b85fe9ea4-sdk/static/js/remoteEntry.js'
    