
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/845cc093b419-sdk/static/js/remoteEntry.js'
    