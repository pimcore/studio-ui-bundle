
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/dfae5e7aedda-sdk/static/js/remoteEntry.js'
    