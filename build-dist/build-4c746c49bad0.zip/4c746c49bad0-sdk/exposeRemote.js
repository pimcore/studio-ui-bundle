
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/4c746c49bad0-sdk/static/js/remoteEntry.js'
    