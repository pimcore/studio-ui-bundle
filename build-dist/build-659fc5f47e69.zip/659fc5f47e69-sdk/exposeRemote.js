
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/659fc5f47e69-sdk/static/js/remoteEntry.js'
    