
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/b3272ce75f65-sdk/static/js/remoteEntry.js'
    