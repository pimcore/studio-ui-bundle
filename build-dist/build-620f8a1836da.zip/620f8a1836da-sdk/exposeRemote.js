
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/620f8a1836da-sdk/static/js/remoteEntry.js'
    