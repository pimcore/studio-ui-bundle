
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/2f06fdde7d86-sdk/static/js/remoteEntry.js'
    