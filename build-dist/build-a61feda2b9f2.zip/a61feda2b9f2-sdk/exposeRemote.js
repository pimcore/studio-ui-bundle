
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/a61feda2b9f2-sdk/static/js/remoteEntry.js'
    