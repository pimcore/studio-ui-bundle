
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/6f39e838bf6f-sdk/static/js/remoteEntry.js'
    