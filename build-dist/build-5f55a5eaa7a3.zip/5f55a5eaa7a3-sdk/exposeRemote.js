
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/5f55a5eaa7a3-sdk/static/js/remoteEntry.js'
    