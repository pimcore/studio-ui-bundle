
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/fc863ace9b68-sdk/static/js/remoteEntry.js'
    