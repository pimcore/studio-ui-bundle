
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/fdb5273764bc-sdk/static/js/remoteEntry.js'
    