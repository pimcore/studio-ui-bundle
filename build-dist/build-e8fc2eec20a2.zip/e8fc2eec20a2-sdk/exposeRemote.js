
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/e8fc2eec20a2-sdk/static/js/remoteEntry.js'
    