
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/97a16eb95df4-sdk/static/js/remoteEntry.js'
    