
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/6e2aab10c66f-sdk/static/js/remoteEntry.js'
    