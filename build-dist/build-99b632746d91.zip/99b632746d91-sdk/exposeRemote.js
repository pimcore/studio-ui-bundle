
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/99b632746d91-sdk/static/js/remoteEntry.js'
    