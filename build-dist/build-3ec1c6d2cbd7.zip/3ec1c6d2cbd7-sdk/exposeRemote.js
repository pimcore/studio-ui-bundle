
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/3ec1c6d2cbd7-sdk/static/js/remoteEntry.js'
    