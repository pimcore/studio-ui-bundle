
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/572fb8497c37-sdk/static/js/remoteEntry.js'
    