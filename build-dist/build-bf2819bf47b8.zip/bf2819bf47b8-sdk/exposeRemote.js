
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/bf2819bf47b8-sdk/static/js/remoteEntry.js'
    