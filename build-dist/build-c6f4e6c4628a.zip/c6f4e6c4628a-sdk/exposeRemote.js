
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/c6f4e6c4628a-sdk/static/js/remoteEntry.js'
    