
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/f2d8464ef8e6-sdk/static/js/remoteEntry.js'
    