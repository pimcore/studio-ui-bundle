
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/88d542840da4-sdk/static/js/remoteEntry.js'
    