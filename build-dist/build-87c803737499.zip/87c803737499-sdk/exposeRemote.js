
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/87c803737499-sdk/static/js/remoteEntry.js'
    