
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/13edd9a9bc50-sdk/static/js/remoteEntry.js'
    