
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/e27178d4e630-sdk/static/js/remoteEntry.js'
    