
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/38084af5da17-sdk/static/js/remoteEntry.js'
    