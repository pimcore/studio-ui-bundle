
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/d18b7d73d0ed-sdk/static/js/remoteEntry.js'
    