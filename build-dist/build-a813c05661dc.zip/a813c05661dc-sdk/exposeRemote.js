
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/a813c05661dc-sdk/static/js/remoteEntry.js'
    