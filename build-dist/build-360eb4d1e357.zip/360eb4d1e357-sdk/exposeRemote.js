
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/360eb4d1e357-sdk/static/js/remoteEntry.js'
    