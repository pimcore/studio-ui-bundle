
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/6cf361984e6e-sdk/static/js/remoteEntry.js'
    