
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/2c4a364ec789-sdk/static/js/remoteEntry.js'
    