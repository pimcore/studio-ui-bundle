
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/50968d3d0ae5-sdk/static/js/remoteEntry.js'
    