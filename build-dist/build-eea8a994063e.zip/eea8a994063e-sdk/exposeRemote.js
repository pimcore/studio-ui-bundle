
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/eea8a994063e-sdk/static/js/remoteEntry.js'
    