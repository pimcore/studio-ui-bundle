
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/531362bfacb6-sdk/static/js/remoteEntry.js'
    