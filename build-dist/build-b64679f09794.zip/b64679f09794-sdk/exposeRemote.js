
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/b64679f09794-sdk/static/js/remoteEntry.js'
    