
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/f240540a5237-sdk/static/js/remoteEntry.js'
    