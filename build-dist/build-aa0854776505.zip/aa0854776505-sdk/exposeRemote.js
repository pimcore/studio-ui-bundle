
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/aa0854776505-sdk/static/js/remoteEntry.js'
    