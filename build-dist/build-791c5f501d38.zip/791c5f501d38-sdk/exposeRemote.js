
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/791c5f501d38-sdk/static/js/remoteEntry.js'
    