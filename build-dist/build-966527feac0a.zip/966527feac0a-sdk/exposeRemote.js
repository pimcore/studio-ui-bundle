
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/966527feac0a-sdk/static/js/remoteEntry.js'
    