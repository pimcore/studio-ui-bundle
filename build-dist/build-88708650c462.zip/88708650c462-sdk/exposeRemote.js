
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/88708650c462-sdk/static/js/remoteEntry.js'
    