
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/0e34faabd750-sdk/static/js/remoteEntry.js'
    