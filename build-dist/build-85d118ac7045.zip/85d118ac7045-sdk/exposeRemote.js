
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/85d118ac7045-sdk/static/js/remoteEntry.js'
    