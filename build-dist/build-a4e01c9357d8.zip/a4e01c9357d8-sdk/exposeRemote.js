
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/a4e01c9357d8-sdk/static/js/remoteEntry.js'
    