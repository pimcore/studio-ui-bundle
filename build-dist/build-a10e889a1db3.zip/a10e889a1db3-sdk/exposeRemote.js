
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/a10e889a1db3-sdk/static/js/remoteEntry.js'
    