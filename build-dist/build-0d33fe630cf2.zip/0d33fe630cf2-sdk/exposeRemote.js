
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/0d33fe630cf2-sdk/static/js/remoteEntry.js'
    