
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/0ce06727c1db-sdk/static/js/remoteEntry.js'
    