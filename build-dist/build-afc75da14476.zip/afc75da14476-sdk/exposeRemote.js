
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/afc75da14476-sdk/static/js/remoteEntry.js'
    