
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/dd4a50382310-sdk/static/js/remoteEntry.js'
    