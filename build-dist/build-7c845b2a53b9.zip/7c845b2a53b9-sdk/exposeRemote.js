
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/7c845b2a53b9-sdk/static/js/remoteEntry.js'
    