
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/aaa19d50c6db-sdk/static/js/remoteEntry.js'
    