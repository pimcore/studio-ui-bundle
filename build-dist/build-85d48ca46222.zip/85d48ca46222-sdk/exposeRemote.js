
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/85d48ca46222-sdk/static/js/remoteEntry.js'
    