
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/c294c552a87c-sdk/static/js/remoteEntry.js'
    