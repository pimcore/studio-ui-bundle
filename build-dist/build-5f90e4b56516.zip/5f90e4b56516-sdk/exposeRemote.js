
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/5f90e4b56516-sdk/static/js/remoteEntry.js'
    