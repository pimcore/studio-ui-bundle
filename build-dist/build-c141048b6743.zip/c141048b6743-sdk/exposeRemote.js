
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/c141048b6743-sdk/static/js/remoteEntry.js'
    