
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/802668bd0efe-sdk/static/js/remoteEntry.js'
    