
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/4b683ed8edff-sdk/static/js/remoteEntry.js'
    