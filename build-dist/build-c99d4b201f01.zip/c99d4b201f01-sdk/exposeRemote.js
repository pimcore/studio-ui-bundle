
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/c99d4b201f01-sdk/static/js/remoteEntry.js'
    