
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/fe5191d0255e-sdk/static/js/remoteEntry.js'
    