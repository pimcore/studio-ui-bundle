
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/2f0d8b02ff3e-sdk/static/js/remoteEntry.js'
    