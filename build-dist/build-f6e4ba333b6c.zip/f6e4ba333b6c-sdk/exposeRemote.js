
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/f6e4ba333b6c-sdk/static/js/remoteEntry.js'
    