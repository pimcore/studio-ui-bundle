
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/d91e5f473af4-sdk/static/js/remoteEntry.js'
    