
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/e4f9d10907b8-sdk/static/js/remoteEntry.js'
    