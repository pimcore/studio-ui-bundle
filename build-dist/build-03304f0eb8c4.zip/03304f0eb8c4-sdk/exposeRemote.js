
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/03304f0eb8c4-sdk/static/js/remoteEntry.js'
    