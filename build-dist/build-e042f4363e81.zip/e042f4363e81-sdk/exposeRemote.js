
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/e042f4363e81-sdk/static/js/remoteEntry.js'
    