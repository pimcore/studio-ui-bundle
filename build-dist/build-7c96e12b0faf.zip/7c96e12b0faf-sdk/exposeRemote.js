
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/7c96e12b0faf-sdk/static/js/remoteEntry.js'
    