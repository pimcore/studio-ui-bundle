
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/eaa86ebcba85-sdk/static/js/remoteEntry.js'
    