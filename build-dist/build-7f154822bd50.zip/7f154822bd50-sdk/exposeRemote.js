
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/7f154822bd50-sdk/static/js/remoteEntry.js'
    