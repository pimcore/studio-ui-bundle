
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/9547cc4c09e5-sdk/static/js/remoteEntry.js'
    