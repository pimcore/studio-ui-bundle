
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/2f6812beb380-sdk/static/js/remoteEntry.js'
    