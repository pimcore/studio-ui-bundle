
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/dee6eb6e7c12-sdk/static/js/remoteEntry.js'
    