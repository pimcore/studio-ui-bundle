
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/947cab15b29a-sdk/static/js/remoteEntry.js'
    