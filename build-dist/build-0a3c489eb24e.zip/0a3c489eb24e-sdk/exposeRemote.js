
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/0a3c489eb24e-sdk/static/js/remoteEntry.js'
    