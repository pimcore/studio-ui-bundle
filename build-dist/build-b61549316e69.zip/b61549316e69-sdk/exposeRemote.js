
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/b61549316e69-sdk/static/js/remoteEntry.js'
    