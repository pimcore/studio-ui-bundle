
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/aca25dcaea41-sdk/static/js/remoteEntry.js'
    