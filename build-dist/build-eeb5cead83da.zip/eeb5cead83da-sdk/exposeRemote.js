
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/eeb5cead83da-sdk/static/js/remoteEntry.js'
    