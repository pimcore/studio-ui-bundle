
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/28b25de85084-sdk/static/js/remoteEntry.js'
    