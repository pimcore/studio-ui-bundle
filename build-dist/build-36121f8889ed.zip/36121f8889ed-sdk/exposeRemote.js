
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/36121f8889ed-sdk/static/js/remoteEntry.js'
    