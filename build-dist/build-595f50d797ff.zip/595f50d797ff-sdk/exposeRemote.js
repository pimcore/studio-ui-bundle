
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/595f50d797ff-sdk/static/js/remoteEntry.js'
    