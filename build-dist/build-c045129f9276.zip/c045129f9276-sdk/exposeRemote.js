
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/c045129f9276-sdk/static/js/remoteEntry.js'
    