
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/776e70f6f5f6-sdk/static/js/remoteEntry.js'
    