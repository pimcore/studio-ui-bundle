
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/579912b48489-sdk/static/js/remoteEntry.js'
    