
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/ab94796ebbc6-sdk/static/js/remoteEntry.js'
    