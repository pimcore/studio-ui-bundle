
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/97865878754c-sdk/static/js/remoteEntry.js'
    