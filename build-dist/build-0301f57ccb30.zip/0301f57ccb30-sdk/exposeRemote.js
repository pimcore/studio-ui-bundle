
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/0301f57ccb30-sdk/static/js/remoteEntry.js'
    