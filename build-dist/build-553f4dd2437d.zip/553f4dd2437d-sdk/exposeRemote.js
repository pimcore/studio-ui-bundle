
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/553f4dd2437d-sdk/static/js/remoteEntry.js'
    