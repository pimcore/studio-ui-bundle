
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/e577d5d8d5e0-sdk/static/js/remoteEntry.js'
    