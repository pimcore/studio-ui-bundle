
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/8f41390c9f32-sdk/static/js/remoteEntry.js'
    