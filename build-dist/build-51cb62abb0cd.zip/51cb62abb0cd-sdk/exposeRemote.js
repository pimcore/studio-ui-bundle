
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/51cb62abb0cd-sdk/static/js/remoteEntry.js'
    