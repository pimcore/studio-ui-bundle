
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/9bb965bd4d02-sdk/static/js/remoteEntry.js'
    