
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/04998c951fba-sdk/static/js/remoteEntry.js'
    