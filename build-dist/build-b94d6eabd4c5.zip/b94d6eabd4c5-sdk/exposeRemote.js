
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/b94d6eabd4c5-sdk/static/js/remoteEntry.js'
    