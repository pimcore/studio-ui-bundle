
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/d39bd0f95b58-sdk/static/js/remoteEntry.js'
    