
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/444962bafa40-sdk/static/js/remoteEntry.js'
    