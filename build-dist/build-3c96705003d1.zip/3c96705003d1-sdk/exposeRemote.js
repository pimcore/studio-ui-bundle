
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/3c96705003d1-sdk/static/js/remoteEntry.js'
    