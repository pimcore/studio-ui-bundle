
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/01a8a780a5a0-sdk/static/js/remoteEntry.js'
    