
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/89b0313eb190-sdk/static/js/remoteEntry.js'
    