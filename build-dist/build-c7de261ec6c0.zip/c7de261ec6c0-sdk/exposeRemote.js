
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/c7de261ec6c0-sdk/static/js/remoteEntry.js'
    