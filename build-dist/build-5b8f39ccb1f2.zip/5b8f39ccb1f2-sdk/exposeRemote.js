
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/5b8f39ccb1f2-sdk/static/js/remoteEntry.js'
    