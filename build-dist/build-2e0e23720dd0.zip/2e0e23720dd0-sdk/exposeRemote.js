
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/2e0e23720dd0-sdk/static/js/remoteEntry.js'
    