
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/5b5326ab09cc-sdk/static/js/remoteEntry.js'
    