
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/ed69fa853eb8-sdk/static/js/remoteEntry.js'
    