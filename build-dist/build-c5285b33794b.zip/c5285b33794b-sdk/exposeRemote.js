
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/c5285b33794b-sdk/static/js/remoteEntry.js'
    