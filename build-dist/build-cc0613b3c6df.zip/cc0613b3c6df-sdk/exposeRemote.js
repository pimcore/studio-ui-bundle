
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/cc0613b3c6df-sdk/static/js/remoteEntry.js'
    