
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/0e557bdb57db-sdk/static/js/remoteEntry.js'
    