
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/b80e8298b582-sdk/static/js/remoteEntry.js'
    