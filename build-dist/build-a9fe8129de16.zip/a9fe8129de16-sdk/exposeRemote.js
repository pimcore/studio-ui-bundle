
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/a9fe8129de16-sdk/static/js/remoteEntry.js'
    