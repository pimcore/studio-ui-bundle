
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/fca7888afa94-sdk/static/js/remoteEntry.js'
    