
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/4014177acb48-sdk/static/js/remoteEntry.js'
    