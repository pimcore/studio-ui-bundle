
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/eaad2f539b91-sdk/static/js/remoteEntry.js'
    