
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/de3483371a83-sdk/static/js/remoteEntry.js'
    