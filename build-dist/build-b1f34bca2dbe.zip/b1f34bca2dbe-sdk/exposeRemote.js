
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/b1f34bca2dbe-sdk/static/js/remoteEntry.js'
    