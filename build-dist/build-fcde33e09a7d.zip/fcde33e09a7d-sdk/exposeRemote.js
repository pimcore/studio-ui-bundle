
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/fcde33e09a7d-sdk/static/js/remoteEntry.js'
    