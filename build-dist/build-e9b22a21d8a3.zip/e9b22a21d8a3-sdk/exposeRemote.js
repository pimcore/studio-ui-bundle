
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/e9b22a21d8a3-sdk/static/js/remoteEntry.js'
    