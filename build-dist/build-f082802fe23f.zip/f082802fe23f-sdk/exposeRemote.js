
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/f082802fe23f-sdk/static/js/remoteEntry.js'
    