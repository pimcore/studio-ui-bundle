
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/9cce7feba036-sdk/static/js/remoteEntry.js'
    