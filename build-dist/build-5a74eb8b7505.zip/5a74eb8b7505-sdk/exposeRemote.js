
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/5a74eb8b7505-sdk/static/js/remoteEntry.js'
    