
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/f613872c2c2e-sdk/static/js/remoteEntry.js'
    