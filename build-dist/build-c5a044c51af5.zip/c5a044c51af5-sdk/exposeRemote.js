
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/c5a044c51af5-sdk/static/js/remoteEntry.js'
    