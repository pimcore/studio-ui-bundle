
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/24378edb5b59-sdk/static/js/remoteEntry.js'
    