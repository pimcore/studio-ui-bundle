
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/516020046bf8-sdk/static/js/remoteEntry.js'
    