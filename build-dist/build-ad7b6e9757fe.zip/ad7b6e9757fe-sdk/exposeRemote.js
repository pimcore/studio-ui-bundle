
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/ad7b6e9757fe-sdk/static/js/remoteEntry.js'
    