
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/91a908a30b0f-sdk/static/js/remoteEntry.js'
    