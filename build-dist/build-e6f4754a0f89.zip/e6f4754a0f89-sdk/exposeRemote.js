
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/e6f4754a0f89-sdk/static/js/remoteEntry.js'
    