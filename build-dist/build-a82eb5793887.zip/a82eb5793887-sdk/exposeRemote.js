
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/a82eb5793887-sdk/static/js/remoteEntry.js'
    