
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/d35ee5d043c2-sdk/static/js/remoteEntry.js'
    