
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/9a60731a45d9-sdk/static/js/remoteEntry.js'
    