
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/cdb4f87c04af-sdk/static/js/remoteEntry.js'
    