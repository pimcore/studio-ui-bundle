
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/dfb62fbe3f57-sdk/static/js/remoteEntry.js'
    