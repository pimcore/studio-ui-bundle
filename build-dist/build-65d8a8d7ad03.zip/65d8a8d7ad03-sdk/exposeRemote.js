
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/65d8a8d7ad03-sdk/static/js/remoteEntry.js'
    