
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/d639ac97499f-sdk/static/js/remoteEntry.js'
    