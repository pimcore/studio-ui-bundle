
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/1eb9024b9b75-sdk/static/js/remoteEntry.js'
    