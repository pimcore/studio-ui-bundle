
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/09008c0b5874-sdk/static/js/remoteEntry.js'
    