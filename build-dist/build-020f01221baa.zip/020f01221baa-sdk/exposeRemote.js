
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/020f01221baa-sdk/static/js/remoteEntry.js'
    