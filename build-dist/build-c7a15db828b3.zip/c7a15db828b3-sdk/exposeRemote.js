
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/c7a15db828b3-sdk/static/js/remoteEntry.js'
    