
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/8f04cc1c4814-sdk/static/js/remoteEntry.js'
    