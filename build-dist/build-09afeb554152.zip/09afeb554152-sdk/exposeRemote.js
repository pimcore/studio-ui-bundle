
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/09afeb554152-sdk/static/js/remoteEntry.js'
    