
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/75c542177eb5-sdk/static/js/remoteEntry.js'
    