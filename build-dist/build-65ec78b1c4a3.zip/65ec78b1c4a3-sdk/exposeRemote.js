
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/65ec78b1c4a3-sdk/static/js/remoteEntry.js'
    