
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/035d8f4f880c-sdk/static/js/remoteEntry.js'
    