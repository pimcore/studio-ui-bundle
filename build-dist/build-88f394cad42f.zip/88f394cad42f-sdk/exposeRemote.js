
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/88f394cad42f-sdk/static/js/remoteEntry.js'
    