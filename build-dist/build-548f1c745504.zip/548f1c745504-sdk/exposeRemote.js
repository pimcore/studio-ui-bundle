
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/548f1c745504-sdk/static/js/remoteEntry.js'
    