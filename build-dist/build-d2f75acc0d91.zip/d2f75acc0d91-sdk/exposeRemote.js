
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/d2f75acc0d91-sdk/static/js/remoteEntry.js'
    