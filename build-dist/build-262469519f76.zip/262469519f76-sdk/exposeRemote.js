
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/262469519f76-sdk/static/js/remoteEntry.js'
    