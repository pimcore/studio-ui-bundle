
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/a3030c98470e-sdk/static/js/remoteEntry.js'
    