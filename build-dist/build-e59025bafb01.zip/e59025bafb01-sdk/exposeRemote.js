
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/e59025bafb01-sdk/static/js/remoteEntry.js'
    