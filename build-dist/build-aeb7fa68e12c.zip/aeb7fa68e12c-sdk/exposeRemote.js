
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/aeb7fa68e12c-sdk/static/js/remoteEntry.js'
    