
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/0302aadb5511-sdk/static/js/remoteEntry.js'
    