
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/e137320cb63d-sdk/static/js/remoteEntry.js'
    