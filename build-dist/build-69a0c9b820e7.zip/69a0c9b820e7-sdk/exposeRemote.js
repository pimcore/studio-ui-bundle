
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/69a0c9b820e7-sdk/static/js/remoteEntry.js'
    