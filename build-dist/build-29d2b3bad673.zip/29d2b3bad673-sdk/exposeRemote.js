
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/29d2b3bad673-sdk/static/js/remoteEntry.js'
    