
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/a700276775ee-sdk/static/js/remoteEntry.js'
    