
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/eb9efc2f071f-sdk/static/js/remoteEntry.js'
    