
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/ae25090aa68c-sdk/static/js/remoteEntry.js'
    