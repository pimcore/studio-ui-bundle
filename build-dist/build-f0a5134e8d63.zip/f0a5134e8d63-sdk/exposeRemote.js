
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/f0a5134e8d63-sdk/static/js/remoteEntry.js'
    