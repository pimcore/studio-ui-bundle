
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/ec21a8486f07-sdk/static/js/remoteEntry.js'
    