
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/026004de3f8b-sdk/static/js/remoteEntry.js'
    