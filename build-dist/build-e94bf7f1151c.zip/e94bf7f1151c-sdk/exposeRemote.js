
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/e94bf7f1151c-sdk/static/js/remoteEntry.js'
    