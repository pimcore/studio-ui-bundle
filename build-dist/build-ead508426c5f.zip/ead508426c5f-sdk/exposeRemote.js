
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/ead508426c5f-sdk/static/js/remoteEntry.js'
    