
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/450875ccb33c-sdk/static/js/remoteEntry.js'
    