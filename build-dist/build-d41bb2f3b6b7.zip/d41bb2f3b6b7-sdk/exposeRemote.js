
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/d41bb2f3b6b7-sdk/static/js/remoteEntry.js'
    