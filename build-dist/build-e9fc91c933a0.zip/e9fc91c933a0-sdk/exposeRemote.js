
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/e9fc91c933a0-sdk/static/js/remoteEntry.js'
    