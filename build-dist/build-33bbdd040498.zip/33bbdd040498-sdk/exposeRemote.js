
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/33bbdd040498-sdk/static/js/remoteEntry.js'
    