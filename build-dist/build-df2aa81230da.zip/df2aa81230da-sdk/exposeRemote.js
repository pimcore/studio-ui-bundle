
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/df2aa81230da-sdk/static/js/remoteEntry.js'
    