
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/d4d16667be1b-sdk/static/js/remoteEntry.js'
    