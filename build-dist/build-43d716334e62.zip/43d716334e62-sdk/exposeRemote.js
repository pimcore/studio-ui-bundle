
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/43d716334e62-sdk/static/js/remoteEntry.js'
    