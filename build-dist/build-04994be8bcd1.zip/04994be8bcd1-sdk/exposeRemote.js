
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/04994be8bcd1-sdk/static/js/remoteEntry.js'
    