
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/4f44e7ad3174-sdk/static/js/remoteEntry.js'
    