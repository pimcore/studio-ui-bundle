
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/cfdd30371d02-sdk/static/js/remoteEntry.js'
    