
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/1baf05b66f4a-sdk/static/js/remoteEntry.js'
    