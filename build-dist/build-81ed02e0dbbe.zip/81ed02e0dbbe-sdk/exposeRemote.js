
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/81ed02e0dbbe-sdk/static/js/remoteEntry.js'
    