
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/50d19e526ddc-sdk/static/js/remoteEntry.js'
    