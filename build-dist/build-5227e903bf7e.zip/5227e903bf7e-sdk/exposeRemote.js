
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/5227e903bf7e-sdk/static/js/remoteEntry.js'
    