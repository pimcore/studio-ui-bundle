
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/4329a9eecd40-sdk/static/js/remoteEntry.js'
    