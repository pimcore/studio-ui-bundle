
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/6566bb637a95-sdk/static/js/remoteEntry.js'
    