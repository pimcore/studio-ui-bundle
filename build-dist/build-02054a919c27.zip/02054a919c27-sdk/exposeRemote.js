
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/02054a919c27-sdk/static/js/remoteEntry.js'
    