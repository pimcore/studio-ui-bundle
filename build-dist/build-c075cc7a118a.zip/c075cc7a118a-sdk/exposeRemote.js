
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/c075cc7a118a-sdk/static/js/remoteEntry.js'
    