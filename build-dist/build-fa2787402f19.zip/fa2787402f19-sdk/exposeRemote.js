
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/fa2787402f19-sdk/static/js/remoteEntry.js'
    