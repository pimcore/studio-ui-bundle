
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/f8e4f6fd5505-sdk/static/js/remoteEntry.js'
    