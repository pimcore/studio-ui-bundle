
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/7747feef1560-sdk/static/js/remoteEntry.js'
    