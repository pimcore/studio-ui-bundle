
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/8f2c0dfc9283-sdk/static/js/remoteEntry.js'
    