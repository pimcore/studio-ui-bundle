
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/458376966ad3-sdk/static/js/remoteEntry.js'
    