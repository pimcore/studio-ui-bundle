
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/59f7f6bda509-sdk/static/js/remoteEntry.js'
    