
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/2be8f488902c-sdk/static/js/remoteEntry.js'
    