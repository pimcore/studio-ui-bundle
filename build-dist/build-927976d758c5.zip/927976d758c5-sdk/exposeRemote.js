
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/927976d758c5-sdk/static/js/remoteEntry.js'
    