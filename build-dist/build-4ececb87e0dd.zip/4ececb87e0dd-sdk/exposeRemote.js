
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/4ececb87e0dd-sdk/static/js/remoteEntry.js'
    