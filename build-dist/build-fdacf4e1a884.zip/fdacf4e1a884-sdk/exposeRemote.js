
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/fdacf4e1a884-sdk/static/js/remoteEntry.js'
    