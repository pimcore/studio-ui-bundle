
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/a3f98c857bc2-sdk/static/js/remoteEntry.js'
    