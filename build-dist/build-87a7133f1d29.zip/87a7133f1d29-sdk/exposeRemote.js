
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/87a7133f1d29-sdk/static/js/remoteEntry.js'
    