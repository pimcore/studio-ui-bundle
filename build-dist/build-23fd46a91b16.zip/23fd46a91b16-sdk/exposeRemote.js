
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/23fd46a91b16-sdk/static/js/remoteEntry.js'
    