
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/5960be14ad67-sdk/static/js/remoteEntry.js'
    