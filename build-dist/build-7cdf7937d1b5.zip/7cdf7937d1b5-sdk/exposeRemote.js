
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/7cdf7937d1b5-sdk/static/js/remoteEntry.js'
    