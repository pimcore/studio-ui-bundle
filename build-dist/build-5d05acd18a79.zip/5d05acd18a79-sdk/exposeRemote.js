
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/5d05acd18a79-sdk/static/js/remoteEntry.js'
    