
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/5e91a1553350-sdk/static/js/remoteEntry.js'
    