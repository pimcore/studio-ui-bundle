
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/f385b47662eb-sdk/static/js/remoteEntry.js'
    