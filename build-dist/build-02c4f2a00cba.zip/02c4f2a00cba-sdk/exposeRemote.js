
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/02c4f2a00cba-sdk/static/js/remoteEntry.js'
    