
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/90265b2ed92c-sdk/static/js/remoteEntry.js'
    