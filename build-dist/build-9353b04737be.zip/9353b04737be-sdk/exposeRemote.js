
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/9353b04737be-sdk/static/js/remoteEntry.js'
    