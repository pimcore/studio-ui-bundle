
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/bbcf347e3173-sdk/static/js/remoteEntry.js'
    