
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/39bf6735356a-sdk/static/js/remoteEntry.js'
    