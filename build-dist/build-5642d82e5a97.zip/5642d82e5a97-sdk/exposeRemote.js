
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/5642d82e5a97-sdk/static/js/remoteEntry.js'
    