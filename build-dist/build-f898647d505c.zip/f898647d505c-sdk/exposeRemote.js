
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/f898647d505c-sdk/static/js/remoteEntry.js'
    