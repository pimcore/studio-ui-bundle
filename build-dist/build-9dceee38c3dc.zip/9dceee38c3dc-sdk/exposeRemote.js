
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/9dceee38c3dc-sdk/static/js/remoteEntry.js'
    