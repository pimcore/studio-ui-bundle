
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/74aa91e635d1-sdk/static/js/remoteEntry.js'
    