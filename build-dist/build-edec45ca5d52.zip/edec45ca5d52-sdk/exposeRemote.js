
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/edec45ca5d52-sdk/static/js/remoteEntry.js'
    