
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/62b45f21946e-sdk/static/js/remoteEntry.js'
    