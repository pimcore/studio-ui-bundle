
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/96b42875219f-sdk/static/js/remoteEntry.js'
    