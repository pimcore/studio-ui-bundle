
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/e6a2eafc3250-sdk/static/js/remoteEntry.js'
    