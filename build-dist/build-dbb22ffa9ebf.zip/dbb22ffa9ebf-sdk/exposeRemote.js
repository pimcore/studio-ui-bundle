
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/dbb22ffa9ebf-sdk/static/js/remoteEntry.js'
    