
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/1af8f6fd6324-sdk/static/js/remoteEntry.js'
    