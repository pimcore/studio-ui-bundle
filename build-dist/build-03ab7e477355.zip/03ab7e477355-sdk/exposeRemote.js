
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/03ab7e477355-sdk/static/js/remoteEntry.js'
    