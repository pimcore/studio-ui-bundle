
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/e74dce75b5b2-sdk/static/js/remoteEntry.js'
    