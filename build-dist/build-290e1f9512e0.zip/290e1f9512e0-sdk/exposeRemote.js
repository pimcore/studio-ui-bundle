
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/290e1f9512e0-sdk/static/js/remoteEntry.js'
    