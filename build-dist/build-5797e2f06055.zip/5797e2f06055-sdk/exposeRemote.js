
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/5797e2f06055-sdk/static/js/remoteEntry.js'
    