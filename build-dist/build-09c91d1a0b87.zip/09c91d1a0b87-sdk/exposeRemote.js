
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/09c91d1a0b87-sdk/static/js/remoteEntry.js'
    