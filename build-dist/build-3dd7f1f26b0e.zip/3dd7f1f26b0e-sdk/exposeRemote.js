
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/3dd7f1f26b0e-sdk/static/js/remoteEntry.js'
    