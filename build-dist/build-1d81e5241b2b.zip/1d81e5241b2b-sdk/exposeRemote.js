
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/1d81e5241b2b-sdk/static/js/remoteEntry.js'
    