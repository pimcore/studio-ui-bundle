
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/d2e5c645beeb-sdk/static/js/remoteEntry.js'
    