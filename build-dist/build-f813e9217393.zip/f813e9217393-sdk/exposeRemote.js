
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/f813e9217393-sdk/static/js/remoteEntry.js'
    