
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/efc6b0465fcb-sdk/static/js/remoteEntry.js'
    