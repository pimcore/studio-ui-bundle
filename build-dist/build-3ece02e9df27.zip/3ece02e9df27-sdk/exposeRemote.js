
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/3ece02e9df27-sdk/static/js/remoteEntry.js'
    