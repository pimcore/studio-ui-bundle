
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/90767315f442-sdk/static/js/remoteEntry.js'
    