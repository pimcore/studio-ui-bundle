
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/5b41ddbd1ec5-sdk/static/js/remoteEntry.js'
    