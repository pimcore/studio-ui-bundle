
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/f00243b1f3e2-sdk/static/js/remoteEntry.js'
    