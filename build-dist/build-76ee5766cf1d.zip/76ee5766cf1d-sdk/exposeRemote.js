
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/76ee5766cf1d-sdk/static/js/remoteEntry.js'
    