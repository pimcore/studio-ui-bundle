
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/c91aa7302721-sdk/static/js/remoteEntry.js'
    