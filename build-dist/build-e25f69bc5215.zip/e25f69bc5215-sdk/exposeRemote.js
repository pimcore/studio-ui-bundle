
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/e25f69bc5215-sdk/static/js/remoteEntry.js'
    