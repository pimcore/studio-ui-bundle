
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/1c5b99d8bbf5-sdk/static/js/remoteEntry.js'
    