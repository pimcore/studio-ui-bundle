
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/c50964b88b7b-sdk/static/js/remoteEntry.js'
    