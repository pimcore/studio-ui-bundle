
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/aefc7a2c8813-sdk/static/js/remoteEntry.js'
    