
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/cbe30b4be881-sdk/static/js/remoteEntry.js'
    