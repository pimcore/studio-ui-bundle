
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/8f00a4d3b796-sdk/static/js/remoteEntry.js'
    