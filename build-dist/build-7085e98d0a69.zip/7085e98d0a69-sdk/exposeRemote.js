
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/7085e98d0a69-sdk/static/js/remoteEntry.js'
    