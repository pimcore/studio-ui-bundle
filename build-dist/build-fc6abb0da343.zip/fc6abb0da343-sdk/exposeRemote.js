
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/fc6abb0da343-sdk/static/js/remoteEntry.js'
    