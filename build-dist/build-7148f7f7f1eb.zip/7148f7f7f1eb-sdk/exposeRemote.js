
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/7148f7f7f1eb-sdk/static/js/remoteEntry.js'
    