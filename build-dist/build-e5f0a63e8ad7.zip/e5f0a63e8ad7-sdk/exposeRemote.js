
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/e5f0a63e8ad7-sdk/static/js/remoteEntry.js'
    