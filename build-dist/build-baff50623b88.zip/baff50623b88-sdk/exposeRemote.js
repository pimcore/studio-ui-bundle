
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/baff50623b88-sdk/static/js/remoteEntry.js'
    