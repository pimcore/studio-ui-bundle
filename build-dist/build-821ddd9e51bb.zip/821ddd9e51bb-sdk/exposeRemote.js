
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/821ddd9e51bb-sdk/static/js/remoteEntry.js'
    