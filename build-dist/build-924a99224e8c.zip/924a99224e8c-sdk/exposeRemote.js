
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/924a99224e8c-sdk/static/js/remoteEntry.js'
    