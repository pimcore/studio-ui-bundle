
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/ee6f40a04535-sdk/static/js/remoteEntry.js'
    