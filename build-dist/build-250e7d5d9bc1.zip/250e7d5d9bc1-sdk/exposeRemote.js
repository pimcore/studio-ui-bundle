
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/250e7d5d9bc1-sdk/static/js/remoteEntry.js'
    