
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/de0288213f0c-sdk/static/js/remoteEntry.js'
    