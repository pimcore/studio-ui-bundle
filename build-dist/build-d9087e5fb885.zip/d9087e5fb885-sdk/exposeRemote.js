
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/d9087e5fb885-sdk/static/js/remoteEntry.js'
    