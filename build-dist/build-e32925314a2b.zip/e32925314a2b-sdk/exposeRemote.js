
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/e32925314a2b-sdk/static/js/remoteEntry.js'
    