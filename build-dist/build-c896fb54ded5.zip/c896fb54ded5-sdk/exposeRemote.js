
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/c896fb54ded5-sdk/static/js/remoteEntry.js'
    