
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/736ea0dc05d3-sdk/static/js/remoteEntry.js'
    