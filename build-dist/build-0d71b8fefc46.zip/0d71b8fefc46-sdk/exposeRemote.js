
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/0d71b8fefc46-sdk/static/js/remoteEntry.js'
    