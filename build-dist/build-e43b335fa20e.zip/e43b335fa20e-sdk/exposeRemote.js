
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/e43b335fa20e-sdk/static/js/remoteEntry.js'
    