
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/02a2a273f2c2-sdk/static/js/remoteEntry.js'
    