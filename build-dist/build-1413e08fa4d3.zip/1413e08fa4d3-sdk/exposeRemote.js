
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/1413e08fa4d3-sdk/static/js/remoteEntry.js'
    