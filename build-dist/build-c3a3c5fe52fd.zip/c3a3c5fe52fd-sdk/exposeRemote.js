
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/c3a3c5fe52fd-sdk/static/js/remoteEntry.js'
    