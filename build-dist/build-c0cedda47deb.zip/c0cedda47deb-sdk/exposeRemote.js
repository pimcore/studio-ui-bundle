
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/c0cedda47deb-sdk/static/js/remoteEntry.js'
    