
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/5b8b15f91277-sdk/static/js/remoteEntry.js'
    