
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/12532d1e81d9-sdk/static/js/remoteEntry.js'
    