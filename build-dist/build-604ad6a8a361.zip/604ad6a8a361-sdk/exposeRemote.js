
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/604ad6a8a361-sdk/static/js/remoteEntry.js'
    