/*!
 * 
 *             /**
 *              * This source file is available under the terms of the
 *              * Pimcore Open Core License (POCL)
 *              * Full copyright and license information is available in
 *              * LICENSE.md which is distributed with this source code.
 *              *
 *              *  @copyright  Copyright (c) Pimcore GmbH (https://www.pimcore.com)
 *              *  @license    Pimcore Open Core License (POCL)
 *              * /
 *
 */
"use strict";
(self["chunk_pimcore_studio_ui_bundle "] = self["chunk_pimcore_studio_ui_bundle "] || []).push([["__federation_expose_modules__widget_manager"], {
"./js/src/core/modules/widget-manager/events/close-widget-events.ts"(module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
/* provided dependency */ var $ReactRefreshRuntime$ = __webpack_require__("./node_modules/@rspack/plugin-react-refresh/client/reactRefresh.js");
/**
 * This source file is available under the terms of the
 * Pimcore Open Core License (POCL)
 * Full copyright and license information is available in
 * LICENSE.md which is distributed with this source code.
 *
 *  @copyright  Copyright (c) Pimcore GmbH (https://www.pimcore.com)
 *  @license    Pimcore Open Core License (POCL)
 */ 

function $RefreshSig$() { return $ReactRefreshRuntime$.createSignatureFunctionForTransform() }
function $RefreshReg$(type, id) { $ReactRefreshRuntime$.register(type, module.id + "_" + id) }
Promise.resolve().then(() => { $ReactRefreshRuntime$.refresh(module.id, module.hot) });


},
"./js/src/core/modules/widget-manager/events/index.ts"(module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
/* import */ var _close_widget_events__rspack_import_0 = __webpack_require__("./js/src/core/modules/widget-manager/events/close-widget-events.ts");
/* provided dependency */ var $ReactRefreshRuntime$ = __webpack_require__("./node_modules/@rspack/plugin-react-refresh/client/reactRefresh.js");
/**
 * This source file is available under the terms of the
 * Pimcore Open Core License (POCL)
 * Full copyright and license information is available in
 * LICENSE.md which is distributed with this source code.
 *
 *  @copyright  Copyright (c) Pimcore GmbH (https://www.pimcore.com)
 *  @license    Pimcore Open Core License (POCL)
 */ 

function $RefreshSig$() { return $ReactRefreshRuntime$.createSignatureFunctionForTransform() }
function $RefreshReg$(type, id) { $ReactRefreshRuntime$.register(type, module.id + "_" + id) }
Promise.resolve().then(() => { $ReactRefreshRuntime$.refresh(module.id, module.hot) });


},
"./js/src/sdk/modules/widget-manager/index.ts"(module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  BorderTitleView: () => (/* reexport safe */ _Pimcore_modules_widget_manager_title_border_title_view__rspack_import_7.BorderTitleView),
  PerspectiveProcessorContext: () => (/* reexport safe */ _Pimcore_modules_widget_manager_services_processors_perspective_processor_registry__rspack_import_5.PerspectiveProcessorContext),
  PerspectiveProcessorRegistry: () => (/* reexport safe */ _Pimcore_modules_widget_manager_services_processors_perspective_processor_registry__rspack_import_5.PerspectiveProcessorRegistry),
  TabTitleContainer: () => (/* reexport safe */ _Pimcore_modules_widget_manager_title_tab_title_container__rspack_import_6.TabTitleContainer),
  TabTitleView: () => (/* reexport safe */ _Pimcore_modules_widget_manager_title_tab_title_view__rspack_import_8.TabTitleView),
  WidgetContentTitleView: () => (/* reexport safe */ _Pimcore_modules_widget_manager_widget_widget_content_title_view__rspack_import_9.WidgetContentTitleView),
  WidgetManagerActionService: () => (/* reexport safe */ _Pimcore_modules_widget_manager_services_widget_manager_action_service__rspack_import_2.WidgetManagerActionService),
  WidgetRegistry: () => (/* reexport safe */ _Pimcore_modules_widget_manager_services_widget_registry__rspack_import_1.WidgetRegistry),
  closeWidget: () => (/* reexport safe */ _Pimcore_modules_widget_manager_widget_manager_slice__rspack_import_3.closeWidget),
  initialState: () => (/* reexport safe */ _Pimcore_modules_widget_manager_widget_manager_slice__rspack_import_3.initialState),
  openBottomWidget: () => (/* reexport safe */ _Pimcore_modules_widget_manager_widget_manager_slice__rspack_import_3.openBottomWidget),
  openLeftWidget: () => (/* reexport safe */ _Pimcore_modules_widget_manager_widget_manager_slice__rspack_import_3.openLeftWidget),
  openMainWidget: () => (/* reexport safe */ _Pimcore_modules_widget_manager_widget_manager_slice__rspack_import_3.openMainWidget),
  openRightWidget: () => (/* reexport safe */ _Pimcore_modules_widget_manager_widget_manager_slice__rspack_import_3.openRightWidget),
  selectInnerModel: () => (/* reexport safe */ _Pimcore_modules_widget_manager_widget_manager_slice__rspack_import_3.selectInnerModel),
  selectMainWidgetContext: () => (/* reexport safe */ _Pimcore_modules_widget_manager_widget_manager_slice__rspack_import_3.selectMainWidgetContext),
  selectOuterModel: () => (/* reexport safe */ _Pimcore_modules_widget_manager_widget_manager_slice__rspack_import_3.selectOuterModel),
  selectWidgetManagerRestored: () => (/* reexport safe */ _Pimcore_modules_widget_manager_widget_manager_slice__rspack_import_3.selectWidgetManagerRestored),
  setActiveWidgetById: () => (/* reexport safe */ _Pimcore_modules_widget_manager_widget_manager_slice__rspack_import_3.setActiveWidgetById),
  setWidgetManagerRestored: () => (/* reexport safe */ _Pimcore_modules_widget_manager_widget_manager_slice__rspack_import_3.setWidgetManagerRestored),
  updateInnerModel: () => (/* reexport safe */ _Pimcore_modules_widget_manager_widget_manager_slice__rspack_import_3.updateInnerModel),
  updateMainWidgetContext: () => (/* reexport safe */ _Pimcore_modules_widget_manager_widget_manager_slice__rspack_import_3.updateMainWidgetContext),
  updateOuterModel: () => (/* reexport safe */ _Pimcore_modules_widget_manager_widget_manager_slice__rspack_import_3.updateOuterModel),
  updateWidget: () => (/* reexport safe */ _Pimcore_modules_widget_manager_widget_manager_slice__rspack_import_3.updateWidget),
  useWidgetManager: () => (/* reexport safe */ _Pimcore_modules_widget_manager_hooks_use_widget_manager__rspack_import_0.useWidgetManager),
  widgetManagerSliceName: () => (/* reexport safe */ _Pimcore_modules_widget_manager_widget_manager_slice__rspack_import_3.widgetManagerSliceName)
});
/* import */ var _Pimcore_modules_widget_manager_hooks_use_widget_manager__rspack_import_0 = __webpack_require__("./js/src/core/modules/widget-manager/hooks/use-widget-manager.ts");
/* import */ var _Pimcore_modules_widget_manager_services_widget_registry__rspack_import_1 = __webpack_require__("./js/src/core/modules/widget-manager/services/widget-registry.ts");
/* import */ var _Pimcore_modules_widget_manager_services_widget_manager_action_service__rspack_import_2 = __webpack_require__("./js/src/core/modules/widget-manager/services/widget-manager-action-service.ts");
/* import */ var _Pimcore_modules_widget_manager_widget_manager_slice__rspack_import_3 = __webpack_require__("./js/src/core/modules/widget-manager/widget-manager-slice.ts");
/* import */ var _Pimcore_modules_widget_manager_events__rspack_import_4 = __webpack_require__("./js/src/core/modules/widget-manager/events/index.ts");
/* import */ var _Pimcore_modules_widget_manager_services_processors_perspective_processor_registry__rspack_import_5 = __webpack_require__("./js/src/core/modules/widget-manager/services/processors/perspective-processor-registry.ts");
/* import */ var _Pimcore_modules_widget_manager_title_tab_title_container__rspack_import_6 = __webpack_require__("./js/src/core/modules/widget-manager/title/tab-title-container.tsx");
/* import */ var _Pimcore_modules_widget_manager_title_border_title_view__rspack_import_7 = __webpack_require__("./js/src/core/modules/widget-manager/title/border-title-view.tsx");
/* import */ var _Pimcore_modules_widget_manager_title_tab_title_view__rspack_import_8 = __webpack_require__("./js/src/core/modules/widget-manager/title/tab-title-view.tsx");
/* import */ var _Pimcore_modules_widget_manager_widget_widget_content_title_view__rspack_import_9 = __webpack_require__("./js/src/core/modules/widget-manager/widget/widget-content-title-view.tsx");
/* provided dependency */ var $ReactRefreshRuntime$ = __webpack_require__("./node_modules/@rspack/plugin-react-refresh/client/reactRefresh.js");
/**
 * This source file is available under the terms of the
 * Pimcore Open Core License (POCL)
 * Full copyright and license information is available in
 * LICENSE.md which is distributed with this source code.
 *
 *  @copyright  Copyright (c) Pimcore GmbH (https://www.pimcore.com)
 *  @license    Pimcore Open Core License (POCL)
 */ if (true) {
    module.hot.accept();
}





// Processor Registry for widget manipulation

// Components for titleComponent (tab/button titles)



// Components for contentTitleComponent (widget content headers)


function $RefreshSig$() { return $ReactRefreshRuntime$.createSignatureFunctionForTransform() }
function $RefreshReg$(type, id) { $ReactRefreshRuntime$.register(type, module.id + "_" + id) }
Promise.resolve().then(() => { $ReactRefreshRuntime$.refresh(module.id, module.hot) });


},
"./js/src/core/modules/widget-manager/widget/widget-content-title-view.tsx"(module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  WidgetContentTitleView: () => (WidgetContentTitleView)
});
/* import */ var react_jsx_dev_runtime__rspack_import_0 = __webpack_require__("./node_modules/react/jsx-dev-runtime.js");
/* import */ var react__rspack_import_1 = __webpack_require__("webpack/sharing/consume/default/react/react");
/* import */ var react__rspack_import_1_default = /*#__PURE__*/__webpack_require__.n(react__rspack_import_1);
/* import */ var _title_title_view__rspack_import_2 = __webpack_require__("./js/src/core/modules/widget-manager/widget/title/title-view.tsx");
/* provided dependency */ var $ReactRefreshRuntime$ = __webpack_require__("./node_modules/@rspack/plugin-react-refresh/client/reactRefresh.js");

/**
 * This source file is available under the terms of the
 * Pimcore Open Core License (POCL)
 * Full copyright and license information is available in
 * LICENSE.md which is distributed with this source code.
 *
 *  @copyright  Copyright (c) Pimcore GmbH (https://www.pimcore.com)
 *  @license    Pimcore Open Core License (POCL)
 */ 

/**
 * Widget content title view component for SDK usage.
 * Renders a TitleView with the provided title without translation.
 */ const WidgetContentTitleView = (param)=>{
    let { icon, title } = param;
    return /*#__PURE__*/ (0,react_jsx_dev_runtime__rspack_import_0.jsxDEV)(_title_title_view__rspack_import_2.TitleView, {
        className: "widget__title",
        icon: icon,
        title: title
    }, void 0, false, {
        fileName: "/Users/markusmoser/projects/demo-2026x/dev/pimcore/sui-classdef-sdk/assets/js/src/core/modules/widget-manager/widget/widget-content-title-view.tsx",
        lineNumber: 21,
        columnNumber: 10
    }, undefined);
};
_c = WidgetContentTitleView;
var _c;
$RefreshReg$(_c, "WidgetContentTitleView");

function $RefreshSig$() { return $ReactRefreshRuntime$.createSignatureFunctionForTransform() }
function $RefreshReg$(type, id) { $ReactRefreshRuntime$.register(type, module.id + "_" + id) }
Promise.resolve().then(() => { $ReactRefreshRuntime$.refresh(module.id, module.hot) });


},

}]);
//# sourceMappingURL=__federation_expose_modules__widget_manager.js.map