/*!
 * 
 *             /**
 *              * This source file is available under the terms of the
 *              * Pimcore Open Core License (POCL)
 *              * Full copyright and license information is available in
 *              * LICENSE.md which is distributed with this source code.
 *              *
 *              *  @copyright  Copyright (c) Pimcore GmbH (https://www.pimcore.com)
 *              *  @license    Pimcore Open Core License (POCL)
 *              * /
 *
 */
"use strict";
(self["chunk_pimcore_studio_ui_bundle "] = self["chunk_pimcore_studio_ui_bundle "] || []).push([["__federation_expose_modules__global_message_bus"], {
"./js/src/sdk/modules/global-message-bus/index.ts"(module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  AbstractMessageHandler: () => (/* reexport safe */ _Pimcore_modules_global_message_bus_message_handlers_abstract_message_handler__rspack_import_0.AbstractMessageHandler),
  GlobalMessageBus: () => (/* reexport safe */ _Pimcore_modules_global_message_bus_services_global_message_bus__rspack_import_1.GlobalMessageBus),
  GlobalMessageBusProcess: () => (/* reexport safe */ _Pimcore_modules_background_processor_process_global_message_bus_process__rspack_import_3.GlobalMessageBusProcess),
  useGlobalMessageBus: () => (/* reexport safe */ _Pimcore_modules_global_message_bus_hooks_use_global_message_bus__rspack_import_2.useGlobalMessageBus)
});
/* import */ var _Pimcore_modules_global_message_bus_message_handlers_abstract_message_handler__rspack_import_0 = __webpack_require__("./js/src/core/modules/global-message-bus/message-handlers/abstract-message-handler.ts");
/* import */ var _Pimcore_modules_global_message_bus_services_global_message_bus__rspack_import_1 = __webpack_require__("./js/src/core/modules/global-message-bus/services/global-message-bus.ts");
/* import */ var _Pimcore_modules_global_message_bus_hooks_use_global_message_bus__rspack_import_2 = __webpack_require__("./js/src/core/modules/global-message-bus/hooks/use-global-message-bus.ts");
/* import */ var _Pimcore_modules_background_processor_process_global_message_bus_process__rspack_import_3 = __webpack_require__("./js/src/core/modules/background-processor/process/global-message-bus-process.ts");
/* provided dependency */ var $ReactRefreshRuntime$ = __webpack_require__("./node_modules/@rspack/plugin-react-refresh/client/reactRefresh.js");
/**
 * This source file is available under the terms of the
 * Pimcore Open Core License (POCL)
 * Full copyright and license information is available in
 * LICENSE.md which is distributed with this source code.
 *
 *  @copyright  Copyright (c) Pimcore GmbH (https://www.pimcore.com)
 *  @license    Pimcore Open Core License (POCL)
 */ if (true) {
    module.hot.accept();
}





function $RefreshSig$() { return $ReactRefreshRuntime$.createSignatureFunctionForTransform() }
function $RefreshReg$(type, id) { $ReactRefreshRuntime$.register(type, module.id + "_" + id) }
Promise.resolve().then(() => { $ReactRefreshRuntime$.refresh(module.id, module.hot) });


},

}]);
//# sourceMappingURL=__federation_expose_modules__global_message_bus.js.map