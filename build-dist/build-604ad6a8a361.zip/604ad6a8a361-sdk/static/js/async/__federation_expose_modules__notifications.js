/*!
 * 
 *             /**
 *              * This source file is available under the terms of the
 *              * Pimcore Open Core License (POCL)
 *              * Full copyright and license information is available in
 *              * LICENSE.md which is distributed with this source code.
 *              *
 *              *  @copyright  Copyright (c) Pimcore GmbH (https://www.pimcore.com)
 *              *  @license    Pimcore Open Core License (POCL)
 *              * /
 *
 */
"use strict";
(self["chunk_pimcore_studio_ui_bundle "] = self["chunk_pimcore_studio_ui_bundle "] || []).push([["__federation_expose_modules__notifications"], {
"./js/src/sdk/modules/notifications/index.ts"(module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  DynamicTypeAbstractNotification: () => (/* reexport safe */ _Pimcore_modules_notifications_dynamic_types_definitions_dynamic_type_abstract_notification__rspack_import_2.DynamicTypeAbstractNotification),
  DynamicTypeAbstractNotificationChannel: () => (/* reexport safe */ _Pimcore_modules_notifications_dynamic_types_definitions_dynamic_type_abstract_notification_channel__rspack_import_3.DynamicTypeAbstractNotificationChannel),
  DynamicTypeNotificationChannelRegistry: () => (/* reexport safe */ _Pimcore_modules_notifications_dynamic_types_registry_dynamic_type_notification_channel_registry__rspack_import_5.DynamicTypeNotificationChannelRegistry),
  DynamicTypeNotificationRegistry: () => (/* reexport safe */ _Pimcore_modules_notifications_dynamic_types_registry_dynamic_type_notification_registry__rspack_import_4.DynamicTypeNotificationRegistry),
  NotificationApiSlice: () => (/* reexport module object */ _Pimcore_modules_notifications_notifications_slice_enhanced__rspack_import_1),
  NotificationList: () => (/* reexport safe */ _Pimcore_modules_notifications_notification_list__rspack_import_0.NotificationList),
  parseNotificationPayload: () => (/* reexport safe */ _Pimcore_modules_notifications_utils_notification_payload__rspack_import_6.parseNotificationPayload)
});
/* import */ var _Pimcore_modules_notifications_notification_list__rspack_import_0 = __webpack_require__("./js/src/core/modules/notifications/notification-list.tsx");
/* import */ var _Pimcore_modules_notifications_notifications_slice_enhanced__rspack_import_1 = __webpack_require__("./js/src/core/modules/notifications/notifications-slice-enhanced.ts");
/* import */ var _Pimcore_modules_notifications_dynamic_types_definitions_dynamic_type_abstract_notification__rspack_import_2 = __webpack_require__("./js/src/core/modules/notifications/dynamic-types/definitions/dynamic-type-abstract-notification.tsx");
/* import */ var _Pimcore_modules_notifications_dynamic_types_definitions_dynamic_type_abstract_notification_channel__rspack_import_3 = __webpack_require__("./js/src/core/modules/notifications/dynamic-types/definitions/dynamic-type-abstract-notification-channel.tsx");
/* import */ var _Pimcore_modules_notifications_dynamic_types_registry_dynamic_type_notification_registry__rspack_import_4 = __webpack_require__("./js/src/core/modules/notifications/dynamic-types/registry/dynamic-type-notification-registry.tsx");
/* import */ var _Pimcore_modules_notifications_dynamic_types_registry_dynamic_type_notification_channel_registry__rspack_import_5 = __webpack_require__("./js/src/core/modules/notifications/dynamic-types/registry/dynamic-type-notification-channel-registry.tsx");
/* import */ var _Pimcore_modules_notifications_utils_notification_payload__rspack_import_6 = __webpack_require__("./js/src/core/modules/notifications/utils/notification-payload.ts");
/* provided dependency */ var $ReactRefreshRuntime$ = __webpack_require__("./node_modules/@rspack/plugin-react-refresh/client/reactRefresh.js");
/**
 * This source file is available under the terms of the
 * Pimcore Open Core License (POCL)
 * Full copyright and license information is available in
 * LICENSE.md which is distributed with this source code.
 *
 *  @copyright  Copyright (c) Pimcore GmbH (https://www.pimcore.com)
 *  @license    Pimcore Open Core License (POCL)
 */ if (true) {
    module.hot.accept();
}



// Extension seams for bundles contributing notification types or delivery channels; register a
// definition in your module's onInit.






function $RefreshSig$() { return $ReactRefreshRuntime$.createSignatureFunctionForTransform() }
function $RefreshReg$(type, id) { $ReactRefreshRuntime$.register(type, module.id + "_" + id) }
Promise.resolve().then(() => { $ReactRefreshRuntime$.refresh(module.id, module.hot) });


},
"./js/src/core/modules/notifications/dynamic-types/definitions/dynamic-type-abstract-notification.tsx"(module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  DynamicTypeAbstractNotification: () => (DynamicTypeAbstractNotification)
});
/* import */ var inversify__rspack_import_0 = __webpack_require__("webpack/sharing/consume/default/inversify/inversify");
/* import */ var inversify__rspack_import_0_default = /*#__PURE__*/__webpack_require__.n(inversify__rspack_import_0);
/* import */ var _Pimcore_modules_element_dynamic_types_registry_dynamic_type_registry_abstract__rspack_import_1 = __webpack_require__("./js/src/core/modules/element/dynamic-types/registry/dynamic-type-registry-abstract.tsx");
/* provided dependency */ var $ReactRefreshRuntime$ = __webpack_require__("./node_modules/@rspack/plugin-react-refresh/client/reactRefresh.js");
var _dec, _class;
function _defineProperty(e, r, t) {
    return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, {
        value: t,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : e[r] = t, e;
}
function _toPropertyKey(t) {
    var i = _toPrimitive(t, "string");
    return "symbol" == typeof i ? i : i + "";
}
function _toPrimitive(t, r) {
    if ("object" != typeof t || !t) return t;
    var e = t[Symbol.toPrimitive];
    if (void 0 !== e) {
        var i = e.call(t, r || "default");
        if ("object" != typeof i) return i;
        throw new TypeError("@@toPrimitive must return a primitive value.");
    }
    return ("string" === r ? String : Number)(t);
}
/**
 * This source file is available under the terms of the
 * Pimcore Open Core License (POCL)
 * Full copyright and license information is available in
 * LICENSE.md which is distributed with this source code.
 *
 *  @copyright  Copyright (c) Pimcore GmbH (https://www.pimcore.com)
 *  @license    Pimcore Open Core License (POCL)
 */ 

/**
 * Renders a specific notification type. Either method may return null to fall back to the host's
 * plain title-and-sender rendering, so a definition can enrich only the detail view.
 */ let DynamicTypeAbstractNotification = (_dec = (0,inversify__rspack_import_0.injectable)(), _dec(_class = class DynamicTypeAbstractNotification extends _Pimcore_modules_element_dynamic_types_registry_dynamic_type_registry_abstract__rspack_import_1.DynamicTypeAbstract {
    /** Content for the toast; the host supplies the chrome and the action that opens the bell. */ getPopupContent(props) {
        return null;
    }
    /** Content for the expanded row in the notification list. */ getDetailContent(props, slots) {
        return null;
    }
    /** Whether the host appends the attachment below custom detail content. */ appendsAttachment() {
        return true;
    }
    constructor(...args){
        super(...args);
        /** The notification type id this definition renders. */ _defineProperty(this, "id", void 0);
    }
}) || _class);

function $RefreshSig$() { return $ReactRefreshRuntime$.createSignatureFunctionForTransform() }
function $RefreshReg$(type, id) { $ReactRefreshRuntime$.register(type, module.id + "_" + id) }
Promise.resolve().then(() => { $ReactRefreshRuntime$.refresh(module.id, module.hot) });


},

}]);
//# sourceMappingURL=__federation_expose_modules__notifications.js.map