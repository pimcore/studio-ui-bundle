/*!
 * 
 *             /**
 *              * This source file is available under the terms of the
 *              * Pimcore Open Core License (POCL)
 *              * Full copyright and license information is available in
 *              * LICENSE.md which is distributed with this source code.
 *              *
 *              *  @copyright  Copyright (c) Pimcore GmbH (https://www.pimcore.com)
 *              *  @license    Pimcore Open Core License (POCL)
 *              * /
 *
 */
"use strict";
(self["chunk_pimcore_studio_ui_bundle "] = self["chunk_pimcore_studio_ui_bundle "] || []).push([["__federation_expose_modules__translations"], {
"./js/src/sdk/modules/translations/index.ts"(module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  LanguageColumnHeader: () => (/* reexport safe */ _Pimcore_modules_translations_table_language_column_header__rspack_import_1.LanguageColumnHeader),
  useLanguageLookup: () => (/* reexport safe */ _Pimcore_modules_translations_hooks_use_language_lookup__rspack_import_0.useLanguageLookup)
});
/* import */ var _Pimcore_modules_translations_hooks_use_language_lookup__rspack_import_0 = __webpack_require__("./js/src/core/modules/translations/hooks/use-language-lookup.ts");
/* import */ var _Pimcore_modules_translations_table_language_column_header__rspack_import_1 = __webpack_require__("./js/src/core/modules/translations/table/language-column-header.tsx");
/* provided dependency */ var $ReactRefreshRuntime$ = __webpack_require__("./node_modules/@rspack/plugin-react-refresh/client/reactRefresh.js");
/**
 * This source file is available under the terms of the
 * Pimcore Open Core License (POCL)
 * Full copyright and license information is available in
 * LICENSE.md which is distributed with this source code.
 *
 *  @copyright  Copyright (c) Pimcore GmbH (https://www.pimcore.com)
 *  @license    Pimcore Open Core License (POCL)
 */ if (true) {
    module.hot.accept();
}



function $RefreshSig$() { return $ReactRefreshRuntime$.createSignatureFunctionForTransform() }
function $RefreshReg$(type, id) { $ReactRefreshRuntime$.register(type, module.id + "_" + id) }
Promise.resolve().then(() => { $ReactRefreshRuntime$.refresh(module.id, module.hot) });


},
"./js/src/core/modules/translations/table/language-column-header.tsx"(module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  LanguageColumnHeader: () => (LanguageColumnHeader)
});
/* import */ var react_jsx_dev_runtime__rspack_import_0 = __webpack_require__("./node_modules/react/jsx-dev-runtime.js");
/* import */ var react__rspack_import_1 = __webpack_require__("webpack/sharing/consume/default/react/react");
/* import */ var react__rspack_import_1_default = /*#__PURE__*/__webpack_require__.n(react__rspack_import_1);
/* import */ var _Pimcore_components_flag_icon_flag_icon__rspack_import_2 = __webpack_require__("./js/src/core/components/flag-icon/flag-icon.tsx");
/* provided dependency */ var $ReactRefreshRuntime$ = __webpack_require__("./node_modules/@rspack/plugin-react-refresh/client/reactRefresh.js");

/**
 * This source file is available under the terms of the
 * Pimcore Open Core License (POCL)
 * Full copyright and license information is available in
 * LICENSE.md which is distributed with this source code.
 *
 *  @copyright  Copyright (c) Pimcore GmbH (https://www.pimcore.com)
 *  @license    Pimcore Open Core License (POCL)
 */ 

const LanguageColumnHeader = (param)=>{
    let { language, display } = param;
    return /*#__PURE__*/ (0,react_jsx_dev_runtime__rspack_import_0.jsxDEV)("div", {
        style: {
            display: 'flex',
            alignItems: 'center',
            gap: '8px'
        },
        children: [
            /*#__PURE__*/ (0,react_jsx_dev_runtime__rspack_import_0.jsxDEV)(_Pimcore_components_flag_icon_flag_icon__rspack_import_2.FlagIcon, {
                value: language
            }, void 0, false, {
                fileName: "/Users/markusmoser/projects/demo-2026x/dev/pimcore/sui-classdef-sdk/assets/js/src/core/modules/translations/table/language-column-header.tsx",
                lineNumber: 22,
                columnNumber: 7
            }, undefined),
            /*#__PURE__*/ (0,react_jsx_dev_runtime__rspack_import_0.jsxDEV)("span", {
                children: display
            }, void 0, false, {
                fileName: "/Users/markusmoser/projects/demo-2026x/dev/pimcore/sui-classdef-sdk/assets/js/src/core/modules/translations/table/language-column-header.tsx",
                lineNumber: 23,
                columnNumber: 7
            }, undefined)
        ]
    }, void 0, true, {
        fileName: "/Users/markusmoser/projects/demo-2026x/dev/pimcore/sui-classdef-sdk/assets/js/src/core/modules/translations/table/language-column-header.tsx",
        lineNumber: 17,
        columnNumber: 10
    }, undefined);
};
_c = LanguageColumnHeader;
var _c;
$RefreshReg$(_c, "LanguageColumnHeader");

function $RefreshSig$() { return $ReactRefreshRuntime$.createSignatureFunctionForTransform() }
function $RefreshReg$(type, id) { $ReactRefreshRuntime$.register(type, module.id + "_" + id) }
Promise.resolve().then(() => { $ReactRefreshRuntime$.refresh(module.id, module.hot) });


},

}]);
//# sourceMappingURL=__federation_expose_modules__translations.js.map