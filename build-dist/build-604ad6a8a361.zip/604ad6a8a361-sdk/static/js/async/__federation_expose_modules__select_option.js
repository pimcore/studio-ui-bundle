/*!
 * 
 *             /**
 *              * This source file is available under the terms of the
 *              * Pimcore Open Core License (POCL)
 *              * Full copyright and license information is available in
 *              * LICENSE.md which is distributed with this source code.
 *              *
 *              *  @copyright  Copyright (c) Pimcore GmbH (https://www.pimcore.com)
 *              *  @license    Pimcore Open Core License (POCL)
 *              * /
 *
 */
"use strict";
(self["chunk_pimcore_studio_ui_bundle "] = self["chunk_pimcore_studio_ui_bundle "] || []).push([["__federation_expose_modules__select_option"], {
"./js/src/sdk/modules/select-option/index.ts"(module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  SelectOptionEntriesGrid: () => (/* reexport safe */ _Pimcore_modules_select_option_components_select_option_editor_select_option_entries_grid__rspack_import_1.SelectOptionEntriesGrid),
  SelectOptionGeneralSettingsFormFields: () => (/* reexport safe */ _Pimcore_modules_select_option_components_select_option_editor_general_settings_form_fields__rspack_import_0.SelectOptionGeneralSettingsFormFields)
});
/* import */ var _Pimcore_modules_select_option_components_select_option_editor_general_settings_form_fields__rspack_import_0 = __webpack_require__("./js/src/core/modules/select-option/components/select-option-editor/general-settings-form-fields.tsx");
/* import */ var _Pimcore_modules_select_option_components_select_option_editor_select_option_entries_grid__rspack_import_1 = __webpack_require__("./js/src/core/modules/select-option/components/select-option-editor/select-option-entries-grid.tsx");
/* provided dependency */ var $ReactRefreshRuntime$ = __webpack_require__("./node_modules/@rspack/plugin-react-refresh/client/reactRefresh.js");
/**
 * This source file is available under the terms of the
 * Pimcore Open Core License (POCL)
 * Full copyright and license information is available in
 * LICENSE.md which is distributed with this source code.
 *
 *  @copyright  Copyright (c) Pimcore GmbH (https://www.pimcore.com)
 *  @license    Pimcore Open Core License (POCL)
 */ 


function $RefreshSig$() { return $ReactRefreshRuntime$.createSignatureFunctionForTransform() }
function $RefreshReg$(type, id) { $ReactRefreshRuntime$.register(type, module.id + "_" + id) }
Promise.resolve().then(() => { $ReactRefreshRuntime$.refresh(module.id, module.hot) });


},

}]);
//# sourceMappingURL=__federation_expose_modules__select_option.js.map