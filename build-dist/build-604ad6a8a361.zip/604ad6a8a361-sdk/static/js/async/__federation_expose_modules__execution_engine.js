/*!
 * 
 *             /**
 *              * This source file is available under the terms of the
 *              * Pimcore Open Core License (POCL)
 *              * Full copyright and license information is available in
 *              * LICENSE.md which is distributed with this source code.
 *              *
 *              *  @copyright  Copyright (c) Pimcore GmbH (https://www.pimcore.com)
 *              *  @license    Pimcore Open Core License (POCL)
 *              * /
 *
 */
"use strict";
(self["chunk_pimcore_studio_ui_bundle "] = self["chunk_pimcore_studio_ui_bundle "] || []).push([["__federation_expose_modules__execution_engine"], {
"./js/src/core/modules/execution-engine/services/job-rehydration-registry.ts"(module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  JobRehydrationRegistry: () => (JobRehydrationRegistry)
});
/* import */ var _swc_helpers_ts_decorate__rspack_import_1 = __webpack_require__("./node_modules/tslib/tslib.es6.mjs");
/* import */ var inversify__rspack_import_0 = __webpack_require__("webpack/sharing/consume/default/inversify/inversify");
/* import */ var inversify__rspack_import_0_default = /*#__PURE__*/__webpack_require__.n(inversify__rspack_import_0);
/* provided dependency */ var $ReactRefreshRuntime$ = __webpack_require__("./node_modules/@rspack/plugin-react-refresh/client/reactRefresh.js");

/**
 * This source file is available under the terms of the
 * Pimcore Open Core License (POCL)
 * Full copyright and license information is available in
 * LICENSE.md which is distributed with this source code.
 *
 *  @copyright  Copyright (c) Pimcore GmbH (https://www.pimcore.com)
 *  @license    Pimcore Open Core License (POCL)
 */ 
class JobRehydrationRegistry {
    register(job) {
        for (const name of job.jobNames){
            this.registry.set(name, (jobRuns)=>job.rehydrate(jobRuns));
        }
    }
    get(jobName) {
        return this.registry.get(jobName);
    }
    constructor(){
        this.registry = new Map();
    }
}
JobRehydrationRegistry = (0,_swc_helpers_ts_decorate__rspack_import_1.__decorate)([
    (0,inversify__rspack_import_0.injectable)()
], JobRehydrationRegistry);

function $RefreshSig$() { return $ReactRefreshRuntime$.createSignatureFunctionForTransform() }
function $RefreshReg$(type, id) { $ReactRefreshRuntime$.register(type, module.id + "_" + id) }
Promise.resolve().then(() => { $ReactRefreshRuntime$.refresh(module.id, module.hot) });


},
"./js/src/sdk/modules/execution-engine/index.ts"(module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  JobRehydrationRegistry: () => (/* reexport safe */ _Pimcore_modules_execution_engine_services_job_rehydration_registry__rspack_import_5.JobRehydrationRegistry),
  JobStatus: () => (/* reexport safe */ _Pimcore_modules_execution_engine_jobs_abstact_job__rspack_import_1.JobStatus),
  MessageBusJobHandler: () => (/* reexport safe */ _Pimcore_modules_execution_engine_message_handlers_message_bus_job_message_bus_job_handler__rspack_import_2.MessageBusJobHandler),
  PROGRESS_NO_UPDATE: () => (/* reexport safe */ _Pimcore_modules_execution_engine_message_handlers_message_bus_job_progress_calculator_progress_calculator_interface__rspack_import_3.PROGRESS_NO_UPDATE),
  StepCompletionCalculator: () => (/* reexport safe */ _Pimcore_modules_execution_engine_message_handlers_message_bus_job_progress_calculator_step_completion_calculator__rspack_import_4.StepCompletionCalculator),
  useExecutionEngine: () => (/* reexport safe */ _Pimcore_modules_execution_engine_hooks_use_execution_engine__rspack_import_0.useExecutionEngine)
});
/* import */ var _Pimcore_modules_execution_engine_hooks_use_execution_engine__rspack_import_0 = __webpack_require__("./js/src/core/modules/execution-engine/hooks/use-execution-engine.ts");
/* import */ var _Pimcore_modules_execution_engine_jobs_abstact_job__rspack_import_1 = __webpack_require__("./js/src/core/modules/execution-engine/jobs/abstact-job.ts");
/* import */ var _Pimcore_modules_execution_engine_message_handlers_message_bus_job_message_bus_job_handler__rspack_import_2 = __webpack_require__("./js/src/core/modules/execution-engine/message-handlers/message-bus-job/message-bus-job-handler.ts");
/* import */ var _Pimcore_modules_execution_engine_message_handlers_message_bus_job_progress_calculator_progress_calculator_interface__rspack_import_3 = __webpack_require__("./js/src/core/modules/execution-engine/message-handlers/message-bus-job/progress-calculator/progress-calculator.interface.ts");
/* import */ var _Pimcore_modules_execution_engine_message_handlers_message_bus_job_progress_calculator_step_completion_calculator__rspack_import_4 = __webpack_require__("./js/src/core/modules/execution-engine/message-handlers/message-bus-job/progress-calculator/step-completion-calculator.ts");
/* import */ var _Pimcore_modules_execution_engine_services_job_rehydration_registry__rspack_import_5 = __webpack_require__("./js/src/core/modules/execution-engine/services/job-rehydration-registry.ts");
/* provided dependency */ var $ReactRefreshRuntime$ = __webpack_require__("./node_modules/@rspack/plugin-react-refresh/client/reactRefresh.js");
/**
 * This source file is available under the terms of the
 * Pimcore Open Core License (POCL)
 * Full copyright and license information is available in
 * LICENSE.md which is distributed with this source code.
 *
 *  @copyright  Copyright (c) Pimcore GmbH (https://www.pimcore.com)
 *  @license    Pimcore Open Core License (POCL)
 */ if (true) {
    module.hot.accept();
}







function $RefreshSig$() { return $ReactRefreshRuntime$.createSignatureFunctionForTransform() }
function $RefreshReg$(type, id) { $ReactRefreshRuntime$.register(type, module.id + "_" + id) }
Promise.resolve().then(() => { $ReactRefreshRuntime$.refresh(module.id, module.hot) });


},

}]);
//# sourceMappingURL=__federation_expose_modules__execution_engine.js.map