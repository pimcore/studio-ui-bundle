
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/e935544caa61-sdk/static/js/remoteEntry.js'
    