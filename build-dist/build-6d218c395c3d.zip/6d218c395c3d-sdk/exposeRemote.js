
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/6d218c395c3d-sdk/static/js/remoteEntry.js'
    