
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/498ca0bbe166-sdk/static/js/remoteEntry.js'
    