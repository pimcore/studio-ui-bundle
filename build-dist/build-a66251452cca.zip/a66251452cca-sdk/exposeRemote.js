
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/a66251452cca-sdk/static/js/remoteEntry.js'
    