
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/59a2c9f19452-sdk/static/js/remoteEntry.js'
    