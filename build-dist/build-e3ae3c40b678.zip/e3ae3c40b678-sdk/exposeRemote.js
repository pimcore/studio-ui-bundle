
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/e3ae3c40b678-sdk/static/js/remoteEntry.js'
    