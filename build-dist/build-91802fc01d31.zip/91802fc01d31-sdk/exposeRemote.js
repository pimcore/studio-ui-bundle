
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/91802fc01d31-sdk/static/js/remoteEntry.js'
    