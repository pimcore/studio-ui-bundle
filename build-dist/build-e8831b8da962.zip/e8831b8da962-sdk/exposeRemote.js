
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/e8831b8da962-sdk/static/js/remoteEntry.js'
    