
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/549f3a07e773-sdk/static/js/remoteEntry.js'
    