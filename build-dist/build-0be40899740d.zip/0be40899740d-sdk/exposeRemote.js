
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/0be40899740d-sdk/static/js/remoteEntry.js'
    