
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/3d43c3263734-sdk/static/js/remoteEntry.js'
    