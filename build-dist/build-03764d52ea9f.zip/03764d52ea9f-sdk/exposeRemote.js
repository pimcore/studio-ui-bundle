
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/03764d52ea9f-sdk/static/js/remoteEntry.js'
    