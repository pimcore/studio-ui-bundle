
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/15a0a963cab3-sdk/static/js/remoteEntry.js'
    