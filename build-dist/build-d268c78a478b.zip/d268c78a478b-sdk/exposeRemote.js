
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/d268c78a478b-sdk/static/js/remoteEntry.js'
    