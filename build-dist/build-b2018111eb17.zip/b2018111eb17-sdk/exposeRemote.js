
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/b2018111eb17-sdk/static/js/remoteEntry.js'
    