
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/4b5e073a0087-sdk/static/js/remoteEntry.js'
    