
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/b60b014683e7-sdk/static/js/remoteEntry.js'
    