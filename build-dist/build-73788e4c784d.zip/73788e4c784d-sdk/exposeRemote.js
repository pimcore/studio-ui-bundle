
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/73788e4c784d-sdk/static/js/remoteEntry.js'
    