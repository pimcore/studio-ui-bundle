
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/18c633784352-sdk/static/js/remoteEntry.js'
    