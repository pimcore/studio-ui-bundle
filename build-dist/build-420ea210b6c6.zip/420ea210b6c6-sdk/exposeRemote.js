
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/420ea210b6c6-sdk/static/js/remoteEntry.js'
    