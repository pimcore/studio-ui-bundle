
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/db832a1e47e8-sdk/static/js/remoteEntry.js'
    