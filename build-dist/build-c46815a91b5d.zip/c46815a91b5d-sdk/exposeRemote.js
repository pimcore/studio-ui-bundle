
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/c46815a91b5d-sdk/static/js/remoteEntry.js'
    