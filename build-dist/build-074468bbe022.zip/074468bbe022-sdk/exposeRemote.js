
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/074468bbe022-sdk/static/js/remoteEntry.js'
    