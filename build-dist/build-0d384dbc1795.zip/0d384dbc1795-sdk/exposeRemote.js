
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/0d384dbc1795-sdk/static/js/remoteEntry.js'
    