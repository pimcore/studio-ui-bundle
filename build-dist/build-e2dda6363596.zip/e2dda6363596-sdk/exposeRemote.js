
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/e2dda6363596-sdk/static/js/remoteEntry.js'
    