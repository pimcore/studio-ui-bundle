
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/816531a5ac8e-sdk/static/js/remoteEntry.js'
    