
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/c8ebef6f29d6-sdk/static/js/remoteEntry.js'
    