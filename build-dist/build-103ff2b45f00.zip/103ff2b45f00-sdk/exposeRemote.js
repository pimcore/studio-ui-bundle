
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/103ff2b45f00-sdk/static/js/remoteEntry.js'
    