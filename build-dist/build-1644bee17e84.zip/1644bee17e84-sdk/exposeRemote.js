
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/1644bee17e84-sdk/static/js/remoteEntry.js'
    