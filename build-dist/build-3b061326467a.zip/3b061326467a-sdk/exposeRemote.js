
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/3b061326467a-sdk/static/js/remoteEntry.js'
    