
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/d1be445c0046-sdk/static/js/remoteEntry.js'
    