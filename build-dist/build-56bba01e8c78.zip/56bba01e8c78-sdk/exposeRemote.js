
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/56bba01e8c78-sdk/static/js/remoteEntry.js'
    