
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/56f01349c505-sdk/static/js/remoteEntry.js'
    