
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/7f07472b2dfe-sdk/static/js/remoteEntry.js'
    