
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/27bc3bd4a80f-sdk/static/js/remoteEntry.js'
    