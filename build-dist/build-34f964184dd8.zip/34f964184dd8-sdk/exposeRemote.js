
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/34f964184dd8-sdk/static/js/remoteEntry.js'
    