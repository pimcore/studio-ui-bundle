
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/234d25cce864-sdk/static/js/remoteEntry.js'
    