
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/61a0abb7baf0-sdk/static/js/remoteEntry.js'
    