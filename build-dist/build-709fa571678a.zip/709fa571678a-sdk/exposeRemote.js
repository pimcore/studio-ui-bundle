
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/709fa571678a-sdk/static/js/remoteEntry.js'
    