
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/675d31a91fbf-sdk/static/js/remoteEntry.js'
    