
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/963ae42367e8-sdk/static/js/remoteEntry.js'
    