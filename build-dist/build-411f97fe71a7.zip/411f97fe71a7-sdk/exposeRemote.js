
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/411f97fe71a7-sdk/static/js/remoteEntry.js'
    