
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/e28749158e43-sdk/static/js/remoteEntry.js'
    