
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/7fe097731b7f-sdk/static/js/remoteEntry.js'
    