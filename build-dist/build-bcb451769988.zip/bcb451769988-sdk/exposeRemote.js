
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/bcb451769988-sdk/static/js/remoteEntry.js'
    