
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/2fff2f77f31f-sdk/static/js/remoteEntry.js'
    