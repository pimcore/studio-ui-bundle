
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/c461468eb24c-sdk/static/js/remoteEntry.js'
    