
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/6fc5a7e904a5-sdk/static/js/remoteEntry.js'
    