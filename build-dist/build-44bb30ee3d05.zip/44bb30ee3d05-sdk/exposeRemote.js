
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/44bb30ee3d05-sdk/static/js/remoteEntry.js'
    