
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/bd8a0207d39e-sdk/static/js/remoteEntry.js'
    