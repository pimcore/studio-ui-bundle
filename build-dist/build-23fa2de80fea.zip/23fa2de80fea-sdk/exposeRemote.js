
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/23fa2de80fea-sdk/static/js/remoteEntry.js'
    