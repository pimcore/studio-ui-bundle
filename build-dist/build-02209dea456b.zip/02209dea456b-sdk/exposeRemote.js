
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/02209dea456b-sdk/static/js/remoteEntry.js'
    