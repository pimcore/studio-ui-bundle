
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/ecbfb757b78f-sdk/static/js/remoteEntry.js'
    