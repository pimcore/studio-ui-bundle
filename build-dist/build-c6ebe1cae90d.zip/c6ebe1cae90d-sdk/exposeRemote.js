
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/c6ebe1cae90d-sdk/static/js/remoteEntry.js'
    