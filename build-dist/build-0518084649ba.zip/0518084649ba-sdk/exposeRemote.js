
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/0518084649ba-sdk/static/js/remoteEntry.js'
    