
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/17aeef3e16d4-sdk/static/js/remoteEntry.js'
    