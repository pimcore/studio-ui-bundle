
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/c08c2146ebb7-sdk/static/js/remoteEntry.js'
    