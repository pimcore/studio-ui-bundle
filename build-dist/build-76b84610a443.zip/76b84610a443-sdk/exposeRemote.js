
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/76b84610a443-sdk/static/js/remoteEntry.js'
    