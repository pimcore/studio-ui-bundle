
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/bd86fc743810-sdk/static/js/remoteEntry.js'
    