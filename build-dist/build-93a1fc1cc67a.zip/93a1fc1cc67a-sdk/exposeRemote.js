
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/93a1fc1cc67a-sdk/static/js/remoteEntry.js'
    