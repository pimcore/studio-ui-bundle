
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/99c5fd43333d-sdk/static/js/remoteEntry.js'
    