
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/bd2a6be65f29-sdk/static/js/remoteEntry.js'
    