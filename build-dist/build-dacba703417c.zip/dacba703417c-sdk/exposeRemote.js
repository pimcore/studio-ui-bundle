
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/dacba703417c-sdk/static/js/remoteEntry.js'
    