
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/056e01da84ff-sdk/static/js/remoteEntry.js'
    