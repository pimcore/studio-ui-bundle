
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/c5ee1b1cdd00-sdk/static/js/remoteEntry.js'
    