
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/d8d54b12b63c-sdk/static/js/remoteEntry.js'
    