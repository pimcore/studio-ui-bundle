
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/21773e5dcdff-sdk/static/js/remoteEntry.js'
    