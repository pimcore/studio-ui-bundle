
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/3ecee749882b-sdk/static/js/remoteEntry.js'
    