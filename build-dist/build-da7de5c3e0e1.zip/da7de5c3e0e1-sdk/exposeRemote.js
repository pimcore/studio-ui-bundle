
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/da7de5c3e0e1-sdk/static/js/remoteEntry.js'
    