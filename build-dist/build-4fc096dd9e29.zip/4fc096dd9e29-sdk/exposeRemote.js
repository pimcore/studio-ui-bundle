
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/4fc096dd9e29-sdk/static/js/remoteEntry.js'
    