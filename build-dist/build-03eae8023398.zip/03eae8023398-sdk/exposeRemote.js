
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/03eae8023398-sdk/static/js/remoteEntry.js'
    