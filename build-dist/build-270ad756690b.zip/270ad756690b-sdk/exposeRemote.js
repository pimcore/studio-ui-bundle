
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/270ad756690b-sdk/static/js/remoteEntry.js'
    