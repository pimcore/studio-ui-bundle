
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/def973994aeb-sdk/static/js/remoteEntry.js'
    