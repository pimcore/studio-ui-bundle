
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/c6551504e636-sdk/static/js/remoteEntry.js'
    