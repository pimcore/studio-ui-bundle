
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/31c0f4fd9ca2-sdk/static/js/remoteEntry.js'
    