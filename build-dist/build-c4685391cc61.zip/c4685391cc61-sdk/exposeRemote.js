
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/c4685391cc61-sdk/static/js/remoteEntry.js'
    