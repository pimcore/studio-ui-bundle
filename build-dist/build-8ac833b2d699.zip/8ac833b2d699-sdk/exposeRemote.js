
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/8ac833b2d699-sdk/static/js/remoteEntry.js'
    