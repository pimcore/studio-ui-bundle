
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/1ef9d0d71ac1-sdk/static/js/remoteEntry.js'
    