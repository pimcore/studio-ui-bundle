
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/5525c7f05db7-sdk/static/js/remoteEntry.js'
    