
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/825a7e03c8fd-sdk/static/js/remoteEntry.js'
    