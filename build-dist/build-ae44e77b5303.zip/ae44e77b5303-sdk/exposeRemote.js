
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/ae44e77b5303-sdk/static/js/remoteEntry.js'
    