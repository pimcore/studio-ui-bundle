
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/f7968b4c8368-sdk/static/js/remoteEntry.js'
    