
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/29cc691cffcb-sdk/static/js/remoteEntry.js'
    