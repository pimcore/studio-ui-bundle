
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/78a5d1960e52-sdk/static/js/remoteEntry.js'
    