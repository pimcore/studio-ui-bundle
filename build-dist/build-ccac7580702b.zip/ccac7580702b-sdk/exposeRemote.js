
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/ccac7580702b-sdk/static/js/remoteEntry.js'
    