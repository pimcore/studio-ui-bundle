
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/26aaf856a928-sdk/static/js/remoteEntry.js'
    