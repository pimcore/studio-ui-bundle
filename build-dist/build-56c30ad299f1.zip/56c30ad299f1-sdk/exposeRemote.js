
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/56c30ad299f1-sdk/static/js/remoteEntry.js'
    