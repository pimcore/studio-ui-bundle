
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/7031b8f255ee-sdk/static/js/remoteEntry.js'
    