
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/cf51a4f7eca9-sdk/static/js/remoteEntry.js'
    