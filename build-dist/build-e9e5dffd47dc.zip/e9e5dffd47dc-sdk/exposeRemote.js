
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/e9e5dffd47dc-sdk/static/js/remoteEntry.js'
    