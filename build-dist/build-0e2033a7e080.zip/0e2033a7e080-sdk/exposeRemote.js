
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/0e2033a7e080-sdk/static/js/remoteEntry.js'
    