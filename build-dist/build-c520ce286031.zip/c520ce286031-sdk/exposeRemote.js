
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/c520ce286031-sdk/static/js/remoteEntry.js'
    