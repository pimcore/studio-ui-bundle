
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/ddd0306ae0d0-sdk/static/js/remoteEntry.js'
    