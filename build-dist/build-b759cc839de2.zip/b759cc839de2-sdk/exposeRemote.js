
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/b759cc839de2-sdk/static/js/remoteEntry.js'
    