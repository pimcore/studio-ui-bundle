
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/6d9e7bb3870a-sdk/static/js/remoteEntry.js'
    