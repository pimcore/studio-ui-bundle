
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/6db02903f933-sdk/static/js/remoteEntry.js'
    