
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/5bf3beb4696e-sdk/static/js/remoteEntry.js'
    