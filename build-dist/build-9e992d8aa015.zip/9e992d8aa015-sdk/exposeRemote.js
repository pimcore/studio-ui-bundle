
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/9e992d8aa015-sdk/static/js/remoteEntry.js'
    