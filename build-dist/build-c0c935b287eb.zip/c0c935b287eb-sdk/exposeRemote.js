
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/c0c935b287eb-sdk/static/js/remoteEntry.js'
    