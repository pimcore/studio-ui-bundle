
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/e31be716408c-sdk/static/js/remoteEntry.js'
    