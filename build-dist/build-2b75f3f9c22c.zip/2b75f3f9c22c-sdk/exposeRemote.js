
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/2b75f3f9c22c-sdk/static/js/remoteEntry.js'
    