
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/9ce05f3a6bda-sdk/static/js/remoteEntry.js'
    