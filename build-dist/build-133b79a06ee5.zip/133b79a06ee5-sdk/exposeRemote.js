
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/133b79a06ee5-sdk/static/js/remoteEntry.js'
    