
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/48c3a64b923e-sdk/static/js/remoteEntry.js'
    