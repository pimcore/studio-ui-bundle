
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/e614c4898860-sdk/static/js/remoteEntry.js'
    