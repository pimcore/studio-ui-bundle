
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/1e1780b17a24-sdk/static/js/remoteEntry.js'
    