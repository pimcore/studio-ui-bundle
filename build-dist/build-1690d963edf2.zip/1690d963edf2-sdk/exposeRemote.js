
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/1690d963edf2-sdk/static/js/remoteEntry.js'
    