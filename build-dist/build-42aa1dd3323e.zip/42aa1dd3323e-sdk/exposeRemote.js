
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/42aa1dd3323e-sdk/static/js/remoteEntry.js'
    