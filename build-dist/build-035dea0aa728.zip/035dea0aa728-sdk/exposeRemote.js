
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/035dea0aa728-sdk/static/js/remoteEntry.js'
    