
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/a318ce030578-sdk/static/js/remoteEntry.js'
    