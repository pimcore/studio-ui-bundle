
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/744e0b29dd43-sdk/static/js/remoteEntry.js'
    