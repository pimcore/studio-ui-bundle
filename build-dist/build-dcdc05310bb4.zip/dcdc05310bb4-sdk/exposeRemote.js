
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/dcdc05310bb4-sdk/static/js/remoteEntry.js'
    