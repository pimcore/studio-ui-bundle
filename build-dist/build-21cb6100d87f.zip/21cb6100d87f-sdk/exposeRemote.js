
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/21cb6100d87f-sdk/static/js/remoteEntry.js'
    