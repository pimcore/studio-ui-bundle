
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/a4e3efd0b7cd-sdk/static/js/remoteEntry.js'
    