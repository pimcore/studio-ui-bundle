
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/4c3c16f85b08-sdk/static/js/remoteEntry.js'
    