
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/66cb1adc073a-sdk/static/js/remoteEntry.js'
    