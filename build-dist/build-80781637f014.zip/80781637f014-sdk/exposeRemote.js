
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/80781637f014-sdk/static/js/remoteEntry.js'
    