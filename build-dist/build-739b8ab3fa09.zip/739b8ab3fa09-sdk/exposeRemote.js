
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/739b8ab3fa09-sdk/static/js/remoteEntry.js'
    