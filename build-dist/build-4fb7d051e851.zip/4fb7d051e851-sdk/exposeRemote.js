
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/4fb7d051e851-sdk/static/js/remoteEntry.js'
    