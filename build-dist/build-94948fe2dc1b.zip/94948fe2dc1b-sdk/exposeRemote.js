
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/94948fe2dc1b-sdk/static/js/remoteEntry.js'
    