
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/51dae4eaa72f-sdk/static/js/remoteEntry.js'
    