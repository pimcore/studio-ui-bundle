
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/e6cdca0f94f0-sdk/static/js/remoteEntry.js'
    