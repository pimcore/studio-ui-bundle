
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/350ab4c0697c-sdk/static/js/remoteEntry.js'
    