
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/128101b2f34e-sdk/static/js/remoteEntry.js'
    