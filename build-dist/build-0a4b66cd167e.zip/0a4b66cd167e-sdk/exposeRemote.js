
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/0a4b66cd167e-sdk/static/js/remoteEntry.js'
    