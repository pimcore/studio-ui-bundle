
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/c98632fe0076-sdk/static/js/remoteEntry.js'
    