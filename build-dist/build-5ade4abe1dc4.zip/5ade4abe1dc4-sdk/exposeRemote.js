
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/5ade4abe1dc4-sdk/static/js/remoteEntry.js'
    