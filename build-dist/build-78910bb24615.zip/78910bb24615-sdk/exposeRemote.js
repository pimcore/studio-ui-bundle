
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/78910bb24615-sdk/static/js/remoteEntry.js'
    