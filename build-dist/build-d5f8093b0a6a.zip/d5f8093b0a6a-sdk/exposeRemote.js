
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/d5f8093b0a6a-sdk/static/js/remoteEntry.js'
    