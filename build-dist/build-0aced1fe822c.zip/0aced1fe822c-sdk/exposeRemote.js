
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/0aced1fe822c-sdk/static/js/remoteEntry.js'
    