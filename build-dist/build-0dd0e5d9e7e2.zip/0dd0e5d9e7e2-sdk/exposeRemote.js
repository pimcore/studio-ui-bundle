
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/0dd0e5d9e7e2-sdk/static/js/remoteEntry.js'
    