
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/054866341f1e-sdk/static/js/remoteEntry.js'
    