
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/f9410ddc372a-sdk/static/js/remoteEntry.js'
    