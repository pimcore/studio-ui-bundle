
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/09477a634479-sdk/static/js/remoteEntry.js'
    