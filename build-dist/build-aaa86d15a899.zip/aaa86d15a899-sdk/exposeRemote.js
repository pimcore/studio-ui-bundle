
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/aaa86d15a899-sdk/static/js/remoteEntry.js'
    