
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/19345d8e9751-sdk/static/js/remoteEntry.js'
    