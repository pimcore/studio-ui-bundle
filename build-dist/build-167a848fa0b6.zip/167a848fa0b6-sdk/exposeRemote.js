
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/167a848fa0b6-sdk/static/js/remoteEntry.js'
    