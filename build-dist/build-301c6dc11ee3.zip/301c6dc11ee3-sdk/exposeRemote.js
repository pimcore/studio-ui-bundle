
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/301c6dc11ee3-sdk/static/js/remoteEntry.js'
    