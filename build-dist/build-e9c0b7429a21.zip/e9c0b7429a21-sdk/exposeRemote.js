
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/e9c0b7429a21-sdk/static/js/remoteEntry.js'
    