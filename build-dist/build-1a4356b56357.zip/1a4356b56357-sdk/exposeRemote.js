
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/1a4356b56357-sdk/static/js/remoteEntry.js'
    