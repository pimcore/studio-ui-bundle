
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/11993f050899-sdk/static/js/remoteEntry.js'
    