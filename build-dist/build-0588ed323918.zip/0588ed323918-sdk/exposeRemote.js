
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/0588ed323918-sdk/static/js/remoteEntry.js'
    