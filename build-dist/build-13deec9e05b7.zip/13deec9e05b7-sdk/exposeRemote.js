
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/13deec9e05b7-sdk/static/js/remoteEntry.js'
    