
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/a275bdd9d747-sdk/static/js/remoteEntry.js'
    