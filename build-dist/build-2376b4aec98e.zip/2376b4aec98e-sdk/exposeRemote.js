
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/2376b4aec98e-sdk/static/js/remoteEntry.js'
    