
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/5afbd48ee4d2-sdk/static/js/remoteEntry.js'
    