
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/d319c26769fe-sdk/static/js/remoteEntry.js'
    