
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/aa4a30ad0b13-sdk/static/js/remoteEntry.js'
    