
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/9cec5923e287-sdk/static/js/remoteEntry.js'
    