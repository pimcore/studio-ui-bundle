
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/e3bf5a76e1b0-sdk/static/js/remoteEntry.js'
    