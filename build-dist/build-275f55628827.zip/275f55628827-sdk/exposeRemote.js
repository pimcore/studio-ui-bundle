
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/275f55628827-sdk/static/js/remoteEntry.js'
    