
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/4489e2b318ba-sdk/static/js/remoteEntry.js'
    