
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/4e57a40d1ec3-sdk/static/js/remoteEntry.js'
    