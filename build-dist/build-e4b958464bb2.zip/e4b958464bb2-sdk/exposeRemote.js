
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/e4b958464bb2-sdk/static/js/remoteEntry.js'
    