
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/b6867135098f-sdk/static/js/remoteEntry.js'
    