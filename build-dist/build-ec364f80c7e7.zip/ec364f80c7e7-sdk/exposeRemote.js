
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/ec364f80c7e7-sdk/static/js/remoteEntry.js'
    