
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/daff28c7db3d-sdk/static/js/remoteEntry.js'
    