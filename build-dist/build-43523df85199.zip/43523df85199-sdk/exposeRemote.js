
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/43523df85199-sdk/static/js/remoteEntry.js'
    