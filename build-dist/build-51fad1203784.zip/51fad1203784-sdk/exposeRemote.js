
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/51fad1203784-sdk/static/js/remoteEntry.js'
    