
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/63ca9ea2779c-sdk/static/js/remoteEntry.js'
    