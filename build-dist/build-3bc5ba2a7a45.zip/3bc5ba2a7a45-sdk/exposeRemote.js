
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/3bc5ba2a7a45-sdk/static/js/remoteEntry.js'
    