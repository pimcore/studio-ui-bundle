
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/0d85b966dc54-sdk/static/js/remoteEntry.js'
    