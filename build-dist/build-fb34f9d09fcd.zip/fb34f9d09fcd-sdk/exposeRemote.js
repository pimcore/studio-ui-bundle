
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/fb34f9d09fcd-sdk/static/js/remoteEntry.js'
    