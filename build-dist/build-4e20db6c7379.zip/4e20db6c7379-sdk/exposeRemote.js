
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/4e20db6c7379-sdk/static/js/remoteEntry.js'
    