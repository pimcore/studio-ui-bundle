
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/c2320d76a775-sdk/static/js/remoteEntry.js'
    