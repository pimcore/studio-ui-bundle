
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/a0ec4e0107fb-sdk/static/js/remoteEntry.js'
    