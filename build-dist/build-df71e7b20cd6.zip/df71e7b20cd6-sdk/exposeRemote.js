
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/df71e7b20cd6-sdk/static/js/remoteEntry.js'
    