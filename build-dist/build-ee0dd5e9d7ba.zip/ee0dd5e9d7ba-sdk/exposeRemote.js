
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/ee0dd5e9d7ba-sdk/static/js/remoteEntry.js'
    