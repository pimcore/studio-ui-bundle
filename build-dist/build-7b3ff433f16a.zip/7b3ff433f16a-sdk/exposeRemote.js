
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/7b3ff433f16a-sdk/static/js/remoteEntry.js'
    