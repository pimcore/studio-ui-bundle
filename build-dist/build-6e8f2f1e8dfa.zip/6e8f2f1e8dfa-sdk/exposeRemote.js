
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/6e8f2f1e8dfa-sdk/static/js/remoteEntry.js'
    