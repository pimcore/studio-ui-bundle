
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/7a33b16904ea-sdk/static/js/remoteEntry.js'
    