
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/43e443c58b9e-sdk/static/js/remoteEntry.js'
    