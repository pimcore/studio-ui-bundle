
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/f6f4323419aa-sdk/static/js/remoteEntry.js'
    