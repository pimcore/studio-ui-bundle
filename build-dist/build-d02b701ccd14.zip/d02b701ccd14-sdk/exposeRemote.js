
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/d02b701ccd14-sdk/static/js/remoteEntry.js'
    