
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/d4ec715e133d-sdk/static/js/remoteEntry.js'
    