
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/3c0759725587-sdk/static/js/remoteEntry.js'
    