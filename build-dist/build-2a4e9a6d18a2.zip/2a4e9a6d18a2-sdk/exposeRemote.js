
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/2a4e9a6d18a2-sdk/static/js/remoteEntry.js'
    