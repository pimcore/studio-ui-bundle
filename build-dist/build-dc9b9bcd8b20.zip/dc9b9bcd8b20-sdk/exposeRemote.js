
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/dc9b9bcd8b20-sdk/static/js/remoteEntry.js'
    