
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/1584b69daeec-sdk/static/js/remoteEntry.js'
    