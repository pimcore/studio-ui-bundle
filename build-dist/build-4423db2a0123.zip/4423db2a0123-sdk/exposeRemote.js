
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/4423db2a0123-sdk/static/js/remoteEntry.js'
    