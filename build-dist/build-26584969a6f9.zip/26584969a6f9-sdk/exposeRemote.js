
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/26584969a6f9-sdk/static/js/remoteEntry.js'
    