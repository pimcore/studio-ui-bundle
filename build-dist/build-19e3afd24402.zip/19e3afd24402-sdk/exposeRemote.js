
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/19e3afd24402-sdk/static/js/remoteEntry.js'
    