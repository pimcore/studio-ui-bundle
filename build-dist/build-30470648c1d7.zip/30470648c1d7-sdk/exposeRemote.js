
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/30470648c1d7-sdk/static/js/remoteEntry.js'
    