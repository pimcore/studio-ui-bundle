
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/ee9d42a5f1fe-sdk/static/js/remoteEntry.js'
    