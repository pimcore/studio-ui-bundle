
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/d8823b45af7d-sdk/static/js/remoteEntry.js'
    