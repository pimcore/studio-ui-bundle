
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/fe4289718145-sdk/static/js/remoteEntry.js'
    