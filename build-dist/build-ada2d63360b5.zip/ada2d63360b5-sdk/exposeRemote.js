
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/ada2d63360b5-sdk/static/js/remoteEntry.js'
    