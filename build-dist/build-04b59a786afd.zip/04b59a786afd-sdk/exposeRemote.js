
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/04b59a786afd-sdk/static/js/remoteEntry.js'
    