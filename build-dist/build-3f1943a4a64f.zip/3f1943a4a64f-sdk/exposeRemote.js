
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/3f1943a4a64f-sdk/static/js/remoteEntry.js'
    