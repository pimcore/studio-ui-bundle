
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/56de7a59c382-sdk/static/js/remoteEntry.js'
    