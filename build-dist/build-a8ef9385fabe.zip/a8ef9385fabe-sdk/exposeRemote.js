
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/a8ef9385fabe-sdk/static/js/remoteEntry.js'
    