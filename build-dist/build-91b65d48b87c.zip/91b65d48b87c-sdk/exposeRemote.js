
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/91b65d48b87c-sdk/static/js/remoteEntry.js'
    