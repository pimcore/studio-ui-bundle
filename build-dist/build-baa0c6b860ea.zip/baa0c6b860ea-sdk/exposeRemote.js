
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/baa0c6b860ea-sdk/static/js/remoteEntry.js'
    