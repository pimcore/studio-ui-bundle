
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/fb6e4d80b275-sdk/static/js/remoteEntry.js'
    