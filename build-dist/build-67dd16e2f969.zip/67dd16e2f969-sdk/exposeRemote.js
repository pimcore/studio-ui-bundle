
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/67dd16e2f969-sdk/static/js/remoteEntry.js'
    