
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/d406d0095edd-sdk/static/js/remoteEntry.js'
    