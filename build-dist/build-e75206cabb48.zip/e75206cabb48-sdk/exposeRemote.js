
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/e75206cabb48-sdk/static/js/remoteEntry.js'
    