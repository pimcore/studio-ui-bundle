
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/c32ebd688f7d-sdk/static/js/remoteEntry.js'
    