
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/17bd05b2da35-sdk/static/js/remoteEntry.js'
    