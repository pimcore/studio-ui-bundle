
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/c85962ee2243-sdk/static/js/remoteEntry.js'
    