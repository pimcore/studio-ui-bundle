
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/72f63680f5ff-sdk/static/js/remoteEntry.js'
    