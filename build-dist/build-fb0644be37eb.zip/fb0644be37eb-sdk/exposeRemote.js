
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/fb0644be37eb-sdk/static/js/remoteEntry.js'
    