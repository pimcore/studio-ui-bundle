
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/918e3c392697-sdk/static/js/remoteEntry.js'
    