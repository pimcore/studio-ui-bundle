
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/8175805ce662-sdk/static/js/remoteEntry.js'
    