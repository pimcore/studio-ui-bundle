
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/34884d657dc1-sdk/static/js/remoteEntry.js'
    