
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/7d416cc49eb5-sdk/static/js/remoteEntry.js'
    