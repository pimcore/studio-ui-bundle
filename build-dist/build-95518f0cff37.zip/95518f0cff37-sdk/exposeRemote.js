
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/95518f0cff37-sdk/static/js/remoteEntry.js'
    