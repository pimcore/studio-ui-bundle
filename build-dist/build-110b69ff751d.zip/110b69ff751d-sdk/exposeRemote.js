
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/110b69ff751d-sdk/static/js/remoteEntry.js'
    