
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/600d104d4ede-sdk/static/js/remoteEntry.js'
    