
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/0d0a4dccdf93-sdk/static/js/remoteEntry.js'
    