
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/e70d9ad473a3-sdk/static/js/remoteEntry.js'
    