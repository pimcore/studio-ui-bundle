
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/623d6ec51b45-sdk/static/js/remoteEntry.js'
    