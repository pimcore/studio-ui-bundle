
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/0503aa8ea120-sdk/static/js/remoteEntry.js'
    