
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/4840018aa48f-sdk/static/js/remoteEntry.js'
    