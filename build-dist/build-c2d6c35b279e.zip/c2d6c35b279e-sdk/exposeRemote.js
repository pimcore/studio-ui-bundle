
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/c2d6c35b279e-sdk/static/js/remoteEntry.js'
    