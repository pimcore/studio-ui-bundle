
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/9ac86bd60a4c-sdk/static/js/remoteEntry.js'
    