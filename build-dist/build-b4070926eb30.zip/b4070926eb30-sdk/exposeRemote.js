
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/b4070926eb30-sdk/static/js/remoteEntry.js'
    