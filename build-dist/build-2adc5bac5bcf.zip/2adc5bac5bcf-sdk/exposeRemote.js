
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/2adc5bac5bcf-sdk/static/js/remoteEntry.js'
    