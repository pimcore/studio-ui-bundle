
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/1e2c2c991f3a-sdk/static/js/remoteEntry.js'
    