
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/3cfae94718e9-sdk/static/js/remoteEntry.js'
    