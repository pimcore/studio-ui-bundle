
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/ff13d19fc72d-sdk/static/js/remoteEntry.js'
    