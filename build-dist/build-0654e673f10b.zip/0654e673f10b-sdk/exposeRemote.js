
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/0654e673f10b-sdk/static/js/remoteEntry.js'
    