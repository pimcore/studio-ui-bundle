
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/3dda5adebee8-sdk/static/js/remoteEntry.js'
    