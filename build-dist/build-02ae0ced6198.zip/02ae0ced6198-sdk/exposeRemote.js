
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/02ae0ced6198-sdk/static/js/remoteEntry.js'
    