
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/34ab4002e127-sdk/static/js/remoteEntry.js'
    