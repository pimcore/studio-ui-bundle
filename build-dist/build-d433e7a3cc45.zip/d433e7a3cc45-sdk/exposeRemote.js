
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/d433e7a3cc45-sdk/static/js/remoteEntry.js'
    