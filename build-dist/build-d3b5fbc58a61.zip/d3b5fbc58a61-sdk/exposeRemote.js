
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/d3b5fbc58a61-sdk/static/js/remoteEntry.js'
    