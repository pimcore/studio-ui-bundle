
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/14348fa2f21e-sdk/static/js/remoteEntry.js'
    