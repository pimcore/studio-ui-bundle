
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/fe51d363fa54-sdk/static/js/remoteEntry.js'
    