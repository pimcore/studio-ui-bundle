
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/f213ecca4907-sdk/static/js/remoteEntry.js'
    