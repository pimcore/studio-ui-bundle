
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/358a40e7f6e7-sdk/static/js/remoteEntry.js'
    