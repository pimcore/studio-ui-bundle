
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/674430650ad0-sdk/static/js/remoteEntry.js'
    