
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/25f18c00b4af-sdk/static/js/remoteEntry.js'
    