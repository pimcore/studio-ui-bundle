
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/a96758378ac5-sdk/static/js/remoteEntry.js'
    