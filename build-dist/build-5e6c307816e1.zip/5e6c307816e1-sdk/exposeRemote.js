
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/5e6c307816e1-sdk/static/js/remoteEntry.js'
    