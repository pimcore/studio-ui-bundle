
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/ee20dc50df9b-sdk/static/js/remoteEntry.js'
    