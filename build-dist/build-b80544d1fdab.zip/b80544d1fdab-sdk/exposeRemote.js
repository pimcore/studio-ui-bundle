
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/b80544d1fdab-sdk/static/js/remoteEntry.js'
    