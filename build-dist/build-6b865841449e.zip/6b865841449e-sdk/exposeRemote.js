
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/6b865841449e-sdk/static/js/remoteEntry.js'
    