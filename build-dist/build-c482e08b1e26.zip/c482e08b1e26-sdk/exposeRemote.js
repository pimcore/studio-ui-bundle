
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/c482e08b1e26-sdk/static/js/remoteEntry.js'
    