
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/c645c85dcc3b-sdk/static/js/remoteEntry.js'
    