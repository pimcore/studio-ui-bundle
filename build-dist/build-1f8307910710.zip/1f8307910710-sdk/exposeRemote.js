
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/1f8307910710-sdk/static/js/remoteEntry.js'
    