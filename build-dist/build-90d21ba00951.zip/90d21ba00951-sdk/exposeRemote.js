
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/90d21ba00951-sdk/static/js/remoteEntry.js'
    