
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/65b626aacb10-sdk/static/js/remoteEntry.js'
    