
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/f6ab65f64098-sdk/static/js/remoteEntry.js'
    