
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/416b59cc07ee-sdk/static/js/remoteEntry.js'
    