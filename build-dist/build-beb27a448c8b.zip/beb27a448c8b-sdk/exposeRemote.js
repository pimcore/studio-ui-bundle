
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/beb27a448c8b-sdk/static/js/remoteEntry.js'
    