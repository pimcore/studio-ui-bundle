
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/70314dd1ff17-sdk/static/js/remoteEntry.js'
    