
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/da0d2c5da0c6-sdk/static/js/remoteEntry.js'
    