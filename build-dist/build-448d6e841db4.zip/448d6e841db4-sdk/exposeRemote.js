
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/448d6e841db4-sdk/static/js/remoteEntry.js'
    