
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/65c8c5564641-sdk/static/js/remoteEntry.js'
    