
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/50c1decfabce-sdk/static/js/remoteEntry.js'
    