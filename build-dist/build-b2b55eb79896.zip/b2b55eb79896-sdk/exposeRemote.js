
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/b2b55eb79896-sdk/static/js/remoteEntry.js'
    