
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/c63655fca478-sdk/static/js/remoteEntry.js'
    