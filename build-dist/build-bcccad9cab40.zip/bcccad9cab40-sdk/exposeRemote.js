
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/bcccad9cab40-sdk/static/js/remoteEntry.js'
    