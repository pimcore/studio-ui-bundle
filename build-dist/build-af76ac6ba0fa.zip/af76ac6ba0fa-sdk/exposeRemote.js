
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/af76ac6ba0fa-sdk/static/js/remoteEntry.js'
    