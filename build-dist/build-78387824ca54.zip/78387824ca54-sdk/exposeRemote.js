
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/78387824ca54-sdk/static/js/remoteEntry.js'
    