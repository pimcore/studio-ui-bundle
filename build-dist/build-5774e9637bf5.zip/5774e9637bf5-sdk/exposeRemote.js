
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/5774e9637bf5-sdk/static/js/remoteEntry.js'
    