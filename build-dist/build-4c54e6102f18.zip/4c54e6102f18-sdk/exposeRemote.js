
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/4c54e6102f18-sdk/static/js/remoteEntry.js'
    