
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/241e7ee8fe2b-sdk/static/js/remoteEntry.js'
    