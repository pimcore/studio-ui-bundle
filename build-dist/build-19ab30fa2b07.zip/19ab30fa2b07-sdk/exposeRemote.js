
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/19ab30fa2b07-sdk/static/js/remoteEntry.js'
    