
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/ff540227a3c7-sdk/static/js/remoteEntry.js'
    