
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/c86810b8fc2e-sdk/static/js/remoteEntry.js'
    