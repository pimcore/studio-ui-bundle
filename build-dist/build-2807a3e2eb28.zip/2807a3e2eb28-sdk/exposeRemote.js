
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/2807a3e2eb28-sdk/static/js/remoteEntry.js'
    