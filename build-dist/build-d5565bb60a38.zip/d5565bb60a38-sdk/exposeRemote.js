
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/d5565bb60a38-sdk/static/js/remoteEntry.js'
    