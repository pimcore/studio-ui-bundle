
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/b8abaa295697-sdk/static/js/remoteEntry.js'
    