
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/f5eb7493766a-sdk/static/js/remoteEntry.js'
    