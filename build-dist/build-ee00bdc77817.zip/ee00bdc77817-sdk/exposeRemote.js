
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/ee00bdc77817-sdk/static/js/remoteEntry.js'
    