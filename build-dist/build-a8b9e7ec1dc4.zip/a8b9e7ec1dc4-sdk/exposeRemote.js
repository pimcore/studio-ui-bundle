
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/a8b9e7ec1dc4-sdk/static/js/remoteEntry.js'
    