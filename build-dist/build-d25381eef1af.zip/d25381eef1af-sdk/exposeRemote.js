
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/d25381eef1af-sdk/static/js/remoteEntry.js'
    