
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/73cf459c3b85-sdk/static/js/remoteEntry.js'
    