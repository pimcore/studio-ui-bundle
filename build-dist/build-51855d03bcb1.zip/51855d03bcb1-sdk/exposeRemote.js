
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/51855d03bcb1-sdk/static/js/remoteEntry.js'
    