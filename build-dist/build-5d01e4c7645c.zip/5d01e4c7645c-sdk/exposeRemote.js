
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/5d01e4c7645c-sdk/static/js/remoteEntry.js'
    