
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/38ca30e4e519-sdk/static/js/remoteEntry.js'
    