
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/7cea0dd6204e-sdk/static/js/remoteEntry.js'
    