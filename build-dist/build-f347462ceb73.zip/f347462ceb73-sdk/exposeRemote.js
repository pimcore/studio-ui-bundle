
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/f347462ceb73-sdk/static/js/remoteEntry.js'
    