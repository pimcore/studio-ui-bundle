
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/efaf1bf03351-sdk/static/js/remoteEntry.js'
    