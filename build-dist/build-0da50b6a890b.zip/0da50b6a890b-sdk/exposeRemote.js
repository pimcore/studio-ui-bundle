
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/0da50b6a890b-sdk/static/js/remoteEntry.js'
    