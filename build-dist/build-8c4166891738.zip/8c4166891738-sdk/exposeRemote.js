
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/8c4166891738-sdk/static/js/remoteEntry.js'
    