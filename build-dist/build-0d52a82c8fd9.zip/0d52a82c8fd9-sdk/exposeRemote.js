
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/0d52a82c8fd9-sdk/static/js/remoteEntry.js'
    