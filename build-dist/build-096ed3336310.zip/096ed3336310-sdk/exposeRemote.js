
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/096ed3336310-sdk/static/js/remoteEntry.js'
    