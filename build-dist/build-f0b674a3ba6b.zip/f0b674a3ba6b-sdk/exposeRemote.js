
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/f0b674a3ba6b-sdk/static/js/remoteEntry.js'
    