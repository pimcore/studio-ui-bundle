
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/38cd30af43f9-sdk/static/js/remoteEntry.js'
    