
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/7503b884bb6f-sdk/static/js/remoteEntry.js'
    