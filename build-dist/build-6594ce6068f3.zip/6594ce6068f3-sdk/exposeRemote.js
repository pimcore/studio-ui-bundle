
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/6594ce6068f3-sdk/static/js/remoteEntry.js'
    