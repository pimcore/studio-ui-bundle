
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/cf8102d0605a-sdk/static/js/remoteEntry.js'
    