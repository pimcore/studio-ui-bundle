
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/58f109936dc0-sdk/static/js/remoteEntry.js'
    