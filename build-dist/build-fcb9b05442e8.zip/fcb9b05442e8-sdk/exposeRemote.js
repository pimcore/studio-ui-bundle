
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/fcb9b05442e8-sdk/static/js/remoteEntry.js'
    