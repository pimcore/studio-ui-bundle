
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/aa54fa77a1d5-sdk/static/js/remoteEntry.js'
    