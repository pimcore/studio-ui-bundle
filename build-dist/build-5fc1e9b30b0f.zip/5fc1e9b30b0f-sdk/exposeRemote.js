
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/5fc1e9b30b0f-sdk/static/js/remoteEntry.js'
    