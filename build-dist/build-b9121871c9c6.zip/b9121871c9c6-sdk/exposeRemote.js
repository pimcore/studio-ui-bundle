
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/b9121871c9c6-sdk/static/js/remoteEntry.js'
    