
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/60d81a06b73f-sdk/static/js/remoteEntry.js'
    