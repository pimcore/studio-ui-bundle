
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/5549970f96a8-sdk/static/js/remoteEntry.js'
    