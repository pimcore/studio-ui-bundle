
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/4f5695e4f870-sdk/static/js/remoteEntry.js'
    