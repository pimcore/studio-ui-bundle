
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/c591cf89ff09-sdk/static/js/remoteEntry.js'
    