
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/8cf902165a17-sdk/static/js/remoteEntry.js'
    