
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/293922e2b1d4-sdk/static/js/remoteEntry.js'
    