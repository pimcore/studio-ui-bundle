
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/fec36cc6a715-sdk/static/js/remoteEntry.js'
    