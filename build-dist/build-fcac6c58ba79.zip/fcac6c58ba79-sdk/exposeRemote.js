
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/fcac6c58ba79-sdk/static/js/remoteEntry.js'
    