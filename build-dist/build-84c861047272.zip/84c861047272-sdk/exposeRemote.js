
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/84c861047272-sdk/static/js/remoteEntry.js'
    