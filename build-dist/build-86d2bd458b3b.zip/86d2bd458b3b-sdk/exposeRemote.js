
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/86d2bd458b3b-sdk/static/js/remoteEntry.js'
    