
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/066f46106006-sdk/static/js/remoteEntry.js'
    