
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/09878b4a77ae-sdk/static/js/remoteEntry.js'
    