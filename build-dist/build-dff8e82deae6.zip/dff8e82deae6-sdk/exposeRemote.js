
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/dff8e82deae6-sdk/static/js/remoteEntry.js'
    