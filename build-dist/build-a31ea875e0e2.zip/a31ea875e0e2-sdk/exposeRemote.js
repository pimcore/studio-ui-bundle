
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/a31ea875e0e2-sdk/static/js/remoteEntry.js'
    