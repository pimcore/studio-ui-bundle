
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/858a2d974cfe-sdk/static/js/remoteEntry.js'
    