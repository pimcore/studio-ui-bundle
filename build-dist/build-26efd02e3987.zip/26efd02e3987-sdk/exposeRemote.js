
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/26efd02e3987-sdk/static/js/remoteEntry.js'
    