
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/c25e6d37caed-sdk/static/js/remoteEntry.js'
    