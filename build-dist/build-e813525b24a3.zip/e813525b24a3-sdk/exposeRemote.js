
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/e813525b24a3-sdk/static/js/remoteEntry.js'
    