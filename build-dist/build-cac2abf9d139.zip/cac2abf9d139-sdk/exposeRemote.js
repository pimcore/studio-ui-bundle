
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/cac2abf9d139-sdk/static/js/remoteEntry.js'
    