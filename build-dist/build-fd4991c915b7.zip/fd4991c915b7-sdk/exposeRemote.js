
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/fd4991c915b7-sdk/static/js/remoteEntry.js'
    