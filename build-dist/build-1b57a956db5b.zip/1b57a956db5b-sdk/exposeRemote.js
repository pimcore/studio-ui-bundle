
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/1b57a956db5b-sdk/static/js/remoteEntry.js'
    