
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/b883007e311b-sdk/static/js/remoteEntry.js'
    