
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/a6346965f4ef-sdk/static/js/remoteEntry.js'
    