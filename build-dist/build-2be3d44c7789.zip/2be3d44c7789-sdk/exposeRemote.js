
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/2be3d44c7789-sdk/static/js/remoteEntry.js'
    