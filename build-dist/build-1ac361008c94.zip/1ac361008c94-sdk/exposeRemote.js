
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/1ac361008c94-sdk/static/js/remoteEntry.js'
    