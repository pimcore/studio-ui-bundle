
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/6b5e69dbee39-sdk/static/js/remoteEntry.js'
    