
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/f44804b3bdcc-sdk/static/js/remoteEntry.js'
    