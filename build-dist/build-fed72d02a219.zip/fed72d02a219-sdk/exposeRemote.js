
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/fed72d02a219-sdk/static/js/remoteEntry.js'
    