
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/93324efc7735-sdk/static/js/remoteEntry.js'
    