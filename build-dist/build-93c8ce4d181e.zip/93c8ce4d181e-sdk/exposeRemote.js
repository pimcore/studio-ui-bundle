
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/93c8ce4d181e-sdk/static/js/remoteEntry.js'
    