
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/c6f98da85b2f-sdk/static/js/remoteEntry.js'
    