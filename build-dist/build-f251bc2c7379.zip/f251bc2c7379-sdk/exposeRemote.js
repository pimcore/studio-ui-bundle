
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/f251bc2c7379-sdk/static/js/remoteEntry.js'
    