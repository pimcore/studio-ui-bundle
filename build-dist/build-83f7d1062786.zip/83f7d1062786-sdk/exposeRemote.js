
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/83f7d1062786-sdk/static/js/remoteEntry.js'
    