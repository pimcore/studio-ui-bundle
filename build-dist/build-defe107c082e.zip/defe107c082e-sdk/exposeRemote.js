
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/defe107c082e-sdk/static/js/remoteEntry.js'
    