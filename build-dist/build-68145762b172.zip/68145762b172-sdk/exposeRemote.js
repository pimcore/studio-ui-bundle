
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/68145762b172-sdk/static/js/remoteEntry.js'
    