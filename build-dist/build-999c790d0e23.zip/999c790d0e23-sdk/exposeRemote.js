
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/999c790d0e23-sdk/static/js/remoteEntry.js'
    