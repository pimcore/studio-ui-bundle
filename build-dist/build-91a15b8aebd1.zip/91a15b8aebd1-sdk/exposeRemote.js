
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/91a15b8aebd1-sdk/static/js/remoteEntry.js'
    