
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/1282edc6cdc8-sdk/static/js/remoteEntry.js'
    