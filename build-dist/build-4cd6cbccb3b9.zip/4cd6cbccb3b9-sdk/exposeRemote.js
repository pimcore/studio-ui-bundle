
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/4cd6cbccb3b9-sdk/static/js/remoteEntry.js'
    