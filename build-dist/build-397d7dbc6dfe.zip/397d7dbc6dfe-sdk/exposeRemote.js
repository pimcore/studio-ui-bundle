
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/397d7dbc6dfe-sdk/static/js/remoteEntry.js'
    