
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/83282361c9e9-sdk/static/js/remoteEntry.js'
    