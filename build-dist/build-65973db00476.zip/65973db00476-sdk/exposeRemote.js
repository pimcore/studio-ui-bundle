
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/65973db00476-sdk/static/js/remoteEntry.js'
    