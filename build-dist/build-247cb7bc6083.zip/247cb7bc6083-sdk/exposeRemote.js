
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/247cb7bc6083-sdk/static/js/remoteEntry.js'
    