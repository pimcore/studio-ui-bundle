
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/07732e15d73e-sdk/static/js/remoteEntry.js'
    