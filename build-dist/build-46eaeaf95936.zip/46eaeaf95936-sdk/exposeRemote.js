
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/46eaeaf95936-sdk/static/js/remoteEntry.js'
    