
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/51b0b820f24c-sdk/static/js/remoteEntry.js'
    