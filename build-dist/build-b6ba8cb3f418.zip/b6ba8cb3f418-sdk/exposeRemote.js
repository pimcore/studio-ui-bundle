
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/b6ba8cb3f418-sdk/static/js/remoteEntry.js'
    