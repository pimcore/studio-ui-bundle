
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/7399cb7c6c0b-sdk/static/js/remoteEntry.js'
    