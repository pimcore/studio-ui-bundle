
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/f51ae8ea0e70-sdk/static/js/remoteEntry.js'
    