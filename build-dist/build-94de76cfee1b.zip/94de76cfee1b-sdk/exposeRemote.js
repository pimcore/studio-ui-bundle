
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/94de76cfee1b-sdk/static/js/remoteEntry.js'
    