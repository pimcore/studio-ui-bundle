
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/ea4db994a1b5-sdk/static/js/remoteEntry.js'
    