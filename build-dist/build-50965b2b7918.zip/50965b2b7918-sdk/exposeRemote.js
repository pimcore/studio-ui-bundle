
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/50965b2b7918-sdk/static/js/remoteEntry.js'
    