
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/1232696360a1-sdk/static/js/remoteEntry.js'
    