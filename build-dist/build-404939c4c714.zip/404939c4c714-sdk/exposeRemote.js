
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/404939c4c714-sdk/static/js/remoteEntry.js'
    