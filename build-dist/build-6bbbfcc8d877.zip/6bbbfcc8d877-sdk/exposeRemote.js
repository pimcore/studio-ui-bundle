
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/6bbbfcc8d877-sdk/static/js/remoteEntry.js'
    