
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/7a0d3e9837f1-sdk/static/js/remoteEntry.js'
    