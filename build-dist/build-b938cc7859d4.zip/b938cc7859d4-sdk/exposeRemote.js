
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/b938cc7859d4-sdk/static/js/remoteEntry.js'
    