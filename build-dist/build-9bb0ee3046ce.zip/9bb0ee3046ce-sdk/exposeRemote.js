
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/9bb0ee3046ce-sdk/static/js/remoteEntry.js'
    