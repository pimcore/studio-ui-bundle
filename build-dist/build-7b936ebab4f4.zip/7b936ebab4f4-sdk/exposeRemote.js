
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/7b936ebab4f4-sdk/static/js/remoteEntry.js'
    