
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/53bc5c8f111a-sdk/static/js/remoteEntry.js'
    