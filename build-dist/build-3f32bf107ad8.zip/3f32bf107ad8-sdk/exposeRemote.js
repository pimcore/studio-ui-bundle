
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/3f32bf107ad8-sdk/static/js/remoteEntry.js'
    