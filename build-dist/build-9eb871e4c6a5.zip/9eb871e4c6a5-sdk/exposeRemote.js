
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/9eb871e4c6a5-sdk/static/js/remoteEntry.js'
    