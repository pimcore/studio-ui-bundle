
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/ab261c75453d-sdk/static/js/remoteEntry.js'
    