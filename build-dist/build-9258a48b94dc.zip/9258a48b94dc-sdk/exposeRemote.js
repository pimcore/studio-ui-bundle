
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/9258a48b94dc-sdk/static/js/remoteEntry.js'
    