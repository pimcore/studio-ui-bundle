
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/4a92fc5162a1-sdk/static/js/remoteEntry.js'
    