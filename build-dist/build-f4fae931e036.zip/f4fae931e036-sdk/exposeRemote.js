
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/f4fae931e036-sdk/static/js/remoteEntry.js'
    