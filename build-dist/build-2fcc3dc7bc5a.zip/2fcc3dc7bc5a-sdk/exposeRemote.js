
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/2fcc3dc7bc5a-sdk/static/js/remoteEntry.js'
    