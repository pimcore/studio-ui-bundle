
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/13e3cc4dde90-sdk/static/js/remoteEntry.js'
    