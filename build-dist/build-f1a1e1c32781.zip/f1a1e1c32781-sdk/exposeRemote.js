
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/f1a1e1c32781-sdk/static/js/remoteEntry.js'
    