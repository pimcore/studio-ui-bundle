
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/fa49d417a938-sdk/static/js/remoteEntry.js'
    