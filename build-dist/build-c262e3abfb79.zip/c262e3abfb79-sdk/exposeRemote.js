
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/c262e3abfb79-sdk/static/js/remoteEntry.js'
    