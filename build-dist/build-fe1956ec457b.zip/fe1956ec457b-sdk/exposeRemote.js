
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/fe1956ec457b-sdk/static/js/remoteEntry.js'
    