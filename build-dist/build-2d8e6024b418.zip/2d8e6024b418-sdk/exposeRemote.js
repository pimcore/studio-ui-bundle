
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/2d8e6024b418-sdk/static/js/remoteEntry.js'
    