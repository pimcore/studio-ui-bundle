
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/9559e9f21030-sdk/static/js/remoteEntry.js'
    