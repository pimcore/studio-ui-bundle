
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/1a4b62807131-sdk/static/js/remoteEntry.js'
    