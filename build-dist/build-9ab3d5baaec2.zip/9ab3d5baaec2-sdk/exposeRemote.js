
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/9ab3d5baaec2-sdk/static/js/remoteEntry.js'
    