
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/14a286368143-sdk/static/js/remoteEntry.js'
    