
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/2b19882a01d6-sdk/static/js/remoteEntry.js'
    