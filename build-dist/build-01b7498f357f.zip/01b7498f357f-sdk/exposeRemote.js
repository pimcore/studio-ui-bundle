
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/01b7498f357f-sdk/static/js/remoteEntry.js'
    