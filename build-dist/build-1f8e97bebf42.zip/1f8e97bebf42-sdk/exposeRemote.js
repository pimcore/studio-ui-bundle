
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/1f8e97bebf42-sdk/static/js/remoteEntry.js'
    