
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/a609720cbdb9-sdk/static/js/remoteEntry.js'
    