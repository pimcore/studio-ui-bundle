
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/74ebeeffbb55-sdk/static/js/remoteEntry.js'
    