
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/ee636eeb6c4c-sdk/static/js/remoteEntry.js'
    