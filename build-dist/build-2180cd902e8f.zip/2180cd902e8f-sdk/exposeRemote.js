
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/2180cd902e8f-sdk/static/js/remoteEntry.js'
    