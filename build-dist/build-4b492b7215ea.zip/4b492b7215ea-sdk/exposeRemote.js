
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/4b492b7215ea-sdk/static/js/remoteEntry.js'
    