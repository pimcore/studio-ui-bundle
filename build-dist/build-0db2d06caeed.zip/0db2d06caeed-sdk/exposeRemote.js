
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/0db2d06caeed-sdk/static/js/remoteEntry.js'
    