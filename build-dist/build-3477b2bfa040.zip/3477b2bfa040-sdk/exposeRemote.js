
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/3477b2bfa040-sdk/static/js/remoteEntry.js'
    