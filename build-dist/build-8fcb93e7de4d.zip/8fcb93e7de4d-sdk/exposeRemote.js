
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/8fcb93e7de4d-sdk/static/js/remoteEntry.js'
    