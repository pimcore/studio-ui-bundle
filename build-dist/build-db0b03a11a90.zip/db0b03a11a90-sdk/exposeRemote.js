
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/db0b03a11a90-sdk/static/js/remoteEntry.js'
    