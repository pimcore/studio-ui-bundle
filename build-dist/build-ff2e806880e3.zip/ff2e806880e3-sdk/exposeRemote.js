
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/ff2e806880e3-sdk/static/js/remoteEntry.js'
    