
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/a622dfa140db-sdk/static/js/remoteEntry.js'
    