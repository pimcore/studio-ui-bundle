
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/85923b5f1bb7-sdk/static/js/remoteEntry.js'
    