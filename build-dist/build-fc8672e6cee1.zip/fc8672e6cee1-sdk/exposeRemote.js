
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/fc8672e6cee1-sdk/static/js/remoteEntry.js'
    