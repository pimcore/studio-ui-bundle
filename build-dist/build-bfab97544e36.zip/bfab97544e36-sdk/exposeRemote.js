
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/bfab97544e36-sdk/static/js/remoteEntry.js'
    