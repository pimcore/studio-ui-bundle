
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/01165d6e5392-sdk/static/js/remoteEntry.js'
    