
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/237aad2f842f-sdk/static/js/remoteEntry.js'
    