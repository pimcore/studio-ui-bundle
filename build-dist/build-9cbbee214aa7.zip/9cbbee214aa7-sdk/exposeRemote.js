
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/9cbbee214aa7-sdk/static/js/remoteEntry.js'
    