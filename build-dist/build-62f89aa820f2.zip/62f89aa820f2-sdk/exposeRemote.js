
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/62f89aa820f2-sdk/static/js/remoteEntry.js'
    