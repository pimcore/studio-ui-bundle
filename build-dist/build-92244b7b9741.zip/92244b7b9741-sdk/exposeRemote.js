
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/92244b7b9741-sdk/static/js/remoteEntry.js'
    