
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/9d0c7d82fcf1-sdk/static/js/remoteEntry.js'
    