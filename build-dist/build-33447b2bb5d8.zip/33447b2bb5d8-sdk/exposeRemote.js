
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/33447b2bb5d8-sdk/static/js/remoteEntry.js'
    