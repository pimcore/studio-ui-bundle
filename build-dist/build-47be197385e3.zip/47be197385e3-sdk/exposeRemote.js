
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/47be197385e3-sdk/static/js/remoteEntry.js'
    