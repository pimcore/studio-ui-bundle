
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/6fac30b0cb56-sdk/static/js/remoteEntry.js'
    