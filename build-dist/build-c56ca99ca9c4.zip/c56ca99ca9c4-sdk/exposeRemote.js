
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/c56ca99ca9c4-sdk/static/js/remoteEntry.js'
    