
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/2231abdf8a14-sdk/static/js/remoteEntry.js'
    