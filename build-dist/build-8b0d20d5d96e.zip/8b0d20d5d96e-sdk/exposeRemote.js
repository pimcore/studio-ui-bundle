
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/8b0d20d5d96e-sdk/static/js/remoteEntry.js'
    