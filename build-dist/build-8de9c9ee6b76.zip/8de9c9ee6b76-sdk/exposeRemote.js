
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/8de9c9ee6b76-sdk/static/js/remoteEntry.js'
    