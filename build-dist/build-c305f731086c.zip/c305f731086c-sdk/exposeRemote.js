
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/c305f731086c-sdk/static/js/remoteEntry.js'
    