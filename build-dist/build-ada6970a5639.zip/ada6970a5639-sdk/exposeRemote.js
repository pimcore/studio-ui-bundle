
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/ada6970a5639-sdk/static/js/remoteEntry.js'
    