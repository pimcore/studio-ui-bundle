
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/962e84dbdb54-sdk/static/js/remoteEntry.js'
    