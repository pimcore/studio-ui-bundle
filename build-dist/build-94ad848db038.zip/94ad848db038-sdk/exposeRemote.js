
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/94ad848db038-sdk/static/js/remoteEntry.js'
    