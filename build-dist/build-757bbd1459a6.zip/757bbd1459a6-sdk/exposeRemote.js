
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/757bbd1459a6-sdk/static/js/remoteEntry.js'
    