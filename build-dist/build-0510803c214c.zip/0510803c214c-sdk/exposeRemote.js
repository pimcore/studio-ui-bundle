
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/0510803c214c-sdk/static/js/remoteEntry.js'
    