
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/181308934043-sdk/static/js/remoteEntry.js'
    