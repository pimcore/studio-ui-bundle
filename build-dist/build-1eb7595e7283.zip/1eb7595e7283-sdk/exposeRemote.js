
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/1eb7595e7283-sdk/static/js/remoteEntry.js'
    