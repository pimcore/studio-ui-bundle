
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/a79653690da6-sdk/static/js/remoteEntry.js'
    