
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/11a562b803f4-sdk/static/js/remoteEntry.js'
    