
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/ee4e929f8f95-sdk/static/js/remoteEntry.js'
    