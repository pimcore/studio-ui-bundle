
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/9dfb322ac5b5-sdk/static/js/remoteEntry.js'
    