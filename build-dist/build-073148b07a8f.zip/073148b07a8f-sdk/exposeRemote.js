
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/073148b07a8f-sdk/static/js/remoteEntry.js'
    