
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/e43ba2d20b3c-sdk/static/js/remoteEntry.js'
    