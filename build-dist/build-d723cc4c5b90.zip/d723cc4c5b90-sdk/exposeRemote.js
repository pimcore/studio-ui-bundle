
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/d723cc4c5b90-sdk/static/js/remoteEntry.js'
    