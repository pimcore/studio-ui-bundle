
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/f8e35704820e-sdk/static/js/remoteEntry.js'
    