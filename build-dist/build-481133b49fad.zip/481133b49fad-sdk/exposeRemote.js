
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/481133b49fad-sdk/static/js/remoteEntry.js'
    