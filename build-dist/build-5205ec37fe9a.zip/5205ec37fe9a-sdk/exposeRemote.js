
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/5205ec37fe9a-sdk/static/js/remoteEntry.js'
    