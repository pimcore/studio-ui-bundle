
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/b9ec3fd7ed07-sdk/static/js/remoteEntry.js'
    