
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/b728ae9c3a62-sdk/static/js/remoteEntry.js'
    