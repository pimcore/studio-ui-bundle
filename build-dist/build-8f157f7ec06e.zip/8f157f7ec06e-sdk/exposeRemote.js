
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/8f157f7ec06e-sdk/static/js/remoteEntry.js'
    