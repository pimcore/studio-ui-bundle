
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/ffffef1bc249-sdk/static/js/remoteEntry.js'
    