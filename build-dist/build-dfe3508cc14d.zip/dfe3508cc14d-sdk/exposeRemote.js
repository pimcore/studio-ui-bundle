
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/dfe3508cc14d-sdk/static/js/remoteEntry.js'
    