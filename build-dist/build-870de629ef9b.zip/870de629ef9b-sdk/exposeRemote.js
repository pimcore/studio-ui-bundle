
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/870de629ef9b-sdk/static/js/remoteEntry.js'
    