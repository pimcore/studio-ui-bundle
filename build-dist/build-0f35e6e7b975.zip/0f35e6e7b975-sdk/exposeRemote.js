
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/0f35e6e7b975-sdk/static/js/remoteEntry.js'
    