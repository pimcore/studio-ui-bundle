
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/a365bec89f49-sdk/static/js/remoteEntry.js'
    