
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/942486862845-sdk/static/js/remoteEntry.js'
    