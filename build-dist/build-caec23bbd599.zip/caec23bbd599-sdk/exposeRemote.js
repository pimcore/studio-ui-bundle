
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/caec23bbd599-sdk/static/js/remoteEntry.js'
    