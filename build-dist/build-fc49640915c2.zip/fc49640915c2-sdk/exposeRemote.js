
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/fc49640915c2-sdk/static/js/remoteEntry.js'
    