
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/ea0c3ae5326e-sdk/static/js/remoteEntry.js'
    