
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/1d8aa6baa92e-sdk/static/js/remoteEntry.js'
    