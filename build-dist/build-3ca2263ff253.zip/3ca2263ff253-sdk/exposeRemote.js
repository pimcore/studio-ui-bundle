
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/3ca2263ff253-sdk/static/js/remoteEntry.js'
    