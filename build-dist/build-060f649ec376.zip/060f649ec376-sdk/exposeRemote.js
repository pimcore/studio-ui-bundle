
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/060f649ec376-sdk/static/js/remoteEntry.js'
    