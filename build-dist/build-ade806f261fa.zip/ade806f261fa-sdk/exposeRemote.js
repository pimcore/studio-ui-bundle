
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/ade806f261fa-sdk/static/js/remoteEntry.js'
    