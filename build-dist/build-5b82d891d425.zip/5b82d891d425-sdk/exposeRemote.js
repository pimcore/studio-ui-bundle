
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/5b82d891d425-sdk/static/js/remoteEntry.js'
    