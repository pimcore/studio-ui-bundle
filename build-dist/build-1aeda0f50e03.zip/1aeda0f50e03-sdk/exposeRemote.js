
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/1aeda0f50e03-sdk/static/js/remoteEntry.js'
    