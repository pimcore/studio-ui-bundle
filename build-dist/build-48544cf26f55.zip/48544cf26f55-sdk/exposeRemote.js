
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/48544cf26f55-sdk/static/js/remoteEntry.js'
    