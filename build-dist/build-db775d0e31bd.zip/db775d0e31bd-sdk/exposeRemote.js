
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/db775d0e31bd-sdk/static/js/remoteEntry.js'
    