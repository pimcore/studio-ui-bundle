
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/5682e938607f-sdk/static/js/remoteEntry.js'
    