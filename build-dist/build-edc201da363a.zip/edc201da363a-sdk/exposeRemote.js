
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/edc201da363a-sdk/static/js/remoteEntry.js'
    