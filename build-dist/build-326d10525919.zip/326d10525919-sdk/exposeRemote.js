
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/326d10525919-sdk/static/js/remoteEntry.js'
    