
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/0603b90da944-sdk/static/js/remoteEntry.js'
    