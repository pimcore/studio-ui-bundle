
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/f25ba55a31b0-sdk/static/js/remoteEntry.js'
    