
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/d9e7e7d356e7-sdk/static/js/remoteEntry.js'
    