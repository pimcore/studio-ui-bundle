
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/f5259cae2e1c-sdk/static/js/remoteEntry.js'
    