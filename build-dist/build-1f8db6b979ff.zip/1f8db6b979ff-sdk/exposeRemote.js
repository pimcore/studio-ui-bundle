
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/1f8db6b979ff-sdk/static/js/remoteEntry.js'
    