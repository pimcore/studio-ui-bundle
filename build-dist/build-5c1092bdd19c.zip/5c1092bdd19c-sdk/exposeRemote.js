
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/5c1092bdd19c-sdk/static/js/remoteEntry.js'
    