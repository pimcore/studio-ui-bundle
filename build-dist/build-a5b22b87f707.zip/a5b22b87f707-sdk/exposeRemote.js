
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/a5b22b87f707-sdk/static/js/remoteEntry.js'
    