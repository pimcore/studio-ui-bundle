
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/37179d347a6b-sdk/static/js/remoteEntry.js'
    