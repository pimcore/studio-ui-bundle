
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/42f9276376bb-sdk/static/js/remoteEntry.js'
    