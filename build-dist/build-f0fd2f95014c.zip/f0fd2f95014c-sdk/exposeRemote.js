
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/f0fd2f95014c-sdk/static/js/remoteEntry.js'
    