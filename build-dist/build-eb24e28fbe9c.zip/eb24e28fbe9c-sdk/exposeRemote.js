
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/eb24e28fbe9c-sdk/static/js/remoteEntry.js'
    