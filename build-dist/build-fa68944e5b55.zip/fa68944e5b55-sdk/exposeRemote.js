
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/fa68944e5b55-sdk/static/js/remoteEntry.js'
    