
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/0ac5243f6161-sdk/static/js/remoteEntry.js'
    