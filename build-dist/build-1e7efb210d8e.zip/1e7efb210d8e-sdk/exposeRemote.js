
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/1e7efb210d8e-sdk/static/js/remoteEntry.js'
    