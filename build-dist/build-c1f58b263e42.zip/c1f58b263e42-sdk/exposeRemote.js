
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/c1f58b263e42-sdk/static/js/remoteEntry.js'
    