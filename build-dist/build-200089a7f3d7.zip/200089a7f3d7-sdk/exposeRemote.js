
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/200089a7f3d7-sdk/static/js/remoteEntry.js'
    