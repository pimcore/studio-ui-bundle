
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/c3cac7d46d8e-sdk/static/js/remoteEntry.js'
    