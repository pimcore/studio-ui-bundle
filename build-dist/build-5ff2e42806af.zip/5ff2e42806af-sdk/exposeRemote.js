
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/5ff2e42806af-sdk/static/js/remoteEntry.js'
    