
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/49c7520ffcf8-sdk/static/js/remoteEntry.js'
    