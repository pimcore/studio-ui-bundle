
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/306411ac2068-sdk/static/js/remoteEntry.js'
    