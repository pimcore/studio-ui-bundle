
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/8a926eb441af-sdk/static/js/remoteEntry.js'
    