
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/7c34b7c847bf-sdk/static/js/remoteEntry.js'
    