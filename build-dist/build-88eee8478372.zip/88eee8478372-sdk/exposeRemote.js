
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/88eee8478372-sdk/static/js/remoteEntry.js'
    