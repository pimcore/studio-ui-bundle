
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/f89270f004b8-sdk/static/js/remoteEntry.js'
    