
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/e1f09349c259-sdk/static/js/remoteEntry.js'
    