
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/8a01809175c6-sdk/static/js/remoteEntry.js'
    