
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/2a26402db8a3-sdk/static/js/remoteEntry.js'
    