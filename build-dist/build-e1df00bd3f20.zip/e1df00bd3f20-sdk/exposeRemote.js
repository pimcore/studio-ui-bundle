
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/e1df00bd3f20-sdk/static/js/remoteEntry.js'
    