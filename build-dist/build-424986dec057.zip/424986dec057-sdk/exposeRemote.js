
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/424986dec057-sdk/static/js/remoteEntry.js'
    