
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/21fbe960f0a4-sdk/static/js/remoteEntry.js'
    