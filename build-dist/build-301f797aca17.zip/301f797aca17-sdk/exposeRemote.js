
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/301f797aca17-sdk/static/js/remoteEntry.js'
    