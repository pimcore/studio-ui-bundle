
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/b3f59f3fbe2d-sdk/static/js/remoteEntry.js'
    