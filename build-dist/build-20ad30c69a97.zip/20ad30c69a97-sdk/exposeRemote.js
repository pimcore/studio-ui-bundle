
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/20ad30c69a97-sdk/static/js/remoteEntry.js'
    