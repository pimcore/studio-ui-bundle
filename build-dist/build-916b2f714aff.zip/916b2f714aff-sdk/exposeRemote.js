
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/916b2f714aff-sdk/static/js/remoteEntry.js'
    