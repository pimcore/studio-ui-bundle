
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/503a375ea38c-sdk/static/js/remoteEntry.js'
    