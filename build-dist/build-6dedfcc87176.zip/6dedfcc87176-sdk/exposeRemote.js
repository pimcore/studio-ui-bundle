
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/6dedfcc87176-sdk/static/js/remoteEntry.js'
    