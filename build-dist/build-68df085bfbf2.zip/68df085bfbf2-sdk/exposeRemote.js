
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/68df085bfbf2-sdk/static/js/remoteEntry.js'
    