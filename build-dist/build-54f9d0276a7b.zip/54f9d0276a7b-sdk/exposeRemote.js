
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/54f9d0276a7b-sdk/static/js/remoteEntry.js'
    