
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/3805b73b23e8-sdk/static/js/remoteEntry.js'
    