
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/db9943b9e35e-sdk/static/js/remoteEntry.js'
    