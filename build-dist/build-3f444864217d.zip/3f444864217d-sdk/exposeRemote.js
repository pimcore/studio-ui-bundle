
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/3f444864217d-sdk/static/js/remoteEntry.js'
    