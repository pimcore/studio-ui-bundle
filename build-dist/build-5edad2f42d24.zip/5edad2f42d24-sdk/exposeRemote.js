
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/5edad2f42d24-sdk/static/js/remoteEntry.js'
    