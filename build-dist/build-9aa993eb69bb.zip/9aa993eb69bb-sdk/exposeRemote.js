
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/9aa993eb69bb-sdk/static/js/remoteEntry.js'
    