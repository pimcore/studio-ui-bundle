
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/99b585e0c55b-sdk/static/js/remoteEntry.js'
    