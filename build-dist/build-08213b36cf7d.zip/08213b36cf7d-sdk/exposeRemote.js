
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/08213b36cf7d-sdk/static/js/remoteEntry.js'
    