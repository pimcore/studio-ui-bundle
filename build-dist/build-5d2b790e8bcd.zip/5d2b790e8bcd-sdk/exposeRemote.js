
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/5d2b790e8bcd-sdk/static/js/remoteEntry.js'
    