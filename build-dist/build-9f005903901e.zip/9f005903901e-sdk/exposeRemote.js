
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/9f005903901e-sdk/static/js/remoteEntry.js'
    