
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/6841d3c8f48a-sdk/static/js/remoteEntry.js'
    