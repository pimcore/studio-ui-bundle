
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/715cf62bc39b-sdk/static/js/remoteEntry.js'
    