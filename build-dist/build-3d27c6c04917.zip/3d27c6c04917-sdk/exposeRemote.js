
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/3d27c6c04917-sdk/static/js/remoteEntry.js'
    