
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/f4c25a1119ef-sdk/static/js/remoteEntry.js'
    