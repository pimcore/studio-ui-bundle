
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/8114cd7158b0-sdk/static/js/remoteEntry.js'
    