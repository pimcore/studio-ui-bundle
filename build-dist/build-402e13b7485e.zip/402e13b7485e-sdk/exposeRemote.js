
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/402e13b7485e-sdk/static/js/remoteEntry.js'
    