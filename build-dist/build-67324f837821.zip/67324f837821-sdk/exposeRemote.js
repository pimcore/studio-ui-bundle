
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/67324f837821-sdk/static/js/remoteEntry.js'
    