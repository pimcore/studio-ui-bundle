
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/596598901e18-sdk/static/js/remoteEntry.js'
    