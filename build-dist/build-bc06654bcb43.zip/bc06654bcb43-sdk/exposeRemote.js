
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/bc06654bcb43-sdk/static/js/remoteEntry.js'
    