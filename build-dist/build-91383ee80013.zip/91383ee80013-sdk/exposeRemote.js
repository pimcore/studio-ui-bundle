
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/91383ee80013-sdk/static/js/remoteEntry.js'
    