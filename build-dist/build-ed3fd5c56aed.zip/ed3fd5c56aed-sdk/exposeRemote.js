
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/ed3fd5c56aed-sdk/static/js/remoteEntry.js'
    