
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/062331319ebc-sdk/static/js/remoteEntry.js'
    