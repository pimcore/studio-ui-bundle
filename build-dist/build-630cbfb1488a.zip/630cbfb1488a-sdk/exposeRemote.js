
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/630cbfb1488a-sdk/static/js/remoteEntry.js'
    