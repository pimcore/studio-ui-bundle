
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/94277ec2d678-sdk/static/js/remoteEntry.js'
    