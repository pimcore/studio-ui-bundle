
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/cdf82a29d55d-sdk/static/js/remoteEntry.js'
    