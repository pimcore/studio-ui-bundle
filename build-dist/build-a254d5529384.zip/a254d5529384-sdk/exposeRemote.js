
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/a254d5529384-sdk/static/js/remoteEntry.js'
    