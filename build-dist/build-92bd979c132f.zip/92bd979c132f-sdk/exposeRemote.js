
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/92bd979c132f-sdk/static/js/remoteEntry.js'
    