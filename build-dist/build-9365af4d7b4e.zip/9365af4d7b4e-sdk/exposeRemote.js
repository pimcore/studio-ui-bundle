
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/9365af4d7b4e-sdk/static/js/remoteEntry.js'
    