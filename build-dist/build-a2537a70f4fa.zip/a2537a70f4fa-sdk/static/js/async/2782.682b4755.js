/*! For license information please see 2782.682b4755.js.LICENSE.txt */
"use strict";(self.chunk_pimcore_studio_ui_bundle=self.chunk_pimcore_studio_ui_bundle||[]).push([["2782"],{1947(e,t,r){r.d(t,{_:()=>o});var n=r(89507),a=r(21429);let i=(0,n.createColumnHelper)(),o=e=>{let{useGridOptions:t,...r}=e;return{...r,useGridOptions:()=>{let{t:e}=(0,a.useTranslation)(),{transformGridColumnDefinition:r,...n}=t();return{...n,transformGridColumnDefinition:t=>{let n=r(t);return n.push(i.accessor("actions",{header:e("actions.open"),enableSorting:!1,meta:{type:"asset-actions"},size:65})),n}}}}}},72681(e,t,r){r.d(t,{y:()=>h});var n=r(74848),a=r(47867),i=r(73362),o=r(66707),l=r(39808),s=r(8412),d=r(66634),u=r(40910),c=r(94614),p=r(30698),f=r(68788);let h=e=>{let{ConfigurationComponent:t,ContextComponent:r,useSidebarOptions:h,...m}=e;return{...m,ContextComponent:(0,f._)(r),ConfigurationComponent:()=>{let{isLoading:e,data:r}=(0,i.useAssetGetAvailableGridColumnsQuery)(),{useElementId:p,useDataQueryHelper:f}=(0,s.t)(),{getId:h}=p(),{id:m}=(0,u.u)(),{isLoading:g,data:y}=(0,i.useAssetGetGridConfigurationByFolderIdQuery)({folderId:h(),configurationId:m}),{setSelectedColumns:w}=(0,o.K)(),{setAvailableColumns:b}=(0,d.m)(),{setGridConfig:v}=(0,c.m)(),{setDataLoadingState:x}=f();return((0,a.useEffect)(()=>{if(void 0===r||void 0===y)return;let e=[],t=r.columns.map(e=>e);for(let t of y.columns){let n=r.columns.find(e=>e.key===t.key);void 0!==n&&e.push({key:t.key,locale:t.locale,type:n.type,config:n.config,sortable:n.sortable,editable:n.editable,localizable:n.localizable,exportable:n.exportable,frontendType:n.frontendType,group:n.group,width:t.width,originalApiDefinition:n})}w(e),b(t),v(y),x("config-changed")},[r,y]),e||g)?(0,n.jsx)(l.U,{loading:!0}):(0,n.jsx)(t,{})},useSidebarOptions:(0,p.f)(h)}}},35510(e,t,r){r.d(t,{$:()=>a});var n=r(7334);let a=()=>{let{id:e}=(0,n.J)();return{getId:()=>e}}},50744(e,t,r){r.d(t,{P:()=>s});var n=r(89106),a=r(47867),i=r(8412),o=r(66707),l=r(79472);let s=(e,t)=>{let{useGridOptions:r,...s}=e;return{...s,useGridOptions:()=>{let{getGridProps:e,transformGridColumn:s,...d}=r(),[u,c]=(0,a.useState)([]),{useInlineEditApiUpdate:p}=t,{updateCache:f,updateApiData:h}=p(),{useDataQueryHelper:m}=(0,i.t)(),{getArgs:g}=m(),{decodeColumnIdentifier:y}=(0,o.K)(),w=e=>{let{rowData:t,columnId:r,value:a}=e,i=y(r);if(void 0===i)return;c(e=>!0===(null==e?void 0:e.some(e=>e.rowIndex===t.id&&e.columnId===r))?e:[...e??[],{rowIndex:t.id,columnId:r}]);let o={getGetRequestArgs:g(),update:{id:t.id,column:i,value:a},meta:e.meta},l=f(o);h(o).then(e=>{(0,n.isNil)(null==e?void 0:e.error)||null==l||l.undo()}).catch(()=>{null==l||l.undo()}).finally(()=>{c(e=>(null==e?void 0:e.filter(e=>e.rowIndex!==t.id||e.columnId!==r))??[])}).catch(()=>{})};return{...d,getGridProps:()=>({...e(),onUpdateCellData:w,modifiedCells:u}),transformGridColumn:e=>{let t=s(e);return{...t,meta:{...t.meta,editable:t=>(0,l.o)(t.permissions,"publish")&&e.editable}}}}}}}},36490(e,t,r){r.d(t,{y:()=>u});var n=r(74848),a=r(16852),i=r(47867),o=r(47904),l=r(47920),s=r(25214);let d=e=>{let{row:t}=e,[r,d]=(0,i.useState)(void 0),{selectRowIfUnselected:u}=(0,s.I)(t),c=(0,o.W)(l.r.assetListGrid.name,{row:t,onComplete:()=>{d(void 0)}});return(0,n.jsx)(a.m,{menu:{items:c,onClick:e=>{"locateInTree"===e.key&&d(!0)}},onOpenChange:e=>{e&&u()},open:r,trigger:["contextMenu"],children:e.children},t.id)},u=e=>{let{useGridOptions:t,...r}=e;return{...r,useGridOptions:()=>{let{getGridProps:e,...r}=t();return{...r,getGridProps:()=>({...e(),contextMenu:d})}}}}},56993(e,t,r){r.d(t,{C:()=>l});var n=r(46881),a=r(55638),i=r(73362),o=r(89106);let l=()=>{let[e]=(0,i.useAssetPatchByIdMutation)(),t=(0,n.useAppDispatch)();return{updateCache:e=>{let{update:r,getGetRequestArgs:n}=e,{id:a,column:o,value:l}=r;return t(i.api.util.updateQueryData("assetGetGrid",n,e=>{e:for(let t of e.items)if(t.id===a){for(let e of t.columns)if(e.key===o.key&&e.locale===o.locale){e.value=l;break e}}return e}))},updateApiData:async t=>{let{update:r}=t,n=e({body:{data:[{id:r.id,metadata:[{name:r.column.key,language:r.column.locale,data:r.value,type:r.column.type}]}]}}),i=await n;return(0,o.isNil)(i.error)||(0,a.Ay)(new a.hD(i.error)),i}}}},65373(e,t,r){r.d(t,{Cj:()=>c.C,wB:()=>i.w,pj:()=>P.p,w8:()=>E,yq:()=>s.y,yg:()=>A.y,Y9:()=>d.Y,YT:()=>F.Y,Sl:()=>f.S,U6:()=>S,_9:()=>j._,Pj:()=>u.P,A8:()=>D.A});var n=r(74848),a=r(73362),i=r(95198),o=r(47867),l=r(67923),s=r(72681),d=r(56177),u=r(50744),c=r(56993),p=r(35510),f=r(59991),h=r(66679),m=r(45490),g=r(37173);let y=()=>{let{toolbarSlotName:e}=(0,g.useSettings)();return(0,o.useMemo)(()=>(0,n.jsx)(m.ComponentRenderer,{component:e??m.componentConfig.asset.listing.toolbar.component.name}),[])};var w=r(62170),b=r(7334),v=r(79472),x=r(17388),k=r(68153);let C=(0,r(2829).rU)(e=>{let{token:t,css:r}=e;return{dropArea:r`
      height: 100%;
      width: 100%;
      min-height: 0;
      min-width: 0;
      overflow: hidden;
      position: relative;

      /* keep the grid's layout (full height, own scrolling) through antd's upload wrappers: a flex column
         chain, since percent heights fail under auto-height parents and antd sets display: table on the button */
      display: flex;
      flex-direction: column;

      && > div,
      && .ant-upload-wrapper,
      && .ant-upload,
      && .ant-upload-btn,
      && .ant-upload-drag-container {
        display: flex;
        flex-direction: column;
        flex: 1 1 auto;
        height: auto;
        width: 100%;
        min-height: 0;
        min-width: 0;
        max-width: 100%;
      }

      && .ant-upload-btn {
        padding: 0 !important;
      }

      /* antd marks every drag as hover; only drags that carry files may show the indicator */
      &:not([data-file-drag]) .ant-upload.ant-upload-drag-hover::after {
        display: none;
      }

      &[data-file-drag]::before {
        content: '';
        position: absolute;
        inset: 0;
        background: ${t.colorPrimaryBg};
        opacity: 0.5;
        border-radius: ${t.borderRadius}px;
        pointer-events: none;
        z-index: 1;
      }
    `}}),G=e=>{var t;return Array.from((null==(t=e.dataTransfer)?void 0:t.types)??[]).includes("Files")},I=e=>{let{children:t}=e,{id:r}=(0,b.J)(),{currentData:i}=(0,a.useAssetGetByIdQuery)({id:r}),{isTreeActionAllowed:l}=(0,x.H)(),{styles:s}=C(),[d,u]=(0,o.useState)(!1),c=(0,o.useRef)(0),p=(0,o.useCallback)(e=>{G(e)&&(c.current+=1,u(!0))},[]),f=(0,o.useCallback)(e=>{G(e)&&(c.current=Math.max(0,c.current-1),0===c.current&&u(!1))},[]),h=(0,o.useCallback)(()=>{c.current=0,u(!1)},[]);return void 0!==i&&(0,v.o)(i.permissions,"create")&&l(k.o.AddUpload)?(0,n.jsx)("div",{className:s.dropArea,"data-file-drag":d?"":void 0,"data-testid":"listing-drop-area",onDragEnter:p,onDragLeave:f,onDropCapture:h,children:(0,n.jsx)(w.G,{targetFolderId:r,targetPath:i.fullPath??"",children:t})}):(0,n.jsx)(n.Fragment,{children:t})},$=e=>(0,n.jsx)(I,{children:e});var j=r(1947),A=r(36490),F=r(23485),D=r(75872),P=r(74525),R=r(46881);let S={...i.G,ViewComponent:()=>(0,n.jsx)(h.d,{renderToolbar:y,wrapGrid:$}),useDataQuery:a.useAssetGetGridQuery,useDataQueryHelper:l.Q,useElementId:p.$},E=()=>{let e=(0,R.useInjection)("Asset/Listing/Builder");return(0,n.jsx)(i.w,{...e.build({props:S})})}},62170(e,t,r){r.d(t,{G:()=>N});var n=r(74848),a=r(47867),i=r(79694);let o=(0,r(2829).rU)(e=>{let{token:t,css:r}=e;return{dragger:r`
      .ant-upload {
        padding: 0 !important;
        background: none;
        border: none !important;
        
        &:hover {
            border: none !important;
        }
        
        &.ant-upload-drag-hover {
          position: relative;
          border-radius: ${t.borderRadius}px;

          &::after {
            content: '';
            position: absolute;
            inset: 0;
            border: 1px dashed ${t.colorLinkHover};
            border-radius: ${t.borderRadius}px;
            box-sizing: border-box;
            pointer-events: none;
            z-index: 1;
          }
        }

        .ant-upload-drag-container {
          width: 100%;
        }
      }
    `}});var l=r(82740),s=r(72623);let d=e=>{let{styles:t}=o(),{Dragger:r}=i.Upload,d=(0,a.useRef)(null),u=(0,l.A)(d,!0);return(0,n.jsx)("div",{ref:d,children:u?(0,n.jsx)(s.v,{...e,openFileDialogOnClick:!1,uploadComponent:r,uploadComponentClassName:t.dragger}):e.children})};var u=r(38990),c=r(55638),p=r(89106),f=r(58200);async function h(e){return await new Promise((t,r)=>{let n=[],a=()=>{e.readEntries(e=>{0===e.length?t(n):(n.push(...e),a())},r)};a()})}async function m(e){return await new Promise((t,r)=>{e.file(t,r)})}async function g(e,t){let r=`${(0,f.$)()}/elements/asset/folder/${e}`,n=await fetch(r,{method:"POST",credentials:"include",headers:{"Content-Type":"application/json"},body:JSON.stringify({folderName:t})});if(!n.ok&&409!==n.status&&!n.ok){let e=await n.text().catch(()=>String(n.status));if(e.includes("error_folder_exists")||e.includes("already exists"))return;throw Error(`Failed to create folder "${t}": ${e}`)}}async function y(e){let t=`${(0,f.$)()}/elements/asset/path?elementPath=${encodeURIComponent(e)}`,r=await fetch(t,{method:"GET",credentials:"include"});if(!r.ok){let t=await r.text().catch(()=>String(r.status));throw Error(`Failed to resolve folder ID for path "${e}": ${t}`)}let n=await r.json();if((0,p.isNil)(n)||"number"!=typeof n.id)throw Error(`Unexpected response resolving path "${e}": ${JSON.stringify(n)}`);return n.id}async function w(e,t,r,n){if(""===r)return e;n.set(t,e);let a=e,i=t;for(let e of r.split("/").filter(Boolean)){i=function(e,t){let r=e.endsWith("/")?e.slice(0,-1):e;return`${r}/${t}`}(i,e);let t=n.get(i);if(!(0,p.isNil)(t)){a=t;continue}await g(a,e),a=await y(i),n.set(i,a)}return a}async function b(e){let t=[],r=[];for(let r=0;r<e.items.length;r++){let n=e.items[r];if("function"==typeof n.webkitGetAsEntry){let e=n.webkitGetAsEntry();(0,p.isNil)(e)||t.push({entry:e,parentRelativeFolderPath:"",depth:0})}}for(;t.length>0;){let{entry:e,parentRelativeFolderPath:n,depth:a}=t.shift();if(!(a>20)){if(e.isFile){let t=await m(e);r.push({file:t,parentRelativeFolderPath:n})}else if(e.isDirectory){let r=""===n?e.name:`${n}/${e.name}`,i=e.createReader();for(let e of(await h(i)))t.push({entry:e,parentRelativeFolderPath:r,depth:a+1})}}}return r}let v=new WeakMap;function x(e){let t=v.get(e)??"";return`${t}/${e.name}-${e.size}`}async function k(e){let{dataTransfer:t,rootFolderId:r,rootPath:n,folderIdByKey:a,conflictMaps:i,checkFile:o}=e;if(""===n)throw Error(`Missing nodePath for folder ${r}`);let l=await b(t);if(0===l.length)return[];let s=new Map;for(let{file:e,parentRelativeFolderPath:t}of(a.clear(),l)){v.set(e,t);let i=await w(r,n,t,s);a.set(x(e),i)}for(let{file:e}of l){let t=x(e),r=a.get(t);await o(e,r)}return l.map(e=>{let{file:t}=e;return t}).filter(e=>!i.skipKeys.has(x(e)))}let C=e=>{var t,r;return null==(r=e.current)||null==(t=r.upload)?void 0:t.uploader};async function G(e,t){let r=C(e);for(let t=0;(0,p.isNil)(r)&&t<10;t++)await new Promise(e=>{setTimeout(e,100)}),r=C(e);(0,p.isNil)(r)?(0,c.Ay)(new c.$g("Folder upload: upload component not ready after drop")):r.uploadFiles(t)}var I=r(83655),$=r(58016),j=r(46881),A=r(79606),F=r(53996),D=r(21429),P=r(30492),R=r(13755),S=r(25750),E=r(22014);let T=e=>{let{open:t}=e,{t:r}=(0,D.useTranslation)();return(0,n.jsx)(P.a,{closable:!1,footer:null,iconName:"folder",open:t,title:r("asset.upload.folder-drop.creating-folders"),children:(0,n.jsxs)(S.s,{align:"center",gap:"small",justify:"center",style:{padding:"16px 0"},children:[(0,n.jsx)(R.t,{size:"small"}),(0,n.jsx)(E.E,{type:"secondary",children:r("asset.upload.folder-drop.creating-folders-hint")})]})})},N=e=>{let{targetFolderId:t,targetPath:r,disabled:i=!1,onUploaded:o,className:l,children:s}=e,{refreshTree:f}=(0,u.h)("asset"),h=(0,j.useAppDispatch)(),[m,g]=(0,a.useState)(!1),y=(0,a.useRef)(!1),{checkFile:w,maps:b,resetMaps:v}=(()=>{let{checkFileExists:e,askUserOverwrite:t,resetApplyToAll:r}=(0,$.e)(),n=(0,a.useRef)(new Map),i=(0,a.useRef)(new Set);return{checkFile:async(r,a)=>{let{exists:o,id:l}=await e(r.name,a);if(!o||(0,p.isNil)(l))return;let s=await t(r.name),d=x(r);s===I.W.SKIP?i.current.add(d):s===I.W.OVERWRITE&&n.current.set(d,l)},maps:{replaceIdByKey:n.current,skipKeys:i.current},resetMaps:()=>{n.current.clear(),i.current.clear(),r()}}})(),C=(0,a.useRef)(new Map),D=(0,a.useRef)(null),P=(0,a.useCallback)(e=>{D.current=e},[]),R=(0,a.useCallback)(e=>{if(y.current)return C.current.get(x(e))},[]),S=(0,a.useCallback)(e=>{if(y.current)return b.replaceIdByKey.get(x(e))},[b.replaceIdByKey]),E=(0,a.useCallback)(e=>{if((0,p.isNil)(e.dataTransfer)||!function(e){if((0,p.isNil)(e.items))return!1;for(let t=0;t<e.items.length;t++){let r=e.items[t];if("function"!=typeof r.webkitGetAsEntry)continue;let n=r.webkitGetAsEntry();if((null==n?void 0:n.isDirectory)===!0)return!0}return!1}(e.dataTransfer))return;e.preventDefault(),e.stopPropagation();let n=e.dataTransfer;(async()=>{let e;v(),y.current=!1,g(!0);try{e=await k({dataTransfer:n,rootFolderId:t,rootPath:r,folderIdByKey:C.current,conflictMaps:b,checkFile:w})}catch(e){(0,c.Ay)(new c.$g(`Folder upload (tree traversal): ${e instanceof Error?e.message:String(e)}`)),g(!1);return}g(!1),0!==e.length&&(y.current=!0,await G(D,e))})()},[r,t,b,w,v]);return i?(0,n.jsx)(n.Fragment,{children:s}):(0,n.jsxs)(n.Fragment,{children:[(0,n.jsx)(T,{open:m}),(0,n.jsx)("div",{className:l,onDropCapture:E,children:(0,n.jsx)(d,{getExternalReplaceId:S,getTargetFolderIdForFile:R,onSuccess:async()=>{y.current=!1,f(t),h(A.FH.util.invalidateTags(F.qN.ASSET_GRID_ID(t))),null==o||o()},skipAssetFetch:!0,skipConflictCheck:y,targetFolderId:t,uploadRef:P,children:s})})]})}}}]);