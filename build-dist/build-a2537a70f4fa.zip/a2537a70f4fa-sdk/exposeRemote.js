
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/a2537a70f4fa-sdk/static/js/remoteEntry.js'
    