
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/a01a199c17b0-sdk/static/js/remoteEntry.js'
    