
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/f214dcd1a9e9-sdk/static/js/remoteEntry.js'
    