
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/3d2054990cc6-sdk/static/js/remoteEntry.js'
    