
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/e2340a2b121d-sdk/static/js/remoteEntry.js'
    