
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/184a98fffefe-sdk/static/js/remoteEntry.js'
    