
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/0971c0fe6067-sdk/static/js/remoteEntry.js'
    