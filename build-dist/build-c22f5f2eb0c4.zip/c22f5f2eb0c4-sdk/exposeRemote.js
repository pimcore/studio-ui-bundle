
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/c22f5f2eb0c4-sdk/static/js/remoteEntry.js'
    