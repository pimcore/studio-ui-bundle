
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/4148e83e12d7-sdk/static/js/remoteEntry.js'
    