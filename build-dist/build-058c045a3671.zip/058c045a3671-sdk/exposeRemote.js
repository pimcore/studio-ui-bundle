
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/058c045a3671-sdk/static/js/remoteEntry.js'
    