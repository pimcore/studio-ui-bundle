
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/7bacc11060aa-sdk/static/js/remoteEntry.js'
    