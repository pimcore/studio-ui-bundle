
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/4215dd254074-sdk/static/js/remoteEntry.js'
    