
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/286952ce8bd4-sdk/static/js/remoteEntry.js'
    