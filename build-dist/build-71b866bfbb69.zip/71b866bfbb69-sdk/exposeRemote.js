
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/71b866bfbb69-sdk/static/js/remoteEntry.js'
    