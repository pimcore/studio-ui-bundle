
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/bbbc2ec8329d-sdk/static/js/remoteEntry.js'
    