
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/455565037c66-sdk/static/js/remoteEntry.js'
    