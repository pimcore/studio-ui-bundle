
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/da45a0f6ff67-sdk/static/js/remoteEntry.js'
    