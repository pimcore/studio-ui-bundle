
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/b097868f4f28-sdk/static/js/remoteEntry.js'
    