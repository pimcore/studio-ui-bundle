
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/5cbac20837d8-sdk/static/js/remoteEntry.js'
    