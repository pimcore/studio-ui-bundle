
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/38f8f349e5f8-sdk/static/js/remoteEntry.js'
    