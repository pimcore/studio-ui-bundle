
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/4ad71b48c45c-sdk/static/js/remoteEntry.js'
    