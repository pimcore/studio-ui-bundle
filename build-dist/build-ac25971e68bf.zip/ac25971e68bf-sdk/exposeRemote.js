
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/ac25971e68bf-sdk/static/js/remoteEntry.js'
    