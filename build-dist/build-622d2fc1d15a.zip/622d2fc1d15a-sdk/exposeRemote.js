
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/622d2fc1d15a-sdk/static/js/remoteEntry.js'
    