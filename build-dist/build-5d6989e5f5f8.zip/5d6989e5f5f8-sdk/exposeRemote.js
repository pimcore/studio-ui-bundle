
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/5d6989e5f5f8-sdk/static/js/remoteEntry.js'
    