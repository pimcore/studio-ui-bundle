
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/bd28e8db178b-sdk/static/js/remoteEntry.js'
    