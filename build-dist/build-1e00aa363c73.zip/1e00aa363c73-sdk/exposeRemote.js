
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/1e00aa363c73-sdk/static/js/remoteEntry.js'
    