
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/a944d4c36ac2-sdk/static/js/remoteEntry.js'
    