
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/869b777cfd83-sdk/static/js/remoteEntry.js'
    