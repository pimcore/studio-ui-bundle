
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/78d9e26183ae-sdk/static/js/remoteEntry.js'
    