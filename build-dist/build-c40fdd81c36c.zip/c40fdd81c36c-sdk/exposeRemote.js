
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/c40fdd81c36c-sdk/static/js/remoteEntry.js'
    