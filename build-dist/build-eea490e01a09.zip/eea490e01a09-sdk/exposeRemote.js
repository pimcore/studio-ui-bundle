
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/eea490e01a09-sdk/static/js/remoteEntry.js'
    