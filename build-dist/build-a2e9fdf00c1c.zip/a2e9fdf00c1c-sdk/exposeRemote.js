
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/a2e9fdf00c1c-sdk/static/js/remoteEntry.js'
    