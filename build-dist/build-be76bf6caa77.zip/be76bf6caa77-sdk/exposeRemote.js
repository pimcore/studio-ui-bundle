
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/be76bf6caa77-sdk/static/js/remoteEntry.js'
    