
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/ac066373aae6-sdk/static/js/remoteEntry.js'
    