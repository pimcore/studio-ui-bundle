
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/177de75f6ab2-sdk/static/js/remoteEntry.js'
    