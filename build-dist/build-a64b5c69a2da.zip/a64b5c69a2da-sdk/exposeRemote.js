
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/a64b5c69a2da-sdk/static/js/remoteEntry.js'
    