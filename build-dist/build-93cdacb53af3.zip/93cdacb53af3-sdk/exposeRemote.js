
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/93cdacb53af3-sdk/static/js/remoteEntry.js'
    