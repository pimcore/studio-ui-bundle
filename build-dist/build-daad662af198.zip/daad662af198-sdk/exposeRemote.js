
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/daad662af198-sdk/static/js/remoteEntry.js'
    