
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/ba3cb8a99b30-sdk/static/js/remoteEntry.js'
    