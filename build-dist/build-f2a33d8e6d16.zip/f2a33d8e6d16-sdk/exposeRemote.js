
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/f2a33d8e6d16-sdk/static/js/remoteEntry.js'
    