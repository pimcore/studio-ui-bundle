
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/5167d26240ec-sdk/static/js/remoteEntry.js'
    