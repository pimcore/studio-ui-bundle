
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/0b3a03f7b433-sdk/static/js/remoteEntry.js'
    