
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/fc97285f2a44-sdk/static/js/remoteEntry.js'
    