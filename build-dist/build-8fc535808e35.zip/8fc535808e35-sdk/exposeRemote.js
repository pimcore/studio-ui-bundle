
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/8fc535808e35-sdk/static/js/remoteEntry.js'
    