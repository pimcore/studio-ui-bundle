
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/cc29fc529e50-sdk/static/js/remoteEntry.js'
    