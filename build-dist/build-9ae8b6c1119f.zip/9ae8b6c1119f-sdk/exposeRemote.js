
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/9ae8b6c1119f-sdk/static/js/remoteEntry.js'
    