
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/19dbd6ad7411-sdk/static/js/remoteEntry.js'
    