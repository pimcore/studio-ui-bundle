
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/06032f25d658-sdk/static/js/remoteEntry.js'
    