
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/d0440d6f24fb-sdk/static/js/remoteEntry.js'
    