
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/c9ae776b033e-sdk/static/js/remoteEntry.js'
    