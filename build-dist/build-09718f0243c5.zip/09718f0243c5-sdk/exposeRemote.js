
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/09718f0243c5-sdk/static/js/remoteEntry.js'
    