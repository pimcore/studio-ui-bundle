
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/10552d730d9b-sdk/static/js/remoteEntry.js'
    