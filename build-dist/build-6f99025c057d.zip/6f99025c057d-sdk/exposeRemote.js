
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/6f99025c057d-sdk/static/js/remoteEntry.js'
    