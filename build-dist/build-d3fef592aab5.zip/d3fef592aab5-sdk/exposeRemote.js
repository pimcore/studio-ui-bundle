
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/d3fef592aab5-sdk/static/js/remoteEntry.js'
    