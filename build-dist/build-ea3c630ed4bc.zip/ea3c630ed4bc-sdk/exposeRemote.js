
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/ea3c630ed4bc-sdk/static/js/remoteEntry.js'
    