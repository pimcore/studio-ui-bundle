
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/b228877a6fa4-sdk/static/js/remoteEntry.js'
    