
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/677f459d8280-sdk/static/js/remoteEntry.js'
    