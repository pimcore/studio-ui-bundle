
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/b87cc4f95081-sdk/static/js/remoteEntry.js'
    