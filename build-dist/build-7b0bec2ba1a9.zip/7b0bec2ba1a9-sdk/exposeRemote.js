
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/7b0bec2ba1a9-sdk/static/js/remoteEntry.js'
    