
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/d09514fbaa97-sdk/static/js/remoteEntry.js'
    