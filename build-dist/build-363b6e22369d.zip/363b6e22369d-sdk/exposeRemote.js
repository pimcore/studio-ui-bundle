
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/363b6e22369d-sdk/static/js/remoteEntry.js'
    