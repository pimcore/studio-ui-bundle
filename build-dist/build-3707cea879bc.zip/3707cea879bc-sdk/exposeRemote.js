
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/3707cea879bc-sdk/static/js/remoteEntry.js'
    