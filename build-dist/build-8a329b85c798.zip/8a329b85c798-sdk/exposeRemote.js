
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/8a329b85c798-sdk/static/js/remoteEntry.js'
    