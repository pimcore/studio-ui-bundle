
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/dd08b0c50929-sdk/static/js/remoteEntry.js'
    