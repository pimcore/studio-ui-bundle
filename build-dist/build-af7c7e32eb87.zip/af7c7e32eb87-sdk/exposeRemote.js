
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/af7c7e32eb87-sdk/static/js/remoteEntry.js'
    