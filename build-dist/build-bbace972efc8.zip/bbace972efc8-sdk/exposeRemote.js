
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/bbace972efc8-sdk/static/js/remoteEntry.js'
    