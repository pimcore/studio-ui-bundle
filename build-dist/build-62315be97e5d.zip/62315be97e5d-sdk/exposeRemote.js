
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/62315be97e5d-sdk/static/js/remoteEntry.js'
    