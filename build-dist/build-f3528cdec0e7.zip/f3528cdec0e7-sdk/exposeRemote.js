
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/f3528cdec0e7-sdk/static/js/remoteEntry.js'
    