
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/a6a865fd6655-sdk/static/js/remoteEntry.js'
    