
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/693f60792625-sdk/static/js/remoteEntry.js'
    