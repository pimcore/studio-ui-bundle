
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/008e9a103527-sdk/static/js/remoteEntry.js'
    