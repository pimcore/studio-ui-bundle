
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/28817ef865c5-sdk/static/js/remoteEntry.js'
    