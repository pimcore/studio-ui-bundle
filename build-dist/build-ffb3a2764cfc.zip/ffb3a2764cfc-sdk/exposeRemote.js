
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/ffb3a2764cfc-sdk/static/js/remoteEntry.js'
    