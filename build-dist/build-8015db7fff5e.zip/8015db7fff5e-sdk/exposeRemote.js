
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/8015db7fff5e-sdk/static/js/remoteEntry.js'
    