
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/bdacd8dde871-sdk/static/js/remoteEntry.js'
    