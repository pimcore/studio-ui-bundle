
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/97312173a27f-sdk/static/js/remoteEntry.js'
    