
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/67120503fe61-sdk/static/js/remoteEntry.js'
    