
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/0dc95240c0fe-sdk/static/js/remoteEntry.js'
    