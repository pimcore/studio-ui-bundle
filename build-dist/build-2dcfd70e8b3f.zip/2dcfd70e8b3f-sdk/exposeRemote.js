
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/2dcfd70e8b3f-sdk/static/js/remoteEntry.js'
    