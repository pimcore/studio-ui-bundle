
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/d16f79e9a811-sdk/static/js/remoteEntry.js'
    