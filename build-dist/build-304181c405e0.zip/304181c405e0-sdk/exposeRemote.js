
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/304181c405e0-sdk/static/js/remoteEntry.js'
    