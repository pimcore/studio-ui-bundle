
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/ab80b8e32835-sdk/static/js/remoteEntry.js'
    