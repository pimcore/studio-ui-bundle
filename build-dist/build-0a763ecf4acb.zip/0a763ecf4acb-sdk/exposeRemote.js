
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/0a763ecf4acb-sdk/static/js/remoteEntry.js'
    