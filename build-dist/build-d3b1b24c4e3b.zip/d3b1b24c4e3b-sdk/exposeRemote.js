
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/d3b1b24c4e3b-sdk/static/js/remoteEntry.js'
    