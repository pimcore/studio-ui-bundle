
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/078eac3c6363-sdk/static/js/remoteEntry.js'
    