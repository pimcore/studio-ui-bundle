
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/a83e0cb7f648-sdk/static/js/remoteEntry.js'
    