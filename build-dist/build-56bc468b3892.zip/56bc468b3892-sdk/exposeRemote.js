
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/56bc468b3892-sdk/static/js/remoteEntry.js'
    