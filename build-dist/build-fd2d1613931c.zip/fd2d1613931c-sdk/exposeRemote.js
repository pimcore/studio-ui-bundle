
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/fd2d1613931c-sdk/static/js/remoteEntry.js'
    