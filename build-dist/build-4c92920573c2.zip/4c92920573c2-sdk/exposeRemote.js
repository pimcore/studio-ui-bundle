
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/4c92920573c2-sdk/static/js/remoteEntry.js'
    