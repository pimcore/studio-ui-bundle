
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/738a1ffa49bb-sdk/static/js/remoteEntry.js'
    