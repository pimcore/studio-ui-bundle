
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/6cdcba782ce2-sdk/static/js/remoteEntry.js'
    