
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/c06db502e576-sdk/static/js/remoteEntry.js'
    