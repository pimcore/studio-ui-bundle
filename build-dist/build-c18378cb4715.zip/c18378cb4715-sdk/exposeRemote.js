
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/c18378cb4715-sdk/static/js/remoteEntry.js'
    