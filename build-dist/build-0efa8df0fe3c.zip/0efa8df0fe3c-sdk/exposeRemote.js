
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/0efa8df0fe3c-sdk/static/js/remoteEntry.js'
    