
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/8958bef5e0ca-sdk/static/js/remoteEntry.js'
    