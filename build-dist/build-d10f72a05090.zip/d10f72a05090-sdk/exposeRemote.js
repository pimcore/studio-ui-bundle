
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/d10f72a05090-sdk/static/js/remoteEntry.js'
    