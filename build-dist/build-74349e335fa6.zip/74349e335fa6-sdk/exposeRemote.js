
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/74349e335fa6-sdk/static/js/remoteEntry.js'
    