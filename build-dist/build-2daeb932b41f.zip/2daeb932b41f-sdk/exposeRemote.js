
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/2daeb932b41f-sdk/static/js/remoteEntry.js'
    