
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/faa6e8d74171-sdk/static/js/remoteEntry.js'
    