
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/b80d103e3081-sdk/static/js/remoteEntry.js'
    