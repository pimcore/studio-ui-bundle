
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/9299e0542a0d-sdk/static/js/remoteEntry.js'
    