
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/599755c85b77-sdk/static/js/remoteEntry.js'
    