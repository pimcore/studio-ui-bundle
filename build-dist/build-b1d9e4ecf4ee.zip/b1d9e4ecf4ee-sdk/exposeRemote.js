
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/b1d9e4ecf4ee-sdk/static/js/remoteEntry.js'
    