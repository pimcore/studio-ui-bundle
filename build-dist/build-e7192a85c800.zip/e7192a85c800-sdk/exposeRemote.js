
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/e7192a85c800-sdk/static/js/remoteEntry.js'
    