
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/8e1ca561dbd7-sdk/static/js/remoteEntry.js'
    