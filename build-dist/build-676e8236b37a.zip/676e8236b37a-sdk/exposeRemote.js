
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/676e8236b37a-sdk/static/js/remoteEntry.js'
    