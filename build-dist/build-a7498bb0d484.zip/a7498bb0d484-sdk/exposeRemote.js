
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/a7498bb0d484-sdk/static/js/remoteEntry.js'
    