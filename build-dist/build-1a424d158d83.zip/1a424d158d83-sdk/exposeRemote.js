
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/1a424d158d83-sdk/static/js/remoteEntry.js'
    