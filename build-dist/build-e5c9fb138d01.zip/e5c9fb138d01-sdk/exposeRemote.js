
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/e5c9fb138d01-sdk/static/js/remoteEntry.js'
    