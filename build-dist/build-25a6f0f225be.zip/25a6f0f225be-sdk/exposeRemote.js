
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/25a6f0f225be-sdk/static/js/remoteEntry.js'
    