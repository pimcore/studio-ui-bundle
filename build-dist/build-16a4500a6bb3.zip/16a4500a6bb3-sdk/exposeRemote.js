
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/16a4500a6bb3-sdk/static/js/remoteEntry.js'
    