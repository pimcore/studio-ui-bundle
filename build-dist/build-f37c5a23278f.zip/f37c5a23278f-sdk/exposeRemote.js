
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/f37c5a23278f-sdk/static/js/remoteEntry.js'
    