
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/0392529c57c6-sdk/static/js/remoteEntry.js'
    