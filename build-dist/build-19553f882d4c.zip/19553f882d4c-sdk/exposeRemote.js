
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/19553f882d4c-sdk/static/js/remoteEntry.js'
    