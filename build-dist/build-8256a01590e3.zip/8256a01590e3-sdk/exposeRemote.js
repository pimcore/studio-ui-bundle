
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/8256a01590e3-sdk/static/js/remoteEntry.js'
    