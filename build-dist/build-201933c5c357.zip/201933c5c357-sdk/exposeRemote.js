
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/201933c5c357-sdk/static/js/remoteEntry.js'
    