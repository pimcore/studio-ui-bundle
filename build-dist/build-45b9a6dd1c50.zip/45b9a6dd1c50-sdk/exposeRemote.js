
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/45b9a6dd1c50-sdk/static/js/remoteEntry.js'
    