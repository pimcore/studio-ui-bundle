
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/cb43f609d19b-sdk/static/js/remoteEntry.js'
    