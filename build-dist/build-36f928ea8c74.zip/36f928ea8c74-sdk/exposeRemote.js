
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/36f928ea8c74-sdk/static/js/remoteEntry.js'
    