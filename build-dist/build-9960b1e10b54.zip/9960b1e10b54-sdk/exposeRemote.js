
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/9960b1e10b54-sdk/static/js/remoteEntry.js'
    