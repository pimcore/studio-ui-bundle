
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/7f483b07d5a8-sdk/static/js/remoteEntry.js'
    