
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/1d99001aa194-sdk/static/js/remoteEntry.js'
    