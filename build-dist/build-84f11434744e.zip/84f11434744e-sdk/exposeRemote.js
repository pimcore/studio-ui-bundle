
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/84f11434744e-sdk/static/js/remoteEntry.js'
    