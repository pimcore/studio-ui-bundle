
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/2ae44dbf2149-sdk/static/js/remoteEntry.js'
    