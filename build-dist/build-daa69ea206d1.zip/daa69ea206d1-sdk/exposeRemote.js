
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/daa69ea206d1-sdk/static/js/remoteEntry.js'
    