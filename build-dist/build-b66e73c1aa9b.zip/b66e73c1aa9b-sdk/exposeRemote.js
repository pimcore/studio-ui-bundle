
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/b66e73c1aa9b-sdk/static/js/remoteEntry.js'
    