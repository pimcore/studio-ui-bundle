
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/3ee469ecb466-sdk/static/js/remoteEntry.js'
    