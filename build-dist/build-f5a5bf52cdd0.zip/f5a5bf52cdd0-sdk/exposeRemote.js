
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/f5a5bf52cdd0-sdk/static/js/remoteEntry.js'
    