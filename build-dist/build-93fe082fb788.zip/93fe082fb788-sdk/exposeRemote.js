
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/93fe082fb788-sdk/static/js/remoteEntry.js'
    