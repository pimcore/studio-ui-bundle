
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/a13c0c65e1ea-sdk/static/js/remoteEntry.js'
    