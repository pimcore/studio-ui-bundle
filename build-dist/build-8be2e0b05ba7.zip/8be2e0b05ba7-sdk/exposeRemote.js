
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/8be2e0b05ba7-sdk/static/js/remoteEntry.js'
    