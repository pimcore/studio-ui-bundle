
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/8d8d2971ebec-sdk/static/js/remoteEntry.js'
    