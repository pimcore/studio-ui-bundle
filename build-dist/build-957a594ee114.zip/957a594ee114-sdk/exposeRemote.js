
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/957a594ee114-sdk/static/js/remoteEntry.js'
    