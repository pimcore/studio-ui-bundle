
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/ddc4564584d1-sdk/static/js/remoteEntry.js'
    