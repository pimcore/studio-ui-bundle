
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/3d6911edcdf3-sdk/static/js/remoteEntry.js'
    