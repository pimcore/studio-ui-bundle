
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/c7de7f373b84-sdk/static/js/remoteEntry.js'
    