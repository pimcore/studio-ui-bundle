
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/2b63b010c881-sdk/static/js/remoteEntry.js'
    