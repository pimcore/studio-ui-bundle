
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/6ec693c9e316-sdk/static/js/remoteEntry.js'
    