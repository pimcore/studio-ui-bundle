
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/8ff0b82cb6ec-sdk/static/js/remoteEntry.js'
    