
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/a0953cdbeb8d-sdk/static/js/remoteEntry.js'
    