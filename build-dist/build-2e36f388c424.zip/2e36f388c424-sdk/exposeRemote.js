
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/2e36f388c424-sdk/static/js/remoteEntry.js'
    