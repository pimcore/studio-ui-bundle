
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/0dca4d1f185c-sdk/static/js/remoteEntry.js'
    