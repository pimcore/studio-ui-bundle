
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/ebd91fd1993f-sdk/static/js/remoteEntry.js'
    