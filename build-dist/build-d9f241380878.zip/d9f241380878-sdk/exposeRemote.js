
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/d9f241380878-sdk/static/js/remoteEntry.js'
    