
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/b0a84e4c9a8c-sdk/static/js/remoteEntry.js'
    