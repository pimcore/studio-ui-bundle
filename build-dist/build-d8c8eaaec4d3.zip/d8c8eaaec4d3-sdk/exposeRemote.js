
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/d8c8eaaec4d3-sdk/static/js/remoteEntry.js'
    