
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/30f84a3b872b-sdk/static/js/remoteEntry.js'
    