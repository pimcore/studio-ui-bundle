
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/d0b88582fffb-sdk/static/js/remoteEntry.js'
    