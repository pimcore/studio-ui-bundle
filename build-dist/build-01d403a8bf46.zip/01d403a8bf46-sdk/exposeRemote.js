
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/01d403a8bf46-sdk/static/js/remoteEntry.js'
    