
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/f974c19107f2-sdk/static/js/remoteEntry.js'
    