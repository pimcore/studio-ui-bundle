
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/6eafdea8bb11-sdk/static/js/remoteEntry.js'
    