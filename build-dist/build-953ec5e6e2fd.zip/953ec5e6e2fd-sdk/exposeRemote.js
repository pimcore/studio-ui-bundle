
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/953ec5e6e2fd-sdk/static/js/remoteEntry.js'
    