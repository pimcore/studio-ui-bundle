
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/ab9713278aea-sdk/static/js/remoteEntry.js'
    