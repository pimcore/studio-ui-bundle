
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/26166275be55-sdk/static/js/remoteEntry.js'
    