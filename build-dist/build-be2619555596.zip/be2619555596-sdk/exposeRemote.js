
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/be2619555596-sdk/static/js/remoteEntry.js'
    