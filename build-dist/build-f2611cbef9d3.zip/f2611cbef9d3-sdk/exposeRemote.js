
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/f2611cbef9d3-sdk/static/js/remoteEntry.js'
    