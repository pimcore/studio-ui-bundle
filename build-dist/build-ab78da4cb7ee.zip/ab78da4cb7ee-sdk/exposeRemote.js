
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/ab78da4cb7ee-sdk/static/js/remoteEntry.js'
    