
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/e216820697f4-sdk/static/js/remoteEntry.js'
    