
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/7bfd05b79438-sdk/static/js/remoteEntry.js'
    