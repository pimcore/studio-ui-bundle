
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/e56f1c2e4e70-sdk/static/js/remoteEntry.js'
    