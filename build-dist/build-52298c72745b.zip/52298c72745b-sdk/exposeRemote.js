
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/52298c72745b-sdk/static/js/remoteEntry.js'
    