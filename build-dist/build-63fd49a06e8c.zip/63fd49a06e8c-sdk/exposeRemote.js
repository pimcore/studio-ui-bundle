
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/63fd49a06e8c-sdk/static/js/remoteEntry.js'
    