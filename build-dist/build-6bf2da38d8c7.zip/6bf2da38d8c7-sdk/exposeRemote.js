
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/6bf2da38d8c7-sdk/static/js/remoteEntry.js'
    