
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/d4c022e6bc59-sdk/static/js/remoteEntry.js'
    