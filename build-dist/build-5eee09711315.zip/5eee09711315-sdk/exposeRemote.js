
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/5eee09711315-sdk/static/js/remoteEntry.js'
    